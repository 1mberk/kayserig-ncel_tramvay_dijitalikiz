# -*- coding: utf-8 -*-
"""
KAYSERAY DİJİTAL İKİZİ (Kayseri Tramvay Ağı & T5 Erkilet Entegrasyonu)
=============================================================================
TAM DONANIMLI SÜRÜM (75 İstasyonlu Gerçek Veri Motoru + SL-Train Video Tarzı Mapbox Haritası):
1. Veri Motoru (`KayseriDataEngine`): `kayseri_rail_network.json` üzerinden 75 gerçek istasyon,
   8 hat-yön rotası ve gerçek sefer tarifeleriyle tam kapasite çalışır.
2. Harita Yapısı (SL-Train Video Stili + Mapbox API Key Entegrasyonu):
   - Kullanıcının Mapbox API anahtarı (`pk.eyJ1IjoibWV0aW5iZXJrYWt5b2wi...`) ile
     `Mapbox Dark v11` koyu vektör altlığı varsayılan katmandır.
   - Videodaki gibi parlak neon ray koridorları, beyaz halka istasyon düğümleri,
     renkli hat rozetli (`[T1][T2][T5]`) koyu kapsül istasyon etiketleri ve
     peron yolcu yoğunluğu (`<0.2` Mavi, `<0.5` Sarı, `<1.0` Turuncu, `>1.0` Kırmızı) gösterimi.
3. Tüm Yan Barlar, Metrik Kartları ve 5 Operasyonel Sekme Eksiksiz Korunmuştur:
   - Sekme 1: Canlı Kayseri Haritası (SL-Train Koridor Haritası & 3D Peron İkizi)
   - Sekme 2: Peron Yolcu Biniş / İniş Akış Grafiği
   - Sekme 3: Cumhuriyet Meydanı Darboğaz Analizi
   - Sekme 4: T5 Erkilet Planlama & Filo Optimizasyonu
   - Sekme 5: Aktif Tramvay Telemetri & RAMS Arıza Backlogu Tablosu
=============================================================================
"""

import json
import math
import os
import urllib.request
from datetime import time
import pandas as pd
import streamlit as st
import folium

try:
    from streamlit_folium import st_folium
    HAS_ST_FOLIUM = True
except ImportError:
    import streamlit.components.v1 as components
    HAS_ST_FOLIUM = False

try:
    import pydeck as pdk
    HAS_PYDECK = True
except ImportError:
    HAS_PYDECK = False

# Kullanıcının Mapbox API Anahtarı
MAPBOX_ACCESS_TOKEN = "pk.eyJ1IjoibWV0aW5iZXJrYWt5b2wiLCJhIjoiY213YXg4eGdwMDgwczJ4c2h0aTZxNmJudiJ9.zr2V41O_aFnj_tdV1aLLBA"

# OSM 403 Engeline Karşı Standart HTTP User-Agent ve Referer Başlığı
STANDARD_HTTP_HEADERS = {
    "User-Agent": "KayserayDigitalTwin/4.0 (https://kayseri.bel.tr; ulasim@kayseri.bel.tr) Mozilla/5.0",
    "Referer": "https://kayseri.bel.tr/",
}
_opener = urllib.request.build_opener()
_opener.addheaders = [(k, v) for k, v in STANDARD_HTTP_HEADERS.items()]
urllib.request.install_opener(_opener)


# ==============================================================================
# 1. VERİ MOTORU & GERÇEKÇİ RAY GEOMETRİSİ (DATA & TRACK ENGINE)
# ==============================================================================

DAY_PROFILES = {
    "Hafta İçi (Pzt-Cum)": {
        "code": "WEEKDAY",
        "headway_mult": 1.0,
        "demand_scale": 1.0,
        "desc": "Sabah 07:00-09:00 ve Akşam 16:30-19:00 tam kapasite iş/okul piki."
    },
    "Cumartesi Tarifesi": {
        "code": "SATURDAY",
        "headway_mult": 1.25,
        "demand_scale": 0.85,
        "desc": "Öğle ve alışveriş odaklı yayvan hafta sonu yoğunluk profili (11:00-19:00)."
    },
    "Pazar / Resmî Tatil": {
        "code": "SUNDAY",
        "headway_mult": 1.50,
        "demand_scale": 0.65,
        "desc": "Seyreltilmiş pazar sefer sıklığı ve sosyal/rekreasyonel talep eğrisi."
    }
}


class KayseriDataEngine:
    def __init__(self, json_path="kayseri_rail_network.json"):
        self.json_path = json_path
        self.data = self._load_data()
        self.stations = {s["station_id"]: s for s in self.data["stations"]}
        self.lines = {l["line_code"]: l for l in self.data["lines"]}
        self.routes = self.data["routes"]
        self.timetables = self.data["timetables_weekday"]
        self.station_demand_weights = self._init_station_demand_weights()
        self.route_station_profiles = self._precompute_route_profiles()

    def _load_data(self):
        paths_to_try = [
            self.json_path,
            os.path.join(os.path.dirname(__file__), self.json_path),
            os.path.join(os.path.dirname(__file__), "data", self.json_path),
            os.path.join(r"C:\Users\tzmas\.gemini\antigravity\scratch\kayseri-tramvay-ikizi", self.json_path),
            os.path.join(r"C:\Users\tzmas\.gemini\antigravity\scratch\kayseri_tram_digital_twin", self.json_path)
        ]
        for p in paths_to_try:
            if p and os.path.exists(p):
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
        raise FileNotFoundError(f"{self.json_path} dosyası bulunamadı.")

    def _init_station_demand_weights(self):
        """KBB 160.000 günlük yolcu verisine dayalı durak bazlı günlük biniş ağırlıkları."""
        weights = {}
        for s_id, s in self.stations.items():
            if s_id == "STN_19":   # Cumhuriyet Meydanı
                weights[s_id] = 28500
            elif s_id == "STN_20": # Hunat Hatun
                weights[s_id] = 16500
            elif s_id == "STN_24": # Tuna
                weights[s_id] = 14200
            elif s_id == "STN_06": # Anafartalar
                weights[s_id] = 11500
            elif s_id == "STN_48": # Erciyes Üniversitesi
                weights[s_id] = 13000
            elif s_id == "STN_49": # Hastaneler
                weights[s_id] = 9800
            elif s_id == "STN_61": # Şehir Hastanesi
                weights[s_id] = 11000
            elif s_id == "STN_57": # Otogar
                weights[s_id] = 9200
            elif s_id == "STN_01": # Organize Sanayi
                weights[s_id] = 8800
            elif s_id == "STN_43": # İldem 5
                weights[s_id] = 8200
            elif s_id == "STN_55": # Talas Cemil Baba
                weights[s_id] = 7800
            elif s_id == "STN_75": # Anayurt İzzet Bayraktar
                weights[s_id] = 6800
            elif s_id == "STN_66": # Kumsmall AVM
                weights[s_id] = 4800
            elif s.get("type") == "corridor":
                weights[s_id] = 5600
            else:
                weights[s_id] = 2300
        return weights

    @staticmethod
    def time_to_seconds(time_str: str) -> int:
        clean_str = time_str.split("*")[0].strip()
        parts = [int(p) for p in clean_str.split(":")]
        if len(parts) == 2:
            return parts[0] * 3600 + parts[1] * 60
        elif len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        return 0

    @staticmethod
    def haversine_distance_km(lat1, lon1, lat2, lon2):
        r = 6371.0
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat / 2) ** 2 +
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
             math.sin(dlon / 2) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return r * c

    def _precompute_route_profiles(self):
        profiles = {}
        for r_key, route in self.routes.items():
            stops = route["stops"]
            total_duration_sec = route["total_travel_time_min"] * 60

            segment_dists = []
            total_dist = 0.0
            for i in range(len(stops) - 1):
                s1 = self.stations.get(stops[i])
                s2 = self.stations.get(stops[i + 1])
                if s1 and s2:
                    d = self.haversine_distance_km(s1["lat_wgs84"], s1["lon_wgs84"],
                                                  s2["lat_wgs84"], s2["lon_wgs84"])
                else:
                    d = 0.6
                segment_dists.append(d)
                total_dist += d

            cum_times_sec = [0.0]
            curr_time = 0.0
            for d in segment_dists:
                seg_time = (d / total_dist) * total_duration_sec if total_dist > 0 else (total_duration_sec / len(segment_dists))
                curr_time += seg_time
                cum_times_sec.append(curr_time)

            profiles[r_key] = {
                "stops": stops,
                "total_dist_km": total_dist,
                "total_duration_sec": total_duration_sec,
                "segment_dists": segment_dists,
                "cum_times_sec": cum_times_sec
            }
        return profiles


# ==============================================================================
# 2. FİZİK MOTORU & KAVİSLİ SPLINE / YAY-UZUNLUĞU ENTERPOLASYONU (PHYSICS ENGINE)
# ==============================================================================

STREET_CURVE_WAYPOINTS = {
    ("STN_02", "STN_03"): [(38.73815, 35.38410)],
    ("STN_03", "STN_04"): [(38.74160, 35.39015), (38.74340, 35.39110)],
    ("STN_04", "STN_05"): [(38.74380, 35.39610)],
    ("STN_05", "STN_06"): [(38.74160, 35.40180)],
    ("STN_07", "STN_08"): [(38.73780, 35.41430)],
    ("STN_08", "STN_09"): [(38.73470, 35.42110)],
    ("STN_09", "STN_10"): [(38.73338, 35.42750)],
    ("STN_11", "STN_12"): [(38.73065, 35.43880)],
    ("STN_13", "STN_14"): [(38.72845, 35.44935)],
    ("STN_17", "STN_18"): [(38.72210, 35.47610), (38.72125, 35.47890)],
    ("STN_18", "STN_19"): [(38.72095, 35.48360), (38.72135, 35.48540)],
    ("STN_19", "STN_20"): [(38.72235, 35.48980), (38.72285, 35.49150)],
    ("STN_21", "STN_22"): [(38.72585, 35.50260)],
    ("STN_23", "STN_24"): [(38.72965, 35.51585)],
    ("STN_26", "STN_27"): [(38.73560, 35.53380), (38.73695, 35.53550)],
    ("STN_27", "STN_28"): [(38.74070, 35.53985)],
    ("STN_31", "STN_32"): [(38.76150, 35.56210), (38.76420, 35.56370)],
    ("STN_32", "STN_33"): [(38.76810, 35.56620)],
    ("STN_35", "STN_36"): [(38.77775, 35.57780)],
    ("STN_36", "STN_37"): [(38.77905, 35.58520)],
    ("STN_38", "STN_39"): [(38.78115, 35.59860)],
    ("STN_39", "STN_40"): [(38.78330, 35.60330)],
    ("STN_24", "STN_44"): [(38.73110, 35.52180), (38.73125, 35.52320)],
    ("STN_44", "STN_45"): [(38.72910, 35.52515)],
    ("STN_45", "STN_46"): [(38.72380, 35.52715)],
    ("STN_46", "STN_47"): [(38.71730, 35.52975)],
    ("STN_47", "STN_48"): [(38.71100, 35.53110)],
    ("STN_48", "STN_49"): [(38.70580, 35.53010)],
    ("STN_49", "STN_50"): [(38.70195, 35.52800)],
    ("STN_50", "STN_51"): [(38.69850, 35.52950), (38.69780, 35.53180)],
    ("STN_51", "STN_52"): [(38.69650, 35.53680)],
    ("STN_54", "STN_55"): [(38.69080, 35.55230)],
    ("STN_06", "STN_56"): [(38.74185, 35.40230)],
    ("STN_56", "STN_57"): [(38.74570, 35.40280)],
    ("STN_57", "STN_58"): [(38.75150, 35.40635)],
    ("STN_58", "STN_59"): [(38.75740, 35.41030)],
    ("STN_59", "STN_60"): [(38.76235, 35.41255)],
    ("STN_62", "STN_63"): [(38.77685, 35.41255)],
    ("STN_63", "STN_64"): [(38.77890, 35.41580), (38.77800, 35.41760)],
    ("STN_64", "STN_65"): [(38.77510, 35.42250)],
    ("STN_65", "STN_66"): [(38.77460, 35.42890), (38.77610, 35.43070)],
    ("STN_45", "STN_67"): [(38.72430, 35.52720), (38.72240, 35.52810)],
    ("STN_67", "STN_68"): [(38.72135, 35.53380)],
    ("STN_68", "STN_69"): [(38.72055, 35.54300)],
    ("STN_69", "STN_70"): [(38.71950, 35.55150)],
    ("STN_70", "STN_71"): [(38.71620, 35.55610)],
    ("STN_72", "STN_73"): [(38.70885, 35.55940)],
    ("STN_73", "STN_74"): [(38.70760, 35.56390)],
    ("STN_74", "STN_75"): [(38.70450, 35.56605)]
}


def catmull_rom_subdivide(coords, subdivisions=5):
    """Koordinat listesini Catmull-Rom eğrisi ile yumuşatarak kavisli poligon üretir."""
    if len(coords) < 2:
        return coords
    if len(coords) == 2:
        return [
            (coords[0][0] + (coords[1][0] - coords[0][0]) * (s / subdivisions),
             coords[0][1] + (coords[1][1] - coords[0][1]) * (s / subdivisions))
            for s in range(subdivisions + 1)
        ]
    out = []
    for i in range(len(coords) - 1):
        p0 = coords[max(0, i - 1)]
        p1 = coords[i]
        p2 = coords[i + 1]
        p3 = coords[min(len(coords) - 1, i + 2)]
        for s in range(subdivisions):
            t = s / subdivisions
            t2 = t * t
            t3 = t2 * t
            lat = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
            lon = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
            out.append((lat, lon))
    out.append(coords[-1])
    return out


def get_pair_curved_points(stations_dict, stn_a_id, stn_b_id):
    """İki istasyon arasındaki cadde kurplarını ve Catmull-Rom ara noktalarını döndürür."""
    s1 = stations_dict.get(stn_a_id)
    s2 = stations_dict.get(stn_b_id)
    if not s1 or not s2:
        return []
    mids = STREET_CURVE_WAYPOINTS.get((stn_a_id, stn_b_id))
    if mids is None:
        rev = STREET_CURVE_WAYPOINTS.get((stn_b_id, stn_a_id))
        mids = list(reversed(rev)) if rev else []
    ctrl = [(s1["lat_wgs84"], s1["lon_wgs84"])] + list(mids) + [(s2["lat_wgs84"], s2["lon_wgs84"])]
    return catmull_rom_subdivide(ctrl, subdivisions=4)


def interpolate_along_polyline(pts, progress):
    """Kavisli poligon üzerinde yay uzunluğuna (arc-length) göre konum ve açı hesaplar."""
    if not pts:
        return 38.72189, 35.48732, 90.0
    if len(pts) == 1:
        return pts[0][0], pts[0][1], 90.0
    dists = [0.0]
    total = 0.0
    for i in range(len(pts) - 1):
        d = KayseriDataEngine.haversine_distance_km(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])
        total += d
        dists.append(total)
    if total <= 1e-7:
        return pts[0][0], pts[0][1], 90.0
    target = max(0.0, min(1.0, progress)) * total
    idx = 0
    for i in range(len(dists) - 1):
        if dists[i] <= target <= dists[i + 1]:
            idx = i
            break
    seg_len = dists[idx + 1] - dists[idx]
    local_t = (target - dists[idx]) / seg_len if seg_len > 1e-7 else 0.0
    lat = pts[idx][0] + local_t * (pts[idx + 1][0] - pts[idx][0])
    lon = pts[idx][1] + local_t * (pts[idx + 1][1] - pts[idx][1])
    bearing = TramPhysicsEngine.calculate_bearing(pts[idx][0], pts[idx][1], pts[idx + 1][0], pts[idx + 1][1])
    return lat, lon, bearing


class TramPhysicsEngine:
    def __init__(self, data_engine: KayseriDataEngine, day_profile_name: str = "Hafta İçi (Pzt-Cum)"):
        self.de = data_engine
        self.day_profile = DAY_PROFILES.get(day_profile_name, DAY_PROFILES["Hafta İçi (Pzt-Cum)"])

    @staticmethod
    def calculate_bearing(lat1, lon1, lat2, lon2):
        y = math.sin(math.radians(lon2 - lon1)) * math.cos(math.radians(lat2))
        x = (math.cos(math.radians(lat1)) * math.sin(math.radians(lat2)) -
             math.sin(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.cos(math.radians(lon2 - lon1)))
        bearing = math.degrees(math.atan2(y, x))
        return (bearing + 360) % 360

    def get_hourly_demand_multiplier(self, hour_float):
        scale = self.day_profile["demand_scale"]
        code = self.day_profile["code"]
        if code in ["SATURDAY", "SUNDAY"]:
            if 11.0 <= hour_float <= 19.0:
                return 1.55 * scale
            elif 9.0 <= hour_float < 11.0 or 19.0 < hour_float <= 21.5:
                return 1.05 * scale
            return 0.45 * scale
        else:
            if 7.0 <= hour_float <= 9.0:
                return 1.85 * scale
            elif 16.5 <= hour_float <= 19.0:
                return 1.95 * scale
            elif 11.5 <= hour_float <= 14.0:
                return 1.10 * scale
            elif 21.0 <= hour_float or hour_float <= 6.0:
                return 0.35 * scale
            return 0.80 * scale

    def get_active_trains_at_time(self, sim_time_seconds: int, selected_lines=None, t5_controller=None):
        if selected_lines is None:
            selected_lines = ["T1", "T2", "T3", "T4", "T5"]

        active_trains = []
        hour = sim_time_seconds / 3600.0
        demand_mult = self.get_hourly_demand_multiplier(hour)
        step_skip = 1 if self.day_profile["code"] == "WEEKDAY" else (2 if self.day_profile["code"] == "SUNDAY" else 1)

        # 1. Mevcut Hatlar (T1-T4)
        for r_key, route in self.de.routes.items():
            line_code = route["line_code"]
            if line_code not in selected_lines:
                continue

            timetable_departures = self.de.timetables.get(r_key, [])
            profile = self.de.route_station_profiles[r_key]
            total_duration_sec = profile["total_duration_sec"]
            stops = profile["stops"]
            cum_times = profile["cum_times_sec"]

            for trip_idx, dep_str in enumerate(timetable_departures):
                if step_skip > 1 and (trip_idx % step_skip != 0):
                    continue
                dep_sec = self.de.time_to_seconds(dep_str)
                arr_sec = dep_sec + total_duration_sec

                if dep_sec <= sim_time_seconds <= arr_sec:
                    elapsed_trip_sec = sim_time_seconds - dep_sec

                    seg_idx = 0
                    for i in range(len(cum_times) - 1):
                        if cum_times[i] <= elapsed_trip_sec <= cum_times[i + 1]:
                            seg_idx = i
                            break
                    else:
                        seg_idx = len(stops) - 2

                    t_start_seg = cum_times[seg_idx]
                    t_end_seg = cum_times[seg_idx + 1]
                    seg_duration = max(1.0, t_end_seg - t_start_seg)

                    progress = (elapsed_trip_sec - t_start_seg) / seg_duration
                    progress = max(0.0, min(1.0, progress))

                    stn_from = self.de.stations[stops[seg_idx]]
                    stn_to = self.de.stations[stops[seg_idx + 1]]

                    curved_pts = get_pair_curved_points(self.de.stations, stops[seg_idx], stops[seg_idx + 1])
                    curr_lat, curr_lon, bearing = interpolate_along_polyline(curved_pts, progress)

                    seg_dist_km = profile["segment_dists"][seg_idx]
                    speed_kmh = (seg_dist_km / (seg_duration / 3600.0)) if seg_duration > 0 else 23.0
                    eta_sec = int(t_end_seg - elapsed_trip_sec)

                    capacity = 309 if (trip_idx % 2 == 1) else 223
                    base_load = 45 + (demand_mult * 25)
                    load_factor = min(98, max(20, int(base_load + ((trip_idx * 7) % 15))))
                    passengers = int((load_factor / 100.0) * capacity)

                    active_trains.append({
                        "train_id": f"{line_code}-{trip_idx + 1:02d}",
                        "line": line_code,
                        "route_key": r_key,
                        "direction": route["direction_code"],
                        "direction_name": route["name"],
                        "origin_departure": dep_str,
                        "current_lat": curr_lat,
                        "current_lon": curr_lon,
                        "from_station": stn_from["station_name"],
                        "to_station": stn_to["station_name"],
                        "segment_progress_pct": round(progress * 100, 1),
                        "speed_kmh": round(speed_kmh, 1),
                        "bearing": round(bearing, 1),
                        "eta_next_station_sec": max(0, eta_sec),
                        "color": self.de.lines[line_code]["color"],
                        "passengers": passengers,
                        "capacity": capacity,
                        "load_factor_pct": load_factor,
                        "is_underground": False
                    })

        # 2. T5 Erkilet Aktif Trenleri
        if "T5" in selected_lines and t5_controller is not None:
            t5_trains = t5_controller.get_active_t5_trains(sim_time_seconds, demand_mult)
            active_trains.extend(t5_trains)

        return active_trains


# ==============================================================================
# 3. T5 ERKİLET KONTROLÖRÜ (DİNAMİK DURAK EKLEME/DÜZENLEME/ÇIKARMA DESTEKLİ)
# ==============================================================================

DEFAULT_T5_NODES = [
    {"id": "ERK_01", "name": "Kumsmall AVM (T3 Bağlantısı)", "lat": 38.77768, "lon": 35.43234, "surface": "surface", "pax_weight": 5500},
    {"id": "ERK_02", "name": "Mobilyakent Kuzey Kavşağı", "lat": 38.77950, "lon": 35.44600, "surface": "surface", "pax_weight": 3500},
    {"id": "ERK_02B", "name": "Erkilet 1. Etap Kavşağı", "lat": 38.78900, "lon": 35.46100, "surface": "surface", "pax_weight": 4200},
    {"id": "ERK_03", "name": "Bülbülpınarı / 100. Yıl", "lat": 38.80650, "lon": 35.47120, "surface": "surface", "pax_weight": 7000},
    {"id": "ERK_03B", "name": "Erkilet Yolu Tepe İnişi", "lat": 38.79950, "lon": 35.47050, "surface": "surface", "pax_weight": 4000},
    {"id": "ERK_04", "name": "Erkilet Merkez (Osmangazi)", "lat": 38.79150, "lon": 35.46950, "surface": "surface", "pax_weight": 8000},
    {"id": "ERK_05", "name": "Erkilet Bulvarı - Kumsmall Kavşağı", "lat": 38.77450, "lon": 35.47300, "surface": "surface", "pax_weight": 5500},
    {"id": "ERK_05B", "name": "Havalimanı Kılçık Ayrımı", "lat": 38.76650, "lon": 35.47520, "surface": "surface", "pax_weight": 4000},
    {"id": "ERK_06", "name": "Kayseri Havalimanı Yeni Terminali", "lat": 38.77348, "lon": 35.49468, "surface": "surface", "pax_weight": 9500},
    {"id": "ERK_06B", "name": "Havalimanı Çıkış Kurpu", "lat": 38.77180, "lon": 35.49100, "surface": "surface", "pax_weight": 3000},
    {"id": "ERK_07", "name": "Erkilet Bulvarı Katılım", "lat": 38.76400, "lon": 35.47550, "surface": "surface", "pax_weight": 3500},
    {"id": "ERK_07B", "name": "AGÜ Sümer Kampüsü Giriş", "lat": 38.74400, "lon": 35.47620, "surface": "surface", "pax_weight": 6500},
    {"id": "ERK_08", "name": "İl Emniyet / AGÜ Sümer (Tünel Girişi)", "lat": 38.73890, "lon": 35.47660, "surface": "tunnel", "pax_weight": 8500},
    {"id": "ERK_09", "name": "Kayseri Garı / Adalet Sarayı (Yer Altı)", "lat": 38.73150, "lon": 35.47950, "surface": "tunnel", "pax_weight": 11000},
    {"id": "ERK_10", "name": "Cumhuriyet Meydanı (Ana Yer Altı Hub)", "lat": 38.72189, "lon": 35.48715, "surface": "tunnel", "pax_weight": 25000},
    {"id": "ERK_11", "name": "Döner Kümbet / Seyyid Burhanettin", "lat": 38.71411, "lon": 35.49575, "surface": "tunnel", "pax_weight": 7500},
    {"id": "ERK_12", "name": "Millet Bahçesi (Güney Terminali)", "lat": 38.70383, "lon": 35.50939, "surface": "surface", "pax_weight": 8500}
]


class T5ErkiletController:
    def __init__(self, data_engine: KayseriDataEngine, headway_min=8, speed_kmh=28, custom_stations=None, base_nodes_override=None):
        self.de = data_engine
        self.headway_min = headway_min
        self.speed_kmh = speed_kmh
        self.color = "#FFD600"
        self.tunnel_color = "#00E5FF"

        base_nodes = [dict(n) for n in (base_nodes_override if base_nodes_override is not None else DEFAULT_T5_NODES)]
        self.nodes = base_nodes.copy()
        if custom_stations:
            for c_stn in custom_stations:
                best_idx = 1
                min_d = float('inf')
                for i in range(len(self.nodes) - 1):
                    d = (KayseriDataEngine.haversine_distance_km(self.nodes[i]["lat"], self.nodes[i]["lon"], c_stn["lat"], c_stn["lon"]) +
                         KayseriDataEngine.haversine_distance_km(c_stn["lat"], c_stn["lon"], self.nodes[i+1]["lat"], self.nodes[i+1]["lon"]))
                    if d < min_d:
                        min_d = d
                        best_idx = i + 1
                self.nodes.insert(best_idx, c_stn)

        self.route_length_km = 17.8 + (len(custom_stations) * 0.4 if custom_stations else 0)
        self.station_count = len(self.nodes)

    def calculate_optimization_metrics(self):
        dwell_time_total_min = (self.station_count * 25.0) / 60.0
        pure_run_time_min = (self.route_length_km / max(10.0, self.speed_kmh)) * 60.0
        one_way_time_min = round(pure_run_time_min + dwell_time_total_min)
        cycle_time_min = (one_way_time_min * 2) + 12

        active_trains_needed = math.ceil(cycle_time_min / max(1, self.headway_min))
        total_fleet_needed = math.ceil(active_trains_needed * 1.15)
        trips_per_day_dir = math.floor((18 * 60) / max(1, self.headway_min))
        total_daily_capacity = trips_per_day_dir * 2 * 296
        avg_wait_time_min = round(self.headway_min / 2.0, 1)

        return {
            "one_way_time_min": one_way_time_min,
            "cycle_time_min": cycle_time_min,
            "active_trains": active_trains_needed,
            "total_fleet": total_fleet_needed,
            "daily_capacity": total_daily_capacity,
            "avg_wait_time_min": avg_wait_time_min,
            "trips_per_day": trips_per_day_dir * 2
        }

    def get_active_t5_trains(self, sim_time_seconds, demand_mult):
        metrics = self.calculate_optimization_metrics()
        active_count = metrics["active_trains"]
        trains = []

        cycle_sec = metrics["cycle_time_min"] * 60
        outbound_nodes = self.nodes
        inbound_nodes = list(reversed(self.nodes))

        for i in range(active_count):
            train_id = f"T5-{i + 1:02d}"
            offset_sec = (i * (self.headway_min * 60))
            train_phase_sec = (sim_time_seconds + offset_sec) % cycle_sec

            half_cycle_sec = cycle_sec / 2.0
            if train_phase_sec < half_cycle_sec:
                node_list = outbound_nodes
                route_progress = train_phase_sec / half_cycle_sec
                dir_name = "Kumsmall → Havalimanı → Meydan → Millet Bahçesi"
                dir_code = "OUTBOUND"
            else:
                node_list = inbound_nodes
                route_progress = (train_phase_sec - half_cycle_sec) / half_cycle_sec
                dir_name = "Millet Bahçesi → Meydan → Havalimanı → Kumsmall"
                dir_code = "INBOUND"

            num_segments = max(1, len(node_list) - 1)
            exact_seg = route_progress * num_segments
            seg_idx = min(int(exact_seg), num_segments - 1)
            p = exact_seg - seg_idx

            n1 = node_list[seg_idx]
            n2 = node_list[seg_idx + 1]

            lat = n1["lat"] + p * (n2["lat"] - n1["lat"])
            lon = n1["lon"] + p * (n2["lon"] - n1["lon"])
            is_underground = (n1.get("surface") == "tunnel" and n2.get("surface") == "tunnel")

            bearing = TramPhysicsEngine.calculate_bearing(n1["lat"], n1["lon"], n2["lat"], n2["lon"])
            load_factor = min(98, max(25, int((demand_mult * 45) + ((i * 6) % 15))))

            trains.append({
                "train_id": train_id,
                "line": "T5",
                "route_key": f"T5_{dir_code}",
                "direction": dir_code,
                "direction_name": dir_name,
                "origin_departure": f"Ring Periyodu ({self.headway_min} dk)",
                "current_lat": lat,
                "current_lon": lon,
                "from_station": n1["name"],
                "to_station": n2["name"],
                "segment_progress_pct": round(p * 100, 1),
                "speed_kmh": round(self.speed_kmh, 1),
                "bearing": round(bearing, 1),
                "eta_next_station_sec": int((1 - p) * 120),
                "color": self.color,
                "passengers": int((load_factor / 100.0) * 296),
                "capacity": 296,
                "load_factor_pct": load_factor,
                "is_underground": is_underground
            })

        return trains


# ==============================================================================
# 4. DARBOĞAZ & YOLCU AKIŞ ANALİZCİSİ (BOTTLENECK & PASSENGER FLOW ANALYZER)
# ==============================================================================

class PassengerAndBottleneckAnalyzer:
    def __init__(self, data_engine: KayseriDataEngine, t5_controller: T5ErkiletController, day_profile_name: str = "Hafta İçi (Pzt-Cum)"):
        self.de = data_engine
        self.t5 = t5_controller
        self.day_profile_name = day_profile_name
        self.max_capacity_trains_per_hour = 60

    def analyze_hourly_throughput(self):
        hours = list(range(5, 24))
        hourly_counts = {h: {"T1": 0, "T2": 0, "T3": 0, "T4": 0, "T5": 0} for h in hours}

        for r_key, route in self.de.routes.items():
            line_code = route["line_code"]
            timetable = self.de.timetables.get(r_key, [])
            cum_times = self.de.route_station_profiles[r_key]["cum_times_sec"]
            stops = self.de.routes[r_key]["stops"]

            try:
                meydan_idx = stops.index("STN_19")
                meydan_offset_sec = cum_times[meydan_idx]
            except ValueError:
                meydan_offset_sec = 0

            for dep_str in timetable:
                dep_sec = self.de.time_to_seconds(dep_str)
                meydan_sec = dep_sec + meydan_offset_sec
                hour_val = int(meydan_sec // 3600)
                if hour_val in hourly_counts:
                    hourly_counts[hour_val][line_code] += 1

        t5_headway = max(1, self.t5.headway_min)
        t5_hourly_trains = math.floor((60.0 / t5_headway) * 2)

        results = []
        for h in hours:
            t5_effective = t5_hourly_trains if (6 <= h <= 23) else 0
            hourly_counts[h]["T5"] = t5_effective

            total_trains = (hourly_counts[h]["T1"] +
                            hourly_counts[h]["T2"] +
                            hourly_counts[h]["T3"] +
                            hourly_counts[h]["T4"] +
                            t5_effective)

            utilization_pct = round((total_trains / self.max_capacity_trains_per_hour) * 100, 1)
            is_overcapacity = total_trains > self.max_capacity_trains_per_hour

            results.append({
                "Saat Dilimi": f"{h:02d}:00 - {h+1:02d}:00",
                "Saat": h,
                "T1 (Tren/sa)": hourly_counts[h]["T1"],
                "T2 (Tren/sa)": hourly_counts[h]["T2"],
                "T3 (Tren/sa)": hourly_counts[h]["T3"],
                "T4 (Tren/sa)": hourly_counts[h]["T4"],
                "T5 Erkilet (Tren/sa)": t5_effective,
                "Toplam Meydan Geçişi": total_trains,
                "Kapasite Limiti": self.max_capacity_trains_per_hour,
                "Doluluk Oranı (%)": utilization_pct,
                "Durum": "🚨 Kapasite Aşımı" if is_overcapacity else "⚠️ Kritik Yoğunluk" if utilization_pct > 80 else "✅ Normal"
            })

        return pd.DataFrame(results)

    def get_station_boarding_flows(self, current_hour):
        physics = TramPhysicsEngine(self.de, self.day_profile_name)
        mult = physics.get_hourly_demand_multiplier(current_hour)

        boarding_list = []
        for s_id, s in self.de.stations.items():
            base_daily = self.de.station_demand_weights.get(s_id, 2200)
            hourly_pax = int((base_daily / 18.0) * mult)
            boarding_list.append({
                "İstasyon ID": s_id,
                "İstasyon Adı": s["station_name"],
                "Hatlar": ", ".join(s["lines_served"]),
                "Saatlik Biniş (Yolcu/sa)": hourly_pax,
                "Saatlik İniş (Yolcu/sa)": int(hourly_pax * 0.94),
                "Günlük Tahmini Hacim": base_daily,
                "İlçe": s["district"]
            })

        for node in self.t5.nodes:
            node_daily = node.get("pax_weight", 5000)
            hourly_pax = int((node_daily / 18.0) * mult)
            boarding_list.append({
                "İstasyon ID": node["id"],
                "İstasyon Adı": node["name"],
                "Hatlar": "T5 Erkilet",
                "Saatlik Biniş (Yolcu/sa)": hourly_pax,
                "Saatlik İniş (Yolcu/sa)": int(hourly_pax * 0.92),
                "Günlük Tahmini Hacim": node_daily,
                "İlçe": "Kocasinan/Melikgazi"
            })

        df = pd.DataFrame(boarding_list)
        return df.sort_values(by="Saatlik Biniş (Yolcu/sa)", ascending=False)


# ==============================================================================
# 5. GELİŞMİŞ RAMS ARIZA KATALOĞU & SL-TRAIN VİDEO TARZI MAPBOX HARİTASI
# ==============================================================================

INCIDENT_CATALOG = [
    {
        "id": "FAIL_CATENARY_01",
        "failure_id": "FAIL_CATENARY_01",
        "name": "Katener Aşınması / Gerilim Düşüşü",
        "category": "Altyapı / Enerji (Elektrifikasyon)",
        "severity": "Kritik",
        "severity_level": "Kritik",
        "mtbf_hours": 2400,
        "MTBF_hours": 2400,
        "typical_mttr_min": 90,
        "MTTR_minutes": 90,
        "affected_system": "750V DC Katener Seyir Teli & Pantoğraf Temas Hattı",
        "safety_protocol": "EN 50122 Topraklama & Karşı Raydan Kontrollü Tek Hat Mekik İşletimi",
        "dispatch_team_required": True,
        "line_impact": "Tek hat işletimi",
        "impact_type": "SINGLE_TRACK",
        "impact_title": "Alt Trafo Gerilim Düşüşü & Tek Hat İşletimi (MTTR: 90 dk)",
        "speed_limit_kmh": 0,
        "radius_km": 0.8,
        "crew": "Organize Sanayi Depo Katener Acil Müdahale Ekibi",
        "vehicle": "Unimog Ray-Karayolu Katener Platform Aracı (10 dk intikal)"
    },
    {
        "id": "FAIL_SWITCH_02",
        "failure_id": "FAIL_SWITCH_02",
        "name": "Makas Mekanizması Kilitlenme Arızası",
        "category": "Altyapı",
        "severity": "Kritik",
        "severity_level": "Kritik",
        "mtbf_hours": 1100,
        "MTBF_hours": 1100,
        "typical_mttr_min": 35,
        "MTTR_minutes": 35,
        "affected_system": "Elektro-Mekanik Makas Dil Kilidi & Konum Sensörü",
        "safety_protocol": "Mekanik Makas Kilit Pimi (Scotch Block) Uygulaması & Kırmızı Sinyal Koruması",
        "dispatch_team_required": True,
        "line_impact": "Bölgesel hat kesintisi",
        "impact_type": "STATION_CLOSURE",
        "impact_title": "Bölgesel Hat Kesintisi & Merkez Makas Kilitlenmesi (MTTR: 35 dk)",
        "speed_limit_kmh": 0,
        "radius_km": 0.5,
        "crew": "Tuna Altyapı & Makas Bakım Ekibi",
        "vehicle": "Mobil Hat Bakım Kamyoneti (6 dk intikal)"
    },
    {
        "id": "FAIL_SIGNAL_03",
        "failure_id": "FAIL_SIGNAL_03",
        "name": "Sinyalizasyon & Emniyet Röle Hatası",
        "category": "Emniyet / Sinyalizasyon",
        "severity": "Orta",
        "severity_level": "Orta",
        "mtbf_hours": 850,
        "MTBF_hours": 850,
        "typical_mttr_min": 20,
        "MTTR_minutes": 20,
        "affected_system": "ATP Anklaşman (Interlocking) & Ray Devresi Röle Grubu",
        "safety_protocol": "OCC Onaylı Görüş Mesafesiyle Seyir (On-Sight Driving - 20 km/s Kısıtı)",
        "dispatch_team_required": True,
        "line_impact": "Hız tahdidi (20 km/s kısıtı)",
        "impact_type": "SPEED_RESTRICTION",
        "impact_title": "Hız Tahdidi: 20 km/s Emniyetli Seyir Kısıtı (MTTR: 20 dk)",
        "speed_limit_kmh": 20,
        "radius_km": 1.4,
        "crew": "Trafik Kontrol Merkezi (OCC) Sinyalizasyon Ekibi",
        "vehicle": "Saha Elektronik Müdahale Aracı (4 dk intikal)"
    },
    {
        "id": "FAIL_DOOR_04",
        "failure_id": "FAIL_DOOR_04",
        "name": "Araç Kapı Emniyet Devresi Arızası",
        "category": "Araç",
        "severity": "Düşük",
        "severity_level": "Düşük",
        "mtbf_hours": 420,
        "MTBF_hours": 420,
        "typical_mttr_min": 15,
        "MTTR_minutes": 15,
        "affected_system": "Yolcu Kapısı Mikro-Switch & Fotosel Emniyet Çevrimi",
        "safety_protocol": "Kapı Mekanik İzolasyonu, Peronda Yolcu Tahliyesi & Depoya Çekilme",
        "dispatch_team_required": False,
        "line_impact": "Depoya çekilme",
        "impact_type": "DWELL_SURGE",
        "impact_title": "Peronda Kapı İzolasyonu & Depoya Çekilme (MTTR: 15 dk)",
        "speed_limit_kmh": 25,
        "radius_km": 0.3,
        "crew": "Hat Boyu Seyyar İstasyon Teknik Ekibi",
        "vehicle": "Yerel Müdahale / Yedek Dizi Sevki (2 dk)"
    },
    {
        "id": "FAIL_SUB_TRAFO_05",
        "failure_id": "FAIL_SUB_TRAFO_05",
        "name": "Trafo Emniyet Arızası",
        "category": "Enerji (Elektrifikasyon)",
        "severity": "Kritik",
        "severity_level": "Kritik",
        "mtbf_hours": 3100,
        "MTBF_hours": 3100,
        "typical_mttr_min": 45,
        "MTTR_minutes": 45,
        "affected_system": "154/34.5 kV - 750V DC Cer Trafo Merkezi Kesici & Buchholz Rölesi",
        "safety_protocol": "SCADA Üzerinden Komşu Trafo Merkezinden Kuplajlı Kısmi Besleme",
        "dispatch_team_required": True,
        "line_impact": "Kısmi besleme kesintisi",
        "impact_type": "SPEED_RESTRICTION",
        "impact_title": "Kısmi Besleme Kesintisi & Güç Kısıtlı İşletim (MTTR: 45 dk)",
        "speed_limit_kmh": 20,
        "radius_km": 1.6,
        "crew": "Yüksek Gerilim & Cer Gücü Trafo Bakım Ekibi",
        "vehicle": "SCADA Trafo Test ve Yüksek Gerilim Aracı (8 dk intikal)"
    }
]


def build_enhanced_folium_map(data_engine, active_trains, t5_controller, sim_time_str, current_hour, active_incident=None, day_profile_name="Hafta İçi (Pzt-Cum)"):
    """
    SL-TRAIN VİDEO TARZI MAPBOX HARİTASI (KAYSERİ UYARLAMASI):
    - Varsayılan Katman: Kullanıcının Mapbox API anahtarıyla çalışan `Mapbox Dark v11` koyu vektör haritası.
    - Koyu zemin üzerinde parlak neon ray koridorları (`T1` Kırmızı, `T2` Yeşil, `T3` Cyan, `T4` Mor, `T5` Altın).
    - İstasyonlar: Videodaki gibi beyaz dairesel halka düğümler + üzerinde renkli hat rozetleri (`[T1][T2][T5]`)
      ve peron yolcu yoğunluğu noktası (`<0.2` Mavi, `<0.5` Sarı, `<1.0` Turuncu, `>1.0` Kırmızı) bulunan koyu kapsül etiketler.
    """
    center_lat = 38.72189
    center_lon = 35.48732

    m = folium.Map(
        location=[center_lat, center_lon],
        zoom_start=13,
        tiles=None
    )

    # 1. SL-TRAIN VİDEO STİLİ MAPBOX DARK V11 (VARSAYILAN) + ALTERNATİF KATMANLAR
    folium.TileLayer(
        tiles=f"https://api.mapbox.com/styles/v1/mapbox/dark-v11/tiles/512/{{z}}/{{x}}/{{y}}@2x?access_token={MAPBOX_ACCESS_TOKEN}",
        attr="© Mapbox © OpenStreetMap",
        name="1. Mapbox Dark v11 (SL-Train Video Stili - Varsayılan)",
        tile_size=512,
        zoom_offset=-1,
        overlay=False,
        control=True
    ).add_to(m)

    folium.TileLayer(
        tiles=f"https://api.mapbox.com/styles/v1/mapbox/navigation-night-v1/tiles/512/{{z}}/{{x}}/{{y}}@2x?access_token={MAPBOX_ACCESS_TOKEN}",
        attr="© Mapbox Navigation Night",
        name="2. Mapbox Navigation Night (Gece Ulaşım)",
        tile_size=512,
        zoom_offset=-1,
        overlay=False,
        control=True
    ).add_to(m)

    folium.TileLayer(
        tiles="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
        attr="© OpenStreetMap © CARTO",
        name="3. CartoDB Dark Matter (Fallback Gece)",
        overlay=False,
        control=True
    ).add_to(m)

    folium.TileLayer(
        tiles="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
        attr="© OpenStreetMap © CARTO",
        name="4. CartoDB Voyager (Renkli Şehir)",
        overlay=False,
        control=True
    ).add_to(m)

    folium.TileLayer(
        tiles="https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}",
        attr="Google Maps Hybrid",
        name="5. Google Maps Hybrid (Uydu + Sokak)",
        overlay=False,
        control=True
    ).add_to(m)

    # 2. MEVCUT HATLARIN KAVİSLİ KORİDOR ÇİZGİLERİ (SL-Train Parlak Neon Stil)
    line_colors = {
        "T1": "#FF3355", # SL-Train Parlak Kırmızı/Mercan
        "T2": "#00E676", # Canlı Yeşil
        "T3": "#00E5FF", # Elektrik Cyan
        "T4": "#E040FB"  # Mor/Magenta
    }

    for l_code, col in line_colors.items():
        r_key = f"{l_code}_DEP" if f"{l_code}_DEP" in data_engine.routes else f"{l_code}_ARR"
        if r_key in data_engine.routes:
            stops_list = data_engine.routes[r_key]["stops"]
            pts = []
            for idx_s in range(len(stops_list) - 1):
                seg_pts = get_pair_curved_points(data_engine.stations, stops_list[idx_s], stops_list[idx_s + 1])
                if idx_s == 0:
                    pts.extend([[p[0], p[1]] for p in seg_pts])
                else:
                    pts.extend([[p[0], p[1]] for p in seg_pts[1:]])
            if len(pts) >= 2:
                # Alt hale (Glow Casing)
                folium.PolyLine(
                    locations=pts,
                    color=col,
                    weight=9,
                    opacity=0.22
                ).add_to(m)
                # Ana Parlak Ray Çizgisi
                folium.PolyLine(
                    locations=pts,
                    color=col,
                    weight=4.5,
                    opacity=0.95,
                    tooltip=f"Hat: {l_code} ({data_engine.lines[l_code]['official_line_name']})"
                ).add_to(m)

    # 3. T5 ERKİLET HATTI (Hemzemin: Parlak Altın/Yeşil / Tünel: Kesik Çizgili Neon Cyan)
    t5_nodes = t5_controller.nodes
    for i in range(len(t5_nodes) - 1):
        n1 = t5_nodes[i]
        n2 = t5_nodes[i + 1]
        pair_pts = [[n1["lat"], n1["lon"]], [n2["lat"], n2["lon"]]]
        is_tunnel_seg = (n1.get("surface") == "tunnel" and n2.get("surface") == "tunnel")

        if is_tunnel_seg:
            folium.PolyLine(
                locations=pair_pts,
                color="#00E5FF",
                weight=6,
                opacity=0.95,
                dash_array="8, 8",
                tooltip=f"T5 Erkilet 4 km Yer Altı Tüneli ({n1['name']} ↔ {n2['name']})"
            ).add_to(m)
        else:
            folium.PolyLine(
                locations=pair_pts,
                color="#FFD600",
                weight=9,
                opacity=0.22
            ).add_to(m)
            folium.PolyLine(
                locations=pair_pts,
                color="#FFD600",
                weight=5.0,
                opacity=0.95,
                tooltip=f"T5 Erkilet Koridoru ({n1['name']} ↔ {n2['name']})"
            ).add_to(m)

    # 4. DURAKLAR VE SL-TRAIN VİDEO STİLİ ROZETLİ KOYU KAPSÜL ETİKETLER
    physics = TramPhysicsEngine(data_engine, day_profile_name)
    demand_mult = physics.get_hourly_demand_multiplier(current_hour)

    badge_colors = {
        "T1": "#FF3355",
        "T2": "#00E676",
        "T3": "#00E5FF",
        "T4": "#E040FB",
        "T5": "#FFD600"
    }

    for stn_id, stn in data_engine.stations.items():
        is_hub = stn.get("is_hub", False) or stn_id in ["STN_19", "STN_24", "STN_06", "STN_45", "STN_61", "STN_48"]
        base_daily = data_engine.station_demand_weights.get(stn_id, 2200)
        hourly_boardings = int((base_daily / 18.0) * demand_mult)

        # SL-Train Yük Yoğunluğu Renk Kodu (<0.2 Mavi, <0.5 Sarı, <1.0 Turuncu, >1.0 Kırmızı)
        if hourly_boardings > 1200:
            p_color = "#EF4444"
            density_lbl = "> 1.0 yolcu/m² (Çok Yoğun)"
        elif hourly_boardings > 700:
            p_color = "#F97316"
            density_lbl = "0.5 - 1.0 yolcu/m² (Yoğun)"
        elif hourly_boardings > 350:
            p_color = "#FACC15"
            density_lbl = "0.2 - 0.5 yolcu/m² (Orta)"
        else:
            p_color = "#3B82F6"
            density_lbl = "< 0.2 yolcu/m² (Akıcı)"

        radius = 7.5 if is_hub else 5.0

        popup_html = f"""
        <div style="font-family: 'Segoe UI', Arial; font-size: 12px; width: 245px; color: #0f172a;">
            <b style="color: #0284c7; font-size: 14px;">🏛️ {stn['station_name']}</b><br>
            <b>İstasyon Kodu:</b> {stn['station_id']} ({stn['district']})<br>
            <b>Hatlar:</b> {', '.join(stn['lines_served'])}<br>
            <b>Peron Yoğunluğu:</b> <span style="color:{p_color}; font-weight:bold;">{density_lbl}</span><br>
            <b>Saatlik Biniş:</b> <b>{hourly_boardings:,} yolcu/saat</b><br>
            <b>Günlük Hacim:</b> ~{base_daily:,} yolcu/gün<br>
            <b>Peron Tipi:</b> {'SL-Train 3B Ada Peron + Üst Geçit Hub' if is_hub else 'Çift Hat Peron'}
        </div>
        """

        # SL-Train Beyaz Çemberli İstasyon Düğümü
        folium.CircleMarker(
            location=[stn["lat_wgs84"], stn["lon_wgs84"]],
            radius=radius,
            color="#FFFFFF",
            fill=True,
            fill_color="#0F172A" if not is_hub else p_color,
            fill_opacity=0.95,
            weight=2.5,
            popup=folium.Popup(popup_html, max_width=320)
        ).add_to(m)

        # SL-Train Koyu Kapsül Etiket + Renkli Hat Rozetleri ([T1][T2])
        badges_html = "".join([
            f"<span style='background:{badge_colors.get(l, '#38bdf8')}; color:{'#0f172a' if l in ['T2','T3','T5'] else '#fff'}; padding:1px 4px; border-radius:3px; font-size:8.5px; font-weight:800; margin-left:3px;'>{l}</span>"
            for l in stn["lines_served"]
        ])

        label_html = f"""
        <div style="
            font-size: 10px;
            font-weight: 700;
            color: #f8fafc;
            background: rgba(15, 23, 42, 0.92);
            padding: 3px 7px;
            border-radius: 6px;
            border: 1px solid {'#ffd600' if is_hub else 'rgba(255,255,255,0.35)'};
            width: max-content;
            max-width: 220px;
            white-space: normal;
            word-break: keep-all;
            line-height: 1.25;
            text-align: center;
            box-shadow: 0 3px 8px rgba(0,0,0,0.65);
            transform: translate(-50%, -115%);
            pointer-events: none;
        ">
            <span style="display:inline-block; width:7px; height:7px; border-radius:50%; background:{p_color}; margin-right:4px;"></span>{stn['station_name']}{badges_html}
        </div>
        """
        folium.Marker(
            location=[stn["lat_wgs84"], stn["lon_wgs84"]],
            icon=folium.DivIcon(html=label_html, icon_size=(200, 36), icon_anchor=(100, 36))
        ).add_to(m)

    # 5. T5 ERKİLET İSTASYONLARI (Yeni Eklenen & Düzenlenen Duraklar Dahil)
    for node in t5_nodes:
        is_custom = node.get("is_custom", False)
        is_tunnel = (node.get("surface") == "tunnel")
        node_color = "#F97316" if is_custom else ("#00E5FF" if is_tunnel else "#FFD600")
        node_hourly = int((node.get("pax_weight", 5000) / 18.0) * demand_mult)

        folium.CircleMarker(
            location=[node["lat"], node["lon"]],
            radius=8.5 if is_custom else 7.0,
            color="#FFFFFF",
            fill=True,
            fill_color=node_color,
            fill_opacity=1.0,
            weight=2.5,
            tooltip=f"{'⭐ YENİ EKLENEN DURAK: ' if is_custom else 'T5 İstasyonu: '}{node['name']} ({node_hourly} yolcu/sa)"
        ).add_to(m)

        t5_label_html = f"""
        <div style="
            font-size: 10px;
            font-weight: 800;
            color: #f8fafc;
            background: rgba(15, 23, 42, 0.94);
            padding: 3px 7px;
            border-radius: 6px;
            border: 1.5px solid {node_color};
            width: max-content;
            max-width: 220px;
            white-space: normal;
            line-height: 1.25;
            text-align: center;
            box-shadow: 0 3px 8px rgba(0,0,0,0.7);
            transform: translate(-50%, -115%);
            pointer-events: none;
        ">
            {'⭐ ' if is_custom else ''}{node['name']} <span style="background:#FFD600; color:#0f172a; padding:1px 4px; border-radius:3px; font-size:8.5px; font-weight:900;">T5</span>
        </div>
        """
        folium.Marker(
            location=[node["lat"], node["lon"]],
            icon=folium.DivIcon(html=t5_label_html, icon_size=(200, 36), icon_anchor=(100, 36))
        ).add_to(m)

    # 6. AKTİF TRAMVAYLAR (Harita Üzerinde Canlı Hareket Eden Yönlü Oklar)
    for train in active_trains:
        popup_train = f"""
        <div style="font-family: 'Segoe UI', Arial; font-size: 12px; width: 235px;">
            <div style="background-color: {train['color']}; color: #0f172a; padding: 4px 8px; font-weight: 800; border-radius: 4px;">
                🚋 {train['train_id']} — Hat: {train['line']}
            </div>
            <div style="margin-top: 6px;">
                <b>Güzergâh:</b> {train['direction_name']}<br>
                <b>Anlık Hız:</b> {train['speed_kmh']} km/sa<br>
                <b>Sonraki Durak:</b> {train['to_station']}<br>
                <b>Varışa Kalan:</b> {train['eta_next_station_sec']} saniye<br>
                <b>Yolcu:</b> {train['passengers']} / {train['capacity']} (%{train['load_factor_pct']})<br>
                <b>Kesim:</b> {'Yer Altı Tüneli (-18m)' if train.get('is_underground') else 'Hemzemin Ray'}
            </div>
        </div>
        """

        train_icon_html = f"""
        <div style="
            background-color: {train['color']};
            color: #0f172a;
            border: 2px solid #ffffff;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 900;
            box-shadow: 0 0 12px {train['color']};
            transform: rotate({train['bearing']}deg);
        ">
            ▲
        </div>
        """

        folium.Marker(
            location=[train["current_lat"], train["current_lon"]],
            icon=folium.DivIcon(html=train_icon_html, icon_size=(24, 24), icon_anchor=(12, 12)),
            popup=folium.Popup(popup_train, max_width=300),
            tooltip=f"{train['train_id']} ({train['line']}) → {train['to_station']} (%{train['load_factor_pct']} dolu)"
        ).add_to(m)

    # 7. AKTİF ARIZA BÖLGESİ (RAMS Simülasyonu)
    if active_incident:
        inc_lat = active_incident["lat"]
        inc_lon = active_incident["lon"]
        inc_radius = active_incident.get("radius_km", 0.8) * 1000

        folium.Circle(
            location=[inc_lat, inc_lon],
            radius=inc_radius,
            color="#EF4444",
            weight=3,
            fill=True,
            fill_color="#EF4444",
            fill_opacity=0.28,
            tooltip=f"🚨 ARIZA ETKİ BÖLGESİ: [{active_incident['failure_id']}] {active_incident['name']} ({active_incident['line_impact']})"
        ).add_to(m)

        incident_icon_html = """
        <div style="
            background: #EF4444;
            color: #ffffff;
            border: 2px solid #ffffff;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            box-shadow: 0 0 14px rgba(239,68,68,0.95);
        ">
            ⚠️
        </div>
        """
        folium.Marker(
            location=[inc_lat, inc_lon],
            icon=folium.DivIcon(html=incident_icon_html, icon_size=(32, 32), icon_anchor=(16, 16)),
            popup=folium.Popup(f"""
            <div style="font-family: Arial; font-size: 12px; width: 265px;">
                <b style="color: #EF4444; font-size: 13px;">🚨 [{active_incident['failure_id']}] {active_incident['name']}</b><br>
                <b>Kategori:</b> {active_incident['category']} ({active_incident['severity_level']})<br>
                <b>MTBF:</b> {active_incident['MTBF_hours']:,} saat | <b>MTTR:</b> {active_incident['MTTR_minutes']} dk<br>
                <b>Hat Etkisi:</b> <span style="color:#d97706; font-weight:bold;">{active_incident['line_impact']}</span><br>
                <b>Emniyet Protokolü:</b> {active_incident['safety_protocol']}<br>
                <b>Müdahale Ekibi:</b> {active_incident['crew']}
            </div>
            """, max_width=290)
        ).add_to(m)

    folium.LayerControl(position="topright").add_to(m)
    return m


# ==============================================================================
# 6. ANA STREAMLIT ARAYÜZÜ (TÜM BARLAR, METRİKLER VE 5 SEKME)
# ==============================================================================

def main():
    st.set_page_config(
        page_title="Kayseray Dijital İkizi & T5 Entegrasyonu",
        page_icon="🚋",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    # --- SESSION STATE (DİNAMİK T5 DURAKLARININ KALICILIĞI) ---
    if "t5_custom_stations" not in st.session_state:
        st.session_state["t5_custom_stations"] = []
    if "t5_base_nodes" not in st.session_state:
        st.session_state["t5_base_nodes"] = [dict(n) for n in DEFAULT_T5_NODES]

    st.markdown("""
        <style>
        .main-header {
            background: linear-gradient(135deg, #091322 0%, #1e293b 100%);
            padding: 16px 24px;
            border-radius: 12px;
            border: 1px solid rgba(56, 189, 248, 0.25);
            color: white;
            margin-bottom: 16px;
        }
        .metric-card {
            background: #0f172a;
            border: 1px solid #1e293b;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
        }
        </style>
    """, unsafe_allow_html=True)

    st.markdown("""
        <div class="main-header">
            <h2 style="margin: 0; padding: 0;">🚋 KAYSERAY DİJİTAL İKİZİ: DİNAMİK OPERASYON VE T5 ERKİLET ENTEGRASYONU</h2>
            <p style="margin: 4px 0 0 0; color: #38bdf8; font-size: 13px;">
                Doğrulanmış 75 İstasyonlu T1-T4 Hatları + Planlanan T5 Erkilet Güzergâhı (SL-Train Mapbox Dark v11 Haritası, Hafta Sonu Zaman Modeli & RAMS Backlogu)
            </p>
        </div>
    """, unsafe_allow_html=True)

    try:
        data_engine = KayseriDataEngine()
    except Exception as e:
        st.error(f"Veri tabanı yüklenemedi: {e}")
        return

    # --- SIDEBAR: KONTROLLER ---
    with st.sidebar:
        st.header("🎛️ Simülasyon Kumandası")

        # 1. Simülasyon Saati ve Gün Profili (Hafta İçi / Cumartesi / Pazar)
        st.subheader("1. Zaman & Gün Profili")
        day_profile_name = st.selectbox(
            "Gün Bazlı Tarife Profili:",
            list(DAY_PROFILES.keys()),
            index=0
        )
        preset = st.selectbox(
            "Hızlı Zaman Dilimi Seç:",
            ["Sabah Piki (08:15)", "Öğle Durgun (12:30)", "Akşam Piki (17:45)", "Gece (22:15)", "Manuel Zaman"]
        )
        h_def, m_def = 8, 15
        if preset == "Sabah Piki (08:15)": h_def, m_def = 8, 15
        elif preset == "Öğle Durgun (12:30)": h_def, m_def = 12, 30
        elif preset == "Akşam Piki (17:45)": h_def, m_def = 17, 45
        elif preset == "Gece (22:15)": h_def, m_def = 22, 15

        sim_time_input = st.slider(
            "Günün Saatini Kaydır:",
            min_value=time(5, 0),
            max_value=time(23, 59),
            value=time(h_def, m_def),
            step=pd.Timedelta(minutes=1)
        )
        sim_seconds = sim_time_input.hour * 3600 + sim_time_input.minute * 60
        curr_hour = sim_time_input.hour

        st.divider()

        # 2. T5 Erkilet Parametreleri
        st.subheader("2. T5 Erkilet Planlama")
        enable_t5 = st.toggle("T5 Erkilet Hattı Aktif", value=True)
        base_hw = st.slider("Sefer Sıklığı (Headway - dk):", min_value=4, max_value=20, value=8, step=1)
        t5_headway = max(4, int(round(base_hw * DAY_PROFILES[day_profile_name]["headway_mult"])))
        t5_speed = st.slider("İşletme Hızı (km/sa):", min_value=18, max_value=45, value=28, step=1)

        t5_controller = T5ErkiletController(
            data_engine,
            headway_min=t5_headway,
            speed_kmh=t5_speed,
            custom_stations=st.session_state["t5_custom_stations"],
            base_nodes_override=st.session_state["t5_base_nodes"]
        )

        st.divider()

        # 3. MEVCUT T5 DURAĞINI DÜZENLE / SİL VEYA YENİ DURAK EKLE
        st.subheader("3. 🛠️ T5 Dinamik Durak Yönetimi")
        with st.expander("✏️ Mevcut T5 Durağını Düzenle / Sil", expanded=False):
            all_t5_names = [f"{n['name']} ({n.get('pax_weight', 5000)}/gün)" for n in st.session_state["t5_base_nodes"]]
            if all_t5_names:
                edit_idx = st.selectbox("Düzenlenecek T5 Durağı:", range(len(all_t5_names)), format_func=lambda i: all_t5_names[i])
                sel_node = st.session_state["t5_base_nodes"][edit_idx]
                ed_name = st.text_input("Durak Adı:", value=sel_node["name"], key="ed_t5_name")
                c_e1, c_e2 = st.columns(2)
                with c_e1:
                    ed_lat = st.number_input("Enlem:", value=float(sel_node["lat"]), format="%.5f", key="ed_t5_lat")
                with c_e2:
                    ed_lon = st.number_input("Boylam:", value=float(sel_node["lon"]), format="%.5f", key="ed_t5_lon")
                ed_pax = st.number_input("Günlük Yolcu Yoğunluğu:", value=int(sel_node.get("pax_weight", 5000)), step=500, key="ed_t5_pax")
                b_col1, b_col2 = st.columns(2)
                with b_col1:
                    if st.button("💾 Kaydet", use_container_width=True):
                        st.session_state["t5_base_nodes"][edit_idx].update({
                            "name": ed_name.strip() or sel_node["name"],
                            "lat": float(ed_lat),
                            "lon": float(ed_lon),
                            "pax_weight": int(ed_pax)
                        })
                        st.rerun()
                with b_col2:
                    if len(st.session_state["t5_base_nodes"]) > 2 and st.button("🗑️ Durağı Sil", use_container_width=True):
                        st.session_state["t5_base_nodes"].pop(edit_idx)
                        st.rerun()

        with st.form("add_station_form", clear_on_submit=True):
            st.markdown("**➕ T5 Hattına Yeni Durak Ekle**")
            new_stn_name = st.text_input("Yeni İstasyon Adı:", placeholder="Örn: Erkilet Çevre Yolu")
            col_geo1, col_geo2 = st.columns(2)
            with col_geo1:
                new_lat = st.number_input("Enlem (Lat):", value=38.7845, min_value=38.65, max_value=38.85, format="%.5f")
            with col_geo2:
                new_lon = st.number_input("Boylam (Lon):", value=35.4715, min_value=35.35, max_value=35.65, format="%.5f")
            new_surface = st.selectbox("İstasyon Tipi:", ["Hemzemin Yüzey", "Yer Altı Tüneli (-18m)"])
            new_pax = st.number_input("Beklenen Günlük Yolcu:", value=4500, step=500)
            btn_add = st.form_submit_button("Durağı Hatta Kaydet")

            if btn_add and new_stn_name.strip():
                new_id = f"ERK_CUSTOM_{len(st.session_state['t5_custom_stations']) + 1:02d}"
                st.session_state["t5_custom_stations"].append({
                    "id": new_id,
                    "name": new_stn_name.strip(),
                    "lat": float(new_lat),
                    "lon": float(new_lon),
                    "surface": "tunnel" if "Tünel" in new_surface else "surface",
                    "pax_weight": int(new_pax),
                    "is_custom": True
                })
                st.success(f"✅ '{new_stn_name}' durağı T5 hattına eklendi ve haritaya işlendi!")
                st.rerun()

        if st.session_state["t5_custom_stations"]:
            st.caption(f"Eklenen Yeni Duraklar ({len(st.session_state['t5_custom_stations'])} adet):")
            for idx, c_stn in enumerate(st.session_state["t5_custom_stations"]):
                c_col1, c_col2 = st.columns([4, 1])
                with c_col1:
                    st.write(f"⭐ **{c_stn['name']}** ({c_stn['surface']})")
                with c_col2:
                    if st.button("Sil", key=f"del_stn_{idx}"):
                        st.session_state["t5_custom_stations"].pop(idx)
                        st.rerun()

        st.divider()

        # 4. Hat Filtresi
        st.subheader("4. Hat Görünürlük Filtresi")
        selected_lines = []
        c1, c2 = st.columns(2)
        with c1:
            if st.checkbox("T1 (İldem-OSB)", value=True): selected_lines.append("T1")
            if st.checkbox("T2 (Talas-Meydan)", value=True): selected_lines.append("T2")
        with c2:
            if st.checkbox("T3 (Kumsmall-İldem)", value=True): selected_lines.append("T3")
            if st.checkbox("T4 (Anayurt-Meydan)", value=True): selected_lines.append("T4")
        if enable_t5:
            selected_lines.append("T5")

        st.divider()

        # 5. Gelişmiş Arıza & RAMS Bakım Simülatörü
        st.subheader("5. ⚠️ Arıza & RAMS Simülatörü")
        enable_incident = st.toggle("🚨 Arıza Simülasyonunu Başlat", value=False)
        active_inc_data = None

        if enable_incident:
            inc_names = [f"[{i['severity_level']}] {i['name']} ({i['MTTR_minutes']} dk)" for i in INCIDENT_CATALOG]
            sel_inc_idx = st.selectbox("Arıza Sınıfı Seç:", range(len(INCIDENT_CATALOG)), format_func=lambda x: inc_names[x])
            sel_inc_tpl = INCIDENT_CATALOG[sel_inc_idx]

            stn_keys = list(data_engine.stations.keys())
            stn_names = [f"{data_engine.stations[k]['station_id']} - {data_engine.stations[k]['station_name']}" for k in stn_keys]
            meydan_idx = stn_keys.index("STN_19") if "STN_19" in stn_keys else 0
            sel_stn_idx = st.selectbox("Arıza Bölgesi İstasyon:", range(len(stn_keys)), index=meydan_idx, format_func=lambda x: stn_names[x])
            sel_stn_obj = data_engine.stations[stn_keys[sel_stn_idx]]

            active_inc_data = {
                **sel_inc_tpl,
                "station_id": sel_stn_obj["station_id"],
                "station_name": sel_stn_obj["station_name"],
                "lat": sel_stn_obj["lat_wgs84"],
                "lon": sel_stn_obj["lon_wgs84"]
            }

            st.markdown(f"""
            <div style="font-size:11px; background:rgba(239,68,68,0.15); border:1px solid #ef4444; border-radius:6px; padding:8px; margin-top:6px;">
                <b>Kod / Kategori:</b> {sel_inc_tpl['failure_id']} ({sel_inc_tpl['category']})<br>
                <b>MTBF:</b> {sel_inc_tpl['MTBF_hours']:,} sa | <b>MTTR:</b> {sel_inc_tpl['MTTR_minutes']} dk<br>
                <b>Hat Etkisi:</b> <span style="color:#fbbf24; font-weight:bold;">{sel_inc_tpl['line_impact']}</span><br>
                <b>Protokol:</b> {sel_inc_tpl['safety_protocol']}
            </div>
            """, unsafe_allow_html=True)

    # Fizik Motoru ile Aktif Trenleri Hesapla
    physics_engine = TramPhysicsEngine(data_engine, day_profile_name)
    active_trains = physics_engine.get_active_trains_at_time(
        sim_time_seconds=sim_seconds,
        selected_lines=selected_lines,
        t5_controller=t5_controller if enable_t5 else None
    )

    # Arıza Etkisini Trenlere Yansıt
    if active_inc_data:
        for t in active_trains:
            d_km = KayseriDataEngine.haversine_distance_km(t["current_lat"], t["current_lon"], active_inc_data["lat"], active_inc_data["lon"])
            if d_km <= active_inc_data["radius_km"]:
                if active_inc_data["impact_type"] in ["SINGLE_TRACK", "STATION_CLOSURE"]:
                    t["speed_kmh"] = 0
                    t["speed_status"] = "🚨 BLOKE (Arıza)"
                elif active_inc_data["impact_type"] == "SPEED_RESTRICTION":
                    t["speed_kmh"] = min(t["speed_kmh"], active_inc_data["speed_limit_kmh"])
                    t["speed_status"] = f"⚠️ Hız Kısıtı ({active_inc_data['speed_limit_kmh']} km/sa)"

    analyzer = PassengerAndBottleneckAnalyzer(data_engine, t5_controller, day_profile_name)
    df_bottleneck = analyzer.analyze_hourly_throughput()
    df_boarding_flows = analyzer.get_station_boarding_flows(curr_hour)

    # --- ÜST KPI METRİK KARTLARI ---
    col_m1, col_m2, col_m3, col_m4, col_m5 = st.columns(5)
    with col_m1:
        st.metric("Simülasyon Saati", f"{sim_time_input.strftime('%H:%M:00')} ({DAY_PROFILES[day_profile_name]['code']})")
    with col_m2:
        st.metric("Hattaki Aktif Trenler", f"{len(active_trains)} dizi")
    with col_m3:
        total_pax = sum(t["passengers"] for t in active_trains)
        st.metric("Anlık Yolcu Hacmi", f"{total_pax:,} yolcu")
    with col_m4:
        avg_load = int(sum(t["load_factor_pct"] for t in active_trains) / max(1, len(active_trains)))
        st.metric("Filo Doluluk Oranı", f"%{avg_load}")
    with col_m5:
        t5_metrics = t5_controller.calculate_optimization_metrics()
        st.metric("T5 Filo İhtiyacı", f"{t5_metrics['total_fleet']} tren" if enable_t5 else "Devre Dışı")

    # --- SEKME DÜZENİ ---
    tab_map, tab_passenger_flow, tab_bottleneck, tab_t5_opt, tab_trains_table = st.tabs([
        "🗺️ Canlı Kayseri Haritası (SL-Train Mapbox Dark v11)",
        "📊 Peron Yolcu Biniş / İniş Akış Grafiği",
        "⚠️ Cumhuriyet Meydanı Darboğaz Analizi",
        "🚄 T5 Erkilet Planlama & Filo Optimizasyonu",
        "📋 Aktif Tramvay Telemetri & RAMS Backlogu"
    ])

    # --------------------------------------------------------------------------
    # TAB 1: SL-TRAIN VİDEO TARZI MAPBOX HARİTASI
    # --------------------------------------------------------------------------
    with tab_map:
        st.subheader("Kayseri Raylı Sistem Ağı — SL-Train Tarzı Mapbox Dark v11 Dijital İkiz Haritası")
        st.markdown("""
        <div style="display:flex; align-items:center; justify-content:space-between; background:#0f172a; color:#e2e8f0; padding:8px 14px; border-radius:8px; margin-bottom:10px; font-size:12px; border:1px solid rgba(56,189,248,0.3);">
            <span>🗺️ <b>Altlık:</b> Mapbox Dark v11 (Aktif) — Durak etiketlerinde hizmet veren hat rozetleri (<b>T1-T5</b>) ve canlı peron yoğunluk noktaları yer alır.</span>
            <span>
                <b>Peron Yük Yoğunluğu (Yolcu/m²):</b>
                <span style="color:#3b82f6; font-weight:bold; margin-left:6px;">● &lt; 0.2</span>
                <span style="color:#facc15; font-weight:bold; margin-left:6px;">● &lt; 0.5</span>
                <span style="color:#f97316; font-weight:bold; margin-left:6px;">● &lt; 1.0</span>
                <span style="color:#ef4444; font-weight:bold; margin-left:6px;">● &gt; 1.0</span>
            </span>
        </div>
        """, unsafe_allow_html=True)

        if active_inc_data:
            st.error(f"🚨 **AKTİF ARIZA VE MÜDAHALE DURUMU:** [{active_inc_data['failure_id']}] {active_inc_data['name']} ({active_inc_data['station_name']}) — **Hat Etkisi:** {active_inc_data['line_impact']} | **Emniyet Protokolü:** {active_inc_data['safety_protocol']} | **MTTR:** {active_inc_data['MTTR_minutes']} dakika")

        folium_map = build_enhanced_folium_map(
            data_engine=data_engine,
            active_trains=active_trains,
            t5_controller=t5_controller,
            sim_time_str=sim_time_input.strftime("%H:%M:00"),
            current_hour=curr_hour,
            active_incident=active_inc_data,
            day_profile_name=day_profile_name
        )

        if HAS_ST_FOLIUM:
            st_folium(folium_map, width="100%", height=680, returned_objects=[])
        else:
            components.html(folium_map._repr_html_(), height=680)

    # --------------------------------------------------------------------------
    # TAB 2: PERON BAZLI YOLCU BİNİŞ/İNİŞ AKIŞ GRAFİĞİ
    # --------------------------------------------------------------------------
    with tab_passenger_flow:
        st.subheader(f"Saat {curr_hour:02d}:00 İtibarıyla İstasyon Peron Yolcu Biniş & İniş Dağılımı ({day_profile_name})")
        st.markdown("""
        Bu grafik, seçtiğiniz simülasyon saatindeki ve gün profilindeki kentsel hareketlilik katsayısına göre istasyon peronlarındaki **saatlik yolcu biniş ve iniş akışını** göstermektedir.
        """)

        col_g1, col_g2 = st.columns([7, 3])
        with col_g1:
            top_15_stations = df_boarding_flows.head(15).set_index("İstasyon Adı")[["Saatlik Biniş (Yolcu/sa)", "Saatlik İniş (Yolcu/sa)"]]
            st.bar_chart(top_15_stations, use_container_width=True)

        with col_g2:
            st.markdown("#### 🏆 En Yoğun 5 İstasyon")
            for idx, r in df_boarding_flows.head(5).iterrows():
                st.write(f"**{r['İstasyon Adı']}**: `{r['Saatlik Biniş (Yolcu/sa)']:,} yolcu/sa`")
            st.caption("Kırmızı işaretli duraklar saatlik 1.200 yolcunun üzerinde biniş alan kritik düğümlerdir.")

        st.dataframe(df_boarding_flows, use_container_width=True, hide_index=True)

    # --------------------------------------------------------------------------
    # TAB 3: DARBOĞAZ VE KAPASİTE ANALİZİ
    # --------------------------------------------------------------------------
    with tab_bottleneck:
        st.subheader("Cumhuriyet Meydanı (Merkez Düğüm) Saatlik Kapasite & Yığılma Analizi")
        st.markdown("""
        Cumhuriyet Meydanı (`STN_19`), T1, T2, T3, T4 ve planlanan T5 Erkilet hatlarının tamamının buluştuğu ana düğümdür.
        T2 ve T4 trenleri batı makasında kafa değiştirdiği için **emniyetli sinyalizasyon kapasitesi saatte azami 60 trendir**.
        """)

        chart_data = df_bottleneck.set_index("Saat Dilimi")[["T1 (Tren/sa)", "T2 (Tren/sa)", "T3 (Tren/sa)", "T4 (Tren/sa)", "T5 Erkilet (Tren/sa)"]]
        st.bar_chart(chart_data, use_container_width=True)

        row_now = df_bottleneck[df_bottleneck["Saat"] == curr_hour].iloc[0]
        b_c1, b_c2, b_c3 = st.columns(3)
        with b_c1:
            st.metric(f"Saat {curr_hour:02d}:00 Toplam Tren", f"{row_now['Toplam Meydan Geçişi']} tren/saat")
        with b_c2:
            st.metric("Kapasite Doluluk Oranı", f"%{row_now['Doluluk Oranı (%)']}")
        with b_c3:
            st.metric("Durum", row_now["Durum"])

        if row_now["Toplam Meydan Geçişi"] > 60:
            st.error(f"🚨 **KAPASİTE AŞIMI:** Saat {curr_hour:02d}:00'de Meydan'a giren tren sayısı ({row_now['Toplam Meydan Geçişi']} tren), saatlik 60 trenlik güvenli makas kapasitesini aşmaktadır!")
        else:
            st.success(f"✅ Saat {curr_hour:02d}:00'de Cumhuriyet Meydanı sinyalizasyon kapasitesi yeterlidir (%{row_now['Doluluk Oranı (%)']} kullanım).")

        st.dataframe(df_bottleneck[["Saat Dilimi", "Toplam Meydan Geçişi", "Kapasite Limiti", "Doluluk Oranı (%)", "Durum"]], use_container_width=True, hide_index=True)

    # --------------------------------------------------------------------------
    # TAB 4: T5 ERKİLET PLANLAMA MODELİ
    # --------------------------------------------------------------------------
    with tab_t5_opt:
        st.subheader("T5 Erkilet Hattı Matematiksel Planlama & Filo Optimizasyonu")
        st.markdown(f"""
        **Mevcut T5 Hat Konfigürasyonu:**
        - **Toplam İstasyon Sayısı:** {t5_controller.station_count} İstasyon ({len(st.session_state['t5_custom_stations'])} adet kullanıcı tarafından eklendi)
        - **Hat Uzunluğu:** {t5_controller.route_length_km:.1f} km (4 km Yeraltı Tüneli dahil)
        - **Sefer Sıklığı (Efektif Headway):** {t5_controller.headway_min} dakika ({day_profile_name})
        - **İşletme Hızı:** {t5_controller.speed_kmh} km/sa
        """)

        opt_c1, opt_c2 = st.columns(2)
        with opt_c1:
            st.markdown("### 🧮 Vuchic / TCRP 100 Matematiksel Formülleri")
            st.latex(r"T_{\text{tek\_yön}} = \left(\frac{L}{V_{\text{ticari}}}\right) \cdot 60 + \frac{N_{\text{durak}} \cdot t_{\text{dwell}}}{60}")
            st.latex(r"T_{\text{cycle}} = 2 \cdot T_{\text{tek\_yön}} + 2 \cdot t_{\text{layover}}")
            st.latex(r"N_{\text{aktif}} = \left\lceil \frac{T_{\text{cycle}}}{H} \right\rceil, \quad N_{\text{filo}} = \left\lceil N_{\text{aktif}} \cdot 1.15 \right\rceil")

        with opt_c2:
            st.markdown("### 📊 Hesaplanan Mühendislik Çıktıları")
            st.write(f"- **Tek Yön Seyahat Süresi:** **{t5_metrics['one_way_time_min']} dakika**")
            st.write(f"- **Tam Ring Çevrim Süresi ($T_{{cycle}}$):** **{t5_metrics['cycle_time_min']} dakika**")
            st.write(f"- **Gereken Aktif Tren Sayısı:** **{t5_metrics['active_trains']} araç dizisi**")
            st.write(f"- **Toplam Filo İhtiyacı (%15 Rezervle):** **{t5_metrics['total_fleet']} araç**")
            st.write(f"- **Günlük Sefer Sayısı:** **{t5_metrics['trips_per_day']} sefer/gün**")
            st.write(f"- **Günlük Taşıma Kapasitesi:** **{t5_metrics['daily_capacity']:,} yolcu/gün**")
            st.write(f"- **Ortalama Yolcu Bekleme Süresi:** **{t5_metrics['avg_wait_time_min']} dakika**")

    # --------------------------------------------------------------------------
    # TAB 5: TELEMETRİ TABLOSU & RAMS ARIZA BACKLOGU
    # --------------------------------------------------------------------------
    with tab_trains_table:
        st.subheader(f"Saat {sim_time_input.strftime('%H:%M')} İtibarıyla Aktif Tramvay Telemetrisi")
        if active_trains:
            df_active = pd.DataFrame(active_trains)
            disp_cols = [
                "train_id", "line", "direction_name", "from_station", "to_station",
                "segment_progress_pct", "speed_kmh", "current_lat", "current_lon",
                "eta_next_station_sec", "passengers", "load_factor_pct"
            ]
            df_disp = df_active[disp_cols].rename(columns={
                "train_id": "Tren ID",
                "line": "Hat",
                "direction_name": "Sefer Yönü",
                "from_station": "Önceki Durak",
                "to_station": "Sonraki Durak",
                "segment_progress_pct": "İlerleme (%)",
                "speed_kmh": "Hız (km/sa)",
                "current_lat": "Enlem (Lat)",
                "current_lon": "Boylam (Lon)",
                "eta_next_station_sec": "Varışa Kalan (sn)",
                "passengers": "Yolcu Sayısı",
                "load_factor_pct": "Doluluk (%)"
            })
            st.dataframe(df_disp, use_container_width=True, hide_index=True)
        else:
            st.info("Bu saatte aktif çalışan tramvay bulunmamaktadır.")

        st.markdown("#### 🛠️ Endüstriyel Arıza, Emniyet ve Bakım Simülatörü Backlogu (RAMS Meta Veri Modeli)")
        df_rams = pd.DataFrame(INCIDENT_CATALOG)[[
            "failure_id", "category", "name", "MTBF_hours", "MTTR_minutes",
            "severity_level", "affected_system", "safety_protocol", "dispatch_team_required", "line_impact"
        ]]
        st.dataframe(df_rams, use_container_width=True, hide_index=True)

    st.markdown("---")
    st.caption("Kayseray Dijital İkizi © 2026 · Kayseri Büyükşehir Belediyesi Ulaşım A.Ş. Açık Veri Modeli")


if __name__ == "__main__":
    main()
