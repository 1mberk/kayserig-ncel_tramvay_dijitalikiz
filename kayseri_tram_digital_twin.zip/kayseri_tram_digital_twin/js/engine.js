/**
 * Kayseri Tramvay Dijital İkiz — Simülasyon & Fizik Motoru (V4 Konsolide 3D Harita & Dinamik Hat/Bakım Motoru)
 * - Coğrafi Poligon / Catmull-Rom Spline Tabanlı Ray Enterpolasyonu (T1, T2, T3, T4, T5 ve Kullanıcı Tanımlı Yeni Hatlar)
 * - Dinamik Erkilet (T5) İstasyon Yönetimi: Durak Ekleme, Silme, İsim/Koordinat/Yolcu Yoğunluğu Düzenleme ve Reaktif Isı Haritası
 * - Gün Bazlı Zaman Modeli (Hafta İçi, Cumartesi, Pazar) Sefer Frekansı (Headway) ve Saatlik Yolcu Talep Eğrileri
 * - Endüstriyel RAMS Arıza & Bakım Backlogu (failure_id, category, MTBF_hours, MTTR_minutes, safety_protocol, dispatch_team_required, line_impact)
 */

class TramDigitalTwinEngine {
  constructor(data) {
    this.data = data;
    this.simTimeSeconds = 8 * 3600 + 15 * 60; // Başlangıç: 08:15:00
    this.timeScale = 1; // 1x, 5x, 15x, 60x, 0
    this.dayType = "WEEKDAY"; // WEEKDAY | SATURDAY | SUNDAY
    this.activeTrains = [];
    this.stationMap = {};
    this.activeIncidents = [];
    this.customLines = []; // Kullanıcının dinamik eklediği ek hatlar
    this.listeners = [];
    this.topologyListeners = [];

    // Bakım Üssü (Depot) Koordinatları
    this.depotLocations = {
      "OSB_DEPOT": { name: "Organize Sanayi Raylı Sistem Bakım Merkezi", lat: 38.738327, lon: 35.3685284 },
      "TUNA_DEPOT": { name: "Tuna İstasyon Sahası Bakım Üssü", lat: 38.7306315, lon: 35.5193112 },
      "OCC_CENTER": { name: "Kayseri Ulaşım A.Ş. OCC Kumanda Merkezi", lat: 38.7246807, lon: 35.4984378 },
      "ILDEM_DEPOT": { name: "İldem Tramvay Depo ve Atölye Sahası", lat: 38.7869555, lon: 35.6254264 }
    };

    // T5 Erkilet Parametreleri
    this.erkiletConfig = {
      active: true,
      visible: true,
      scenario: "scenario_a",
      headwayMinutes: 8,
      commercialSpeed: 28,
      dwellTimeSec: 25,
      customStations: []
    };

    this.routePolylineMap = {};
    this.routeSegmentArcMap = {};

    this.initStationMap();
    this.initCorridorPolylines();
    this.initFleet();
  }

  getActiveDayProfile() {
    const profiles = this.data.day_profiles || {};
    return profiles[this.dayType] || profiles["WEEKDAY"] || {
      id: "WEEKDAY",
      label: "Hafta İçi (Pzt-Cum)",
      fleet_multiplier: 1.0,
      headway_multiplier: 1.0,
      demand_scale: 1.0,
      hourly_curve: Array(24).fill(0.75)
    };
  }

  getHourlyDemandMultiplier(hourFloat = null) {
    const h = hourFloat !== null ? hourFloat : (this.simTimeSeconds / 3600);
    const profile = this.getActiveDayProfile();
    const idx = Math.max(0, Math.min(23, Math.floor(h)));
    const nextIdx = (idx + 1) % 24;
    const frac = h - Math.floor(h);
    const c1 = profile.hourly_curve[idx] || 0.5;
    const c2 = profile.hourly_curve[nextIdx] || 0.5;
    return (c1 + (c2 - c1) * frac) * (profile.demand_scale || 1.0);
  }

  setDayType(dayType) {
    if (!["WEEKDAY", "SATURDAY", "SUNDAY"].includes(dayType)) return;
    this.dayType = dayType;
    // Sefer sıklıklarını ve aktif araç sayısını gün profiline göre yeniden örnekle
    this.initFleet();
    this.notifyTopologyListeners();
    this.notifyListeners();
  }

  initStationMap() {
    this.data.stations.forEach(stn => {
      const isHub = stn.id === "STN_19" || stn.id === "STN_24" || stn.id === "STN_06" || stn.id === "STN_45" || stn.id === "STN_61";
      this.stationMap[stn.id] = {
        ...stn,
        waitingPax: Math.round(isHub ? 135 : 42),
        platformCapacity: isHub ? 750 : 280,
        hourlyDemandBase: isHub ? 2850 : (stn.lines.length > 1 ? 1450 : 650),
        occupancyPct: isHub ? 52 : 28,
        lastBoarding: Math.round(isHub ? 28 : 11),
        lastAlighting: Math.round(isHub ? 24 : 9),
        totalBoardedToday: Math.round(isHub ? 4200 : 1150),
        totalAlightedToday: Math.round(isHub ? 3950 : 1080),
        activeDwell: null
      };
    });

    const erkScenarios = ["scenario_a", "scenario_b"];
    erkScenarios.forEach(sc => {
      if (this.data.erkilet_nodes && this.data.erkilet_nodes[sc]) {
        this.data.erkilet_nodes[sc].forEach(node => {
          const isHub = node.type === "central_hub" || node.type === "airport_spur" || node.type === "airport";
          this.stationMap[node.id] = {
            id: node.id,
            code: node.id.replace("ERK_", ""),
            name: node.name,
            lat: node.lat,
            lon: node.lon,
            type: node.type,
            district: "Kocasinan / Melikgazi",
            lines: ["T5", sc === "scenario_a" ? "T5-A" : "T5-B"],
            is_tunnel: node.surface === "tunnel",
            surface: node.surface,
            isStop: true,
            waitingPax: Math.round(isHub ? 96 : 48),
            platformCapacity: isHub ? 600 : 350,
            hourlyDemandBase: isHub ? 2200 : 1150,
            occupancyPct: isHub ? 48 : 30,
            lastBoarding: Math.round(isHub ? 22 : 12),
            lastAlighting: Math.round(isHub ? 19 : 10),
            totalBoardedToday: Math.round(isHub ? 3100 : 1400),
            totalAlightedToday: Math.round(isHub ? 2900 : 1320),
            activeDwell: null
          };
        });
      }
    });
  }

  initStreetCurveWaypoints() {
    this.pairWaypoints = {
      "STN_02->STN_03": [{ lat: 38.73815, lon: 35.38410 }],
      "STN_03->STN_04": [{ lat: 38.74160, lon: 35.39015 }, { lat: 38.74340, lon: 35.39110 }],
      "STN_04->STN_05": [{ lat: 38.74380, lon: 35.39610 }],
      "STN_05->STN_06": [{ lat: 38.74160, lon: 35.40180 }],
      "STN_07->STN_08": [{ lat: 38.73780, lon: 35.41430 }],
      "STN_08->STN_09": [{ lat: 38.73470, lon: 35.42110 }],
      "STN_09->STN_10": [{ lat: 38.73338, lon: 35.42750 }],
      "STN_11->STN_12": [{ lat: 38.73065, lon: 35.43880 }],
      "STN_13->STN_14": [{ lat: 38.72845, lon: 35.44935 }],
      "STN_17->STN_18": [{ lat: 38.72210, lon: 35.47610 }, { lat: 38.72125, lon: 35.47890 }],
      "STN_18->STN_19": [{ lat: 38.72095, lon: 35.48360 }, { lat: 38.72135, lon: 35.48540 }],
      "STN_19->STN_20": [{ lat: 38.72235, lon: 35.48980 }, { lat: 38.72285, lon: 35.49150 }],
      "STN_21->STN_22": [{ lat: 38.72585, lon: 35.50260 }],
      "STN_23->STN_24": [{ lat: 38.72965, lon: 35.51585 }],
      "STN_26->STN_27": [{ lat: 38.73560, lon: 35.53380 }, { lat: 38.73695, lon: 35.53550 }],
      "STN_27->STN_28": [{ lat: 38.74070, lon: 35.53985 }],
      "STN_31->STN_32": [{ lat: 38.76150, lon: 35.56210 }, { lat: 38.76420, lon: 35.56370 }],
      "STN_32->STN_33": [{ lat: 38.76810, lon: 35.56620 }],
      "STN_35->STN_36": [{ lat: 38.77775, lon: 35.57780 }],
      "STN_36->STN_37": [{ lat: 38.77905, lon: 35.58520 }],
      "STN_38->STN_39": [{ lat: 38.78115, lon: 35.59860 }],
      "STN_39->STN_40": [{ lat: 38.78330, lon: 35.60330 }],
      "STN_24->STN_44": [{ lat: 38.73110, lon: 35.52180 }, { lat: 38.73125, lon: 35.52320 }],
      "STN_44->STN_45": [{ lat: 38.72910, lon: 35.52515 }],
      "STN_45->STN_46": [{ lat: 38.72380, lon: 35.52715 }],
      "STN_46->STN_47": [{ lat: 38.71730, lon: 35.52975 }],
      "STN_47->STN_48": [{ lat: 38.71100, lon: 35.53110 }],
      "STN_48->STN_49": [{ lat: 38.70580, lon: 35.53010 }],
      "STN_49->STN_50": [{ lat: 38.70195, lon: 35.52800 }],
      "STN_50->STN_51": [{ lat: 38.69850, lon: 35.52950 }, { lat: 38.69780, lon: 35.53180 }],
      "STN_51->STN_52": [{ lat: 38.69650, lon: 35.53680 }],
      "STN_54->STN_55": [{ lat: 38.69080, lon: 35.55230 }],
      "STN_06->STN_56": [{ lat: 38.74185, lon: 35.40230 }],
      "STN_56->STN_57": [{ lat: 38.74570, lon: 35.40280 }],
      "STN_57->STN_58": [{ lat: 38.75150, lon: 35.40635 }],
      "STN_58->STN_59": [{ lat: 38.75740, lon: 35.41030 }],
      "STN_59->STN_60": [{ lat: 38.76235, lon: 35.41255 }],
      "STN_62->STN_63": [{ lat: 38.77685, lon: 35.41255 }],
      "STN_63->STN_64": [{ lat: 38.77890, lon: 35.41580 }, { lat: 38.77800, lon: 35.41760 }],
      "STN_64->STN_65": [{ lat: 38.77510, lon: 35.42250 }],
      "STN_65->STN_66": [{ lat: 38.77460, lon: 35.42890 }, { lat: 38.77610, lon: 35.43070 }],
      "STN_45->STN_67": [{ lat: 38.72430, lon: 35.52720 }, { lat: 38.72240, lon: 35.52810 }],
      "STN_67->STN_68": [{ lat: 38.72135, lon: 35.53380 }],
      "STN_68->STN_69": [{ lat: 38.72055, lon: 35.54300 }],
      "STN_69->STN_70": [{ lat: 38.71950, lon: 35.55150 }],
      "STN_70->STN_71": [{ lat: 38.71620, lon: 35.55610 }],
      "STN_72->STN_73": [{ lat: 38.70885, lon: 35.55940 }],
      "STN_73->STN_74": [{ lat: 38.70760, lon: 35.56390 }],
      "STN_74->STN_75": [{ lat: 38.70450, lon: 35.56605 }]
    };
  }

  subdivideCatmullRom(points, subdivisionsPerSegment = 6) {
    if (!points || points.length < 2) return points || [];
    if (points.length === 2) {
      const res = [];
      for (let s = 0; s <= subdivisionsPerSegment; s++) {
        const t = s / subdivisionsPerSegment;
        res.push({
          lat: points[0].lat + (points[1].lat - points[0].lat) * t,
          lon: points[0].lon + (points[1].lon - points[0].lon) * t,
          surface: points[0].surface || points[1].surface || "surface"
        });
      }
      return res;
    }

    const result = [];
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[Math.max(0, i - 1)];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[Math.min(points.length - 1, i + 2)];

      for (let s = 0; s < subdivisionsPerSegment; s++) {
        const t = s / subdivisionsPerSegment;
        const t2 = t * t;
        const t3 = t2 * t;

        const lat = 0.5 * (
          (2 * p1.lat) +
          (-p0.lat + p2.lat) * t +
          (2 * p0.lat - 5 * p1.lat + 4 * p2.lat - p3.lat) * t2 +
          (-p0.lat + 3 * p1.lat - 3 * p2.lat + p3.lat) * t3
        );
        const lon = 0.5 * (
          (2 * p1.lon) +
          (-p0.lon + p2.lon) * t +
          (2 * p0.lon - 5 * p1.lon + 4 * p2.lon - p3.lon) * t2 +
          (-p0.lon + 3 * p1.lon - 3 * p2.lon + p3.lon) * t3
        );

        result.push({
          lat,
          lon,
          surface: (p1.surface === "tunnel" && p2.surface === "tunnel") ? "tunnel" : (p1.surface || "surface"),
          isStop: s === 0 ? !!p1.isStop : false,
          stnId: s === 0 ? (p1.id || p1.stnId) : null
        });
      }
    }
    const last = points[points.length - 1];
    result.push({
      lat: last.lat,
      lon: last.lon,
      surface: last.surface || "surface",
      isStop: !!last.isStop,
      stnId: last.id || last.stnId || null
    });
    return result;
  }

  getPairSubPath(stnIdA, stnIdB) {
    const sA = this.stationMap[stnIdA];
    const sB = this.stationMap[stnIdB];
    if (!sA || !sB) return [];

    const forwardKey = `${stnIdA}->${stnIdB}`;
    const reverseKey = `${stnIdB}->${stnIdA}`;
    let mids = [];
    if (this.pairWaypoints[forwardKey]) {
      mids = this.pairWaypoints[forwardKey];
    } else if (this.pairWaypoints[reverseKey]) {
      mids = [...this.pairWaypoints[reverseKey]].reverse();
    }

    const rawControlPoints = [
      { lat: sA.lat, lon: sA.lon, stnId: sA.id, isStop: true, surface: sA.surface || "surface" },
      ...mids.map(m => ({ lat: m.lat, lon: m.lon, isStop: false, surface: m.surface || "surface" })),
      { lat: sB.lat, lon: sB.lon, stnId: sB.id, isStop: true, surface: sB.surface || "surface" }
    ];

    return this.subdivideCatmullRom(rawControlPoints, 5);
  }

  initCorridorPolylines() {
    this.initStreetCurveWaypoints();

    this.corridorCurves = {
      "ERK_CORRIDOR_A": [
        { lat: 38.77768, lon: 35.43234, name: "Kumsmall AVM Bağlantısı", id: "STN_66", isStop: true, surface: "surface" },
        { lat: 38.77640, lon: 35.44250, name: "Kuzey Çevre Yolu Kavşağı", isStop: false, surface: "surface" },
        { lat: 38.77950, lon: 35.45350, name: "Mobilyakent Kuzey", isStop: false, surface: "surface" },
        { lat: 38.79100, lon: 35.46350, name: "Erkilet Yolu Batı Kurpu", isStop: false, surface: "surface" },
        { lat: 38.80650, lon: 35.47120, name: "Bülbülpınarı / 100. Yıl", id: "ERK_A_01", isStop: true, surface: "surface" },
        { lat: 38.79950, lon: 35.47050, name: "Erkilet Yolu Tepe İnişi", isStop: false, surface: "surface" },
        { lat: 38.79150, lon: 35.46950, name: "Erkilet Merkez / Osmangazi", id: "ERK_A_02", isStop: true, surface: "surface" },
        { lat: 38.78250, lon: 35.47120, name: "Erkilet Bulvarı Orta Aks", isStop: false, surface: "surface" },
        { lat: 38.77450, lon: 35.47300, name: "Erkilet Bulvarı - Kumsmall Kavşağı", id: "ERK_A_03", isStop: true, surface: "surface" },
        { lat: 38.76650, lon: 35.47520, name: "Havalimanı Kılçık Ayrımı", isStop: false, surface: "surface" },
        { lat: 38.76950, lon: 35.48480, name: "Havalimanı Bulvarı Giriş", isStop: false, surface: "surface" },
        { lat: 38.77348, lon: 35.49468, name: "Havalimanı Kılçık İstasyonu", id: "ERK_A_04", isStop: true, surface: "surface" },
        { lat: 38.76980, lon: 35.48520, name: "Terminal Çıkış Kurpu", isStop: false, surface: "surface" },
        { lat: 38.76400, lon: 35.47550, name: "Mustafa Kemal Paşa Katılım", isStop: false, surface: "surface" },
        { lat: 38.75250, lon: 35.47580, name: "Kocasinan Bulvarı Kavşağı", isStop: false, surface: "surface" },
        { lat: 38.74400, lon: 35.47620, name: "AGÜ Sümer Kampüsü Yaklaşımı", isStop: false, surface: "surface" },
        { lat: 38.73890, lon: 35.47660, name: "İl Emniyet / AGÜ Sümer (Tünel Giriş)", id: "ERK_A_05", isStop: true, surface: "tunnel" },
        { lat: 38.73500, lon: 35.47800, name: "Gar Yaklaşım Tüneli", isStop: false, surface: "tunnel" },
        { lat: 38.73150, lon: 35.47950, name: "Kayseri Garı / Adalet Sarayı (Yer Altı)", id: "ERK_A_06", isStop: true, surface: "tunnel" },
        { lat: 38.72650, lon: 35.48320, name: "İstasyon Cad. Tünel Eğrisi", isStop: false, surface: "tunnel" },
        { lat: 38.72189, lon: 35.48715, name: "Cumhuriyet Meydanı (Yer Altı Aktarma)", id: "ERK_A_07", isStop: true, surface: "tunnel" },
        { lat: 38.71800, lon: 35.49150, name: "Meydan Güney Tünel Kurpu", isStop: false, surface: "tunnel" },
        { lat: 38.71411, lon: 35.49575, name: "Döner Kümbet / Seyyid Burhanettin", id: "ERK_A_08", isStop: true, surface: "tunnel" },
        { lat: 38.70850, lon: 35.50300, name: "Talas Bulvarı Güney Portal", isStop: false, surface: "surface" },
        { lat: 38.70383, lon: 35.50939, name: "Millet Bahçesi (Güney Terminali)", id: "ERK_A_09", isStop: true, surface: "surface" }
      ],
      "ERK_CORRIDOR_B": [
        { lat: 38.80650, lon: 35.47120, name: "Bülbülpınarı (Kuzey Uç)", id: "ERK_B_01", isStop: true, surface: "surface" },
        { lat: 38.79150, lon: 35.47300, name: "Erkilet Doğu Aksı", isStop: false, surface: "surface" },
        { lat: 38.78100, lon: 35.48400, name: "Kuzey Havalimanı Kurpu", isStop: false, surface: "surface" },
        { lat: 38.77348, lon: 35.49468, name: "Kayseri Havalimanı (Doğrudan Geçiş)", id: "ERK_B_02", isStop: true, surface: "surface" },
        { lat: 38.75800, lon: 35.48500, name: "Havalimanı Güney Bağlantısı", isStop: false, surface: "surface" },
        { lat: 38.73885, lon: 35.47454, name: "Abdullah Gül Üniversitesi (AGÜ)", id: "ERK_B_03", isStop: true, surface: "tunnel" },
        { lat: 38.73100, lon: 35.48000, name: "İstasyon Caddesi Tüneli", isStop: false, surface: "tunnel" },
        { lat: 38.72189, lon: 35.48715, name: "Cumhuriyet Meydanı (Aktarma Düğümü)", id: "ERK_B_04", isStop: true, surface: "tunnel" },
        { lat: 38.71300, lon: 35.49700, name: "Kartal Kavşağı Yaklaşımı", isStop: false, surface: "surface" },
        { lat: 38.70383, lon: 35.50939, name: "Millet Bahçesi (Güney Uç)", id: "ERK_B_05", isStop: true, surface: "surface" }
      ]
    };

    this.precomputeRoutePaths();
  }

  // Tüm hatlar (T1-T4, T5-A, T5-B ve Yeni Eklenen Hatlar) için kavisli poligon ve yay tablolarını oluşturur
  precomputeRoutePaths() {
    this.routePolylineMap = {};
    this.routeSegmentArcMap = {};

    // 1. T1 - T4 Mevcut Rotalar
    Object.keys(this.data.routes).forEach(routeKey => {
      const route = this.data.routes[routeKey];
      const stopIds = route.stops;
      const fullDensePoints = [];
      const segmentArcList = [];

      for (let i = 0; i < stopIds.length - 1; i++) {
        const subPts = this.getPairSubPath(stopIds[i], stopIds[i + 1]);
        const segArc = this.buildArcLengthTable(subPts);
        segmentArcList.push(segArc);

        if (i === 0) {
          fullDensePoints.push(...subPts);
        } else {
          fullDensePoints.push(...subPts.slice(1));
        }
      }

      this.routePolylineMap[routeKey] = fullDensePoints;
      this.routeSegmentArcMap[routeKey] = segmentArcList;
    });

    // 2. T5 Erkilet Aktif Senaryo Poligonunu stationMap'teki güncel koordinatlarla senkronize et ve yoğunlaştır
    const activeCorridorKey = this.erkiletConfig.scenario === "scenario_b" ? "ERK_CORRIDOR_B" : "ERK_CORRIDOR_A";
    const baseErkNodes = this.corridorCurves[activeCorridorKey];

    // Eğer durak stationMap'te güncellendiyse koridor düğümünü de senkronize et
    baseErkNodes.forEach(node => {
      if (node.id && this.stationMap[node.id]) {
        node.lat = this.stationMap[node.id].lat;
        node.lon = this.stationMap[node.id].lon;
        node.name = this.stationMap[node.id].name;
        node.surface = this.stationMap[node.id].surface || node.surface;
      }
    });

    const denseErkOut = this.subdivideCatmullRom(baseErkNodes, 5);
    const denseErkIn = [...denseErkOut].reverse();

    // HOTFIX: Hem T5_OUT / T5_IN hem de T5-A / T5-B / T5 anahtarlarını besle ki hiçbir katmanda yeni hat eksik kalmasın
    this.routePolylineMap["T5_OUT"] = denseErkOut;
    this.routePolylineMap["T5_IN"] = denseErkIn;
    this.routePolylineMap["T5"] = denseErkOut;
    this.routePolylineMap["T5-A"] = this.subdivideCatmullRom(this.corridorCurves["ERK_CORRIDOR_A"], 5);
    this.routePolylineMap["T5-B"] = this.subdivideCatmullRom(this.corridorCurves["ERK_CORRIDOR_B"], 5);

    const t5OutSegments = [];
    for (let i = 0; i < baseErkNodes.length - 1; i++) {
      const pts = [];
      const p0 = baseErkNodes[Math.max(0, i - 1)];
      const p1 = baseErkNodes[i];
      const p2 = baseErkNodes[i + 1];
      const p3 = baseErkNodes[Math.min(baseErkNodes.length - 1, i + 2)];
      for (let s = 0; s <= 6; s++) {
        const t = s / 6;
        const t2 = t * t;
        const t3 = t2 * t;
        const lat = 0.5 * ((2 * p1.lat) + (-p0.lat + p2.lat) * t + (2 * p0.lat - 5 * p1.lat + 4 * p2.lat - p3.lat) * t2 + (-p0.lat + 3 * p1.lat - 3 * p2.lat + p3.lat) * t3);
        const lon = 0.5 * ((2 * p1.lon) + (-p0.lon + p2.lon) * t + (2 * p0.lon - 5 * p1.lon + 4 * p2.lon - p3.lon) * t2 + (-p0.lon + 3 * p1.lon - 3 * p2.lon + p3.lon) * t3);
        pts.push({ lat, lon, surface: (p1.surface === "tunnel" || p2.surface === "tunnel") ? "tunnel" : "surface" });
      }
      t5OutSegments.push(this.buildArcLengthTable(pts));
    }
    this.routeSegmentArcMap["T5_OUT"] = t5OutSegments;
    this.routeSegmentArcMap["T5_IN"] = [...t5OutSegments].reverse().map(seg => {
      const revPts = [...seg.points].reverse();
      return this.buildArcLengthTable(revPts);
    });

    // 3. Kullanıcının Dinamik Eklediği Yeni Hatlar (Custom Lines)
    this.customLines.forEach(cLine => {
      if (cLine.nodes && cLine.nodes.length >= 2) {
        const denseCustom = this.subdivideCatmullRom(cLine.nodes, 5);
        this.routePolylineMap[cLine.routeKeyOut] = denseCustom;
        this.routePolylineMap[cLine.routeKeyIn] = [...denseCustom].reverse();
        this.routePolylineMap[cLine.code] = denseCustom;

        const segsOut = [];
        for (let i = 0; i < cLine.nodes.length - 1; i++) {
          const sub = this.subdivideCatmullRom([
            cLine.nodes[Math.max(0, i - 1)],
            cLine.nodes[i],
            cLine.nodes[i + 1],
            cLine.nodes[Math.min(cLine.nodes.length - 1, i + 2)]
          ].slice(1, 3), 5);
          segsOut.push(this.buildArcLengthTable(sub));
        }
        this.routeSegmentArcMap[cLine.routeKeyOut] = segsOut;
        this.routeSegmentArcMap[cLine.routeKeyIn] = [...segsOut].reverse().map(s => this.buildArcLengthTable([...s.points].reverse()));
      }
    });
  }

  buildArcLengthTable(points) {
    const cumDist = [0];
    let totalKm = 0;
    for (let i = 0; i < points.length - 1; i++) {
      const d = this.distanceKm(points[i].lat, points[i].lon, points[i + 1].lat, points[i + 1].lon);
      totalKm += d;
      cumDist.push(totalKm);
    }
    return {
      points,
      cumDist,
      totalKm: Math.max(0.005, totalKm)
    };
  }

  sampleArcSegment(arcTable, progress) {
    if (!arcTable || !arcTable.points || arcTable.points.length === 0) {
      return { lat: 38.72189, lon: 35.48732, bearing: 90 };
    }
    const pts = arcTable.points;
    if (pts.length === 1) {
      return { lat: pts[0].lat, lon: pts[0].lon, bearing: 90 };
    }
    const clamped = Math.max(0, Math.min(1, progress));
    const targetDist = clamped * arcTable.totalKm;

    let idx = 0;
    for (let i = 0; i < arcTable.cumDist.length - 1; i++) {
      if (targetDist >= arcTable.cumDist[i] && targetDist <= arcTable.cumDist[i + 1]) {
        idx = i;
        break;
      }
    }
    const d0 = arcTable.cumDist[idx];
    const d1 = arcTable.cumDist[idx + 1];
    const localT = (d1 - d0) > 1e-6 ? (targetDist - d0) / (d1 - d0) : 0;

    const a = pts[idx];
    const b = pts[idx + 1] || pts[idx];
    const lat = a.lat + (b.lat - a.lat) * localT;
    const lon = a.lon + (b.lon - a.lon) * localT;
    const bearing = this.calculateBearing(a, b);
    return { lat, lon, bearing, surface: a.surface };
  }

  initFleet() {
    this.activeTrains = [];
    const profile = this.getActiveDayProfile();
    const fMult = profile.fleet_multiplier || 1.0;

    // Seçilen güne (Hafta İçi / Cumartesi / Pazar) göre dinamik filo büyüklüğü
    this.spawnTrainsForRoute("T1", "T1_DEP", Math.max(4, Math.round(11 * fMult)), "#FF3366");
    this.spawnTrainsForRoute("T1", "T1_ARR", Math.max(4, Math.round(11 * fMult)), "#FF3366");

    this.spawnTrainsForRoute("T2", "T2_DEP", Math.max(2, Math.round(3 * fMult)), "#00E676");
    this.spawnTrainsForRoute("T2", "T2_ARR", Math.max(2, Math.round(3 * fMult)), "#00E676");

    this.spawnTrainsForRoute("T3", "T3_DEP", Math.max(3, Math.round(6 * fMult)), "#00E5FF");
    this.spawnTrainsForRoute("T3", "T3_ARR", Math.max(3, Math.round(6 * fMult)), "#00E5FF");

    this.spawnTrainsForRoute("T4", "T4_DEP", Math.max(2, Math.round(3 * fMult)), "#E040FB");
    this.spawnTrainsForRoute("T4", "T4_ARR", Math.max(2, Math.round(3 * fMult)), "#E040FB");

    // T5 Erkilet Trenleri
    this.spawnErkiletTrains();

    // Kullanıcı Tanımlı Yeni Hatların Trenleri
    this.spawnCustomLineTrains();
  }

  spawnTrainsForRoute(lineCode, routeKey, count, color) {
    const route = this.data.routes[routeKey];
    if (!route || !route.stops || route.stops.length < 2) return;
    const arcSegments = this.routeSegmentArcMap[routeKey] || [];
    const demandMult = this.getHourlyDemandMultiplier();

    for (let i = 0; i < count; i++) {
      const suffix = route.direction === "ARRIVAL" ? "B" : "A";
      const trainId = `${lineCode}-${(i + 1).toString().padStart(2, "0")}${suffix}`;
      const isSirio = (i % 2 === 0);
      const initialProgress = i / count;
      const totalStops = route.stops.length;
      const initialStopIndex = Math.min(Math.floor(initialProgress * (totalStops - 1)), totalStops - 2);
      const segmentProgress = (initialProgress * (totalStops - 1)) - initialStopIndex;

      const fromStn = this.stationMap[route.stops[initialStopIndex]];
      const toStn = this.stationMap[route.stops[initialStopIndex + 1]];
      const sampled = arcSegments[initialStopIndex]
        ? this.sampleArcSegment(arcSegments[initialStopIndex], segmentProgress)
        : {
            lat: fromStn.lat + (toStn.lat - fromStn.lat) * segmentProgress,
            lon: fromStn.lon + (toStn.lon - fromStn.lon) * segmentProgress,
            bearing: this.calculateBearing(fromStn, toStn)
          };

      const cap = isSirio ? 223 : 309;
      const pax = Math.min(cap, Math.round((70 + (i * 19) % 85) * demandMult));

      this.activeTrains.push({
        id: trainId,
        lineCode: lineCode,
        routeKey: routeKey,
        routeName: route.name,
        color: color,
        model: isSirio ? "AnsaldoBreda Sirio (32.25m)" : "Bozankaya Kayseray (32.72m)",
        capacity: cap,
        seats: 70,
        currentStopIndex: initialStopIndex,
        segmentProgress: segmentProgress,
        status: "RUNNING",
        dwellTimerSec: 0,
        nominalSpeedKmh: 44 + (i % 4) * 3,
        currentSpeedKmh: 45,
        lat: sampled.lat,
        lon: sampled.lon,
        altitude: 0,
        bearing: sampled.bearing,
        passengers: pax,
        loadFactor: Math.round((pax / cap) * 100),
        lastBoarded: 14 + (i % 8),
        lastAlighted: 11 + (i % 6),
        fromStationName: fromStn ? fromStn.name : "",
        nextStationName: toStn ? toStn.name : "",
        etaSeconds: 45,
        catenaryVoltage: 750,
        powerKw: 185,
        health: {
          wheelWearPct: Math.floor(86 + (i % 12)),
          pantograph: "Normal (750V DC)",
          nextMaintenanceKm: Math.floor(4800 + i * 650),
          temperatureC: 38 + (i % 7)
        }
      });
    }
  }

  spawnErkiletTrains() {
    if (!this.erkiletConfig.active) return;
    const activeCorridorKey = this.erkiletConfig.scenario === "scenario_b" ? "ERK_CORRIDOR_B" : "ERK_CORRIDOR_A";
    const baseNodes = this.corridorCurves[activeCorridorKey];
    if (!baseNodes || baseNodes.length < 2) return;

    const profile = this.getActiveDayProfile();
    const effectiveHeadway = this.erkiletConfig.headwayMinutes * (profile.headway_multiplier || 1.0);
    const count = Math.max(3, Math.min(16, Math.ceil(74 / Math.max(3, effectiveHeadway))));
    const demandMult = this.getHourlyDemandMultiplier();

    for (let i = 0; i < count; i++) {
      const trainId = `T5-${(i + 1).toString().padStart(2, "0")}`;
      const isOutbound = (i % 2 === 0);
      const routeKey = isOutbound ? "T5_OUT" : "T5_IN";
      const activePath = isOutbound ? baseNodes : [...baseNodes].reverse();
      const arcSegments = this.routeSegmentArcMap[routeKey] || [];

      const progressRatio = (i / count);
      const totalPoints = activePath.length;
      const pointIndex = Math.min(Math.floor(progressRatio * (totalPoints - 1)), totalPoints - 2);
      const segProg = (progressRatio * (totalPoints - 1)) - pointIndex;

      const p1 = activePath[pointIndex];
      const p2 = activePath[pointIndex + 1];
      const sampled = arcSegments[pointIndex]
        ? this.sampleArcSegment(arcSegments[pointIndex], segProg)
        : {
            lat: p1.lat + (p2.lat - p1.lat) * segProg,
            lon: p1.lon + (p2.lon - p1.lon) * segProg,
            bearing: this.calculateBearing(p1, p2)
          };

      const isTunnel = (p1.surface === "tunnel" || p2.surface === "tunnel");
      const pax = Math.min(296, Math.round((105 + (i * 17) % 90) * demandMult));

      this.activeTrains.push({
        id: trainId,
        lineCode: "T5",
        routeKey: routeKey,
        routeName: isOutbound ? "Kumsmall / Bülbülpınarı → Havalimanı → Meydan → Millet Bahçesi" : "Millet Bahçesi → Meydan → Havalimanı → Bülbülpınarı",
        color: "#FFD600",
        model: "Bozankaya 2. Nesil Yüksek Eğim Tramvay",
        capacity: 296,
        seats: 68,
        currentStopIndex: pointIndex,
        segmentProgress: segProg,
        status: "RUNNING",
        dwellTimerSec: 0,
        nominalSpeedKmh: this.erkiletConfig.commercialSpeed * 1.45,
        currentSpeedKmh: this.erkiletConfig.commercialSpeed * 1.35,
        lat: sampled.lat,
        lon: sampled.lon,
        altitude: isTunnel ? -18 : 0,
        isTunnel: isTunnel,
        bearing: sampled.bearing,
        passengers: pax,
        loadFactor: Math.round((pax / 296) * 100),
        lastBoarded: 19,
        lastAlighted: 15,
        fromStationName: p1.name || "Erkilet Hattı",
        nextStationName: p2.name || "Sonraki İstasyon",
        etaSeconds: 50,
        catenaryVoltage: 750,
        powerKw: 210,
        isErkilet: true,
        health: {
          wheelWearPct: 98,
          pantograph: "Yeni Nesil Akıllı Pantoğraf",
          nextMaintenanceKm: 18500,
          temperatureC: 33
        }
      });
    }
  }

  spawnCustomLineTrains() {
    this.customLines.forEach(cLine => {
      if (!cLine.visible || !cLine.nodes || cLine.nodes.length < 2) return;
      const count = cLine.trainCount || 4;
      for (let i = 0; i < count; i++) {
        const isOut = (i % 2 === 0);
        const rKey = isOut ? cLine.routeKeyOut : cLine.routeKeyIn;
        const nodes = isOut ? cLine.nodes : [...cLine.nodes].reverse();
        const arcSegments = this.routeSegmentArcMap[rKey] || [];
        const prog = i / count;
        const idx = Math.min(Math.floor(prog * (nodes.length - 1)), nodes.length - 2);
        const segP = (prog * (nodes.length - 1)) - idx;
        const p1 = nodes[idx];
        const p2 = nodes[idx + 1];
        const sampled = arcSegments[idx]
          ? this.sampleArcSegment(arcSegments[idx], segP)
          : { lat: p1.lat, lon: p1.lon, bearing: this.calculateBearing(p1, p2) };

        this.activeTrains.push({
          id: `${cLine.code}-${(i + 1).toString().padStart(2, "0")}`,
          lineCode: cLine.code,
          routeKey: rKey,
          routeName: cLine.name,
          color: cLine.color || "#F97316",
          model: "Bozankaya 2. Nesil Tramvay",
          capacity: 296,
          seats: 68,
          currentStopIndex: idx,
          segmentProgress: segP,
          status: "RUNNING",
          dwellTimerSec: 0,
          nominalSpeedKmh: 45,
          currentSpeedKmh: 42,
          lat: sampled.lat,
          lon: sampled.lon,
          altitude: 0,
          isTunnel: false,
          bearing: sampled.bearing,
          passengers: 110,
          loadFactor: 37,
          lastBoarded: 14,
          lastAlighted: 10,
          fromStationName: p1.name || "Başlangıç",
          nextStationName: p2.name || "Varış",
          etaSeconds: 45,
          catenaryVoltage: 750,
          powerKw: 190,
          isCustomLine: true,
          customLineCode: cLine.code,
          health: {
            wheelWearPct: 99,
            pantograph: "Normal (750V DC)",
            nextMaintenanceKm: 19000,
            temperatureC: 32
          }
        });
      }
    });
  }

  /**
   * Yeni Hat Ekleme (HOTFIX: Yeni eklenen hattın koordinat dizisini poligon haritasına,
   * data.lines listesine ve 3D/2D render kuyruğuna görünürlük bayrağı açık olarak besler)
   */
  addCustomLine(code, name, color, stationNodes) {
    if (!stationNodes || stationNodes.length < 2) return null;
    const cleanCode = (code || `T${6 + this.customLines.length}`).toUpperCase();
    const routeKeyOut = `${cleanCode}_OUT`;
    const routeKeyIn = `${cleanCode}_IN`;

    stationNodes.forEach((n, idx) => {
      const stnId = n.id || `${cleanCode}_STN_${idx + 1}`;
      n.id = stnId;
      n.isStop = true;
      if (!this.stationMap[stnId]) {
        this.stationMap[stnId] = {
          id: stnId,
          code: stnId,
          name: n.name || `${cleanCode} İstasyon ${idx + 1}`,
          lat: parseFloat(n.lat),
          lon: parseFloat(n.lon),
          type: "regular",
          district: "Kayseri",
          surface: n.surface || "surface",
          is_tunnel: n.surface === "tunnel",
          isStop: true,
          isCustom: true,
          lines: [cleanCode],
          waitingPax: Math.round((n.hourlyDemand || 900) / 18),
          platformCapacity: 350,
          hourlyDemandBase: n.hourlyDemand || 900,
          occupancyPct: 35,
          lastBoarding: 12,
          lastAlighting: 10,
          totalBoardedToday: 500,
          totalAlightedToday: 480,
          activeDwell: null
        };
      }
    });

    const newLineObj = {
      id: `LINE_${cleanCode}`,
      code: cleanCode,
      name: name || `${cleanCode} Yeni Eklenen Tramvay Hattı`,
      color: color || "#F97316",
      length_km: 6.5,
      station_count: stationNodes.length,
      runtime_min: 18,
      commercial_speed_kmh: 26.0,
      electrification: "750 V DC Katener",
      daily_passengers: 24000,
      status: "PROPOSED",
      visible: true,
      routeKeyOut,
      routeKeyIn,
      nodes: stationNodes
    };

    this.customLines.push(newLineObj);
    if (!this.data.lines.some(l => l.code === cleanCode)) {
      this.data.lines.push(newLineObj);
    }

    this.precomputeRoutePaths();
    this.initFleet();
    this.notifyTopologyListeners();
    this.notifyListeners();
    return newLineObj;
  }

  /**
   * T5 Erkilet İstasyon Listesini Getir (Arayüzdeki Dinamik İstasyon Yöneticisi İçin)
   */
  getErkiletStations() {
    const activeCorridorKey = this.erkiletConfig.scenario === "scenario_b" ? "ERK_CORRIDOR_B" : "ERK_CORRIDOR_A";
    const corridor = this.corridorCurves[activeCorridorKey] || [];
    const stops = [];
    corridor.forEach(node => {
      if (node.isStop && node.id && this.stationMap[node.id]) {
        stops.push(this.stationMap[node.id]);
      }
    });
    return stops;
  }

  // T5 Erkilet Güzergâhına Yeni İstasyon Ekleme (Saatlik yolcu ve doluluk oranı destekli)
  addCustomStationToErkilet(name, lat, lon, isTunnel = false, hourlyDemandBase = 1250, occupancyPct = null) {
    const newId = `ERK_CUST_${Date.now().toString().slice(-4)}`;
    const parsedLat = parseFloat(lat);
    const parsedLon = parseFloat(lon);
    const parsedDemand = Math.max(100, parseInt(hourlyDemandBase) || 1250);
    const cap = 350;
    const initWaiting = occupancyPct !== null
      ? Math.round((Math.min(100, Math.max(5, parseFloat(occupancyPct))) / 100) * cap)
      : Math.min(cap, Math.round(parsedDemand / 20));

    const newStation = {
      id: newId,
      code: "T5+",
      name: name.trim(),
      lat: parsedLat,
      lon: parsedLon,
      type: "custom",
      district: "Kocasinan / Erkilet",
      surface: isTunnel ? "tunnel" : "surface",
      is_tunnel: isTunnel,
      isStop: true,
      isCustom: true,
      lines: ["T5", "T5-A"],
      waitingPax: initWaiting,
      platformCapacity: cap,
      hourlyDemandBase: parsedDemand,
      occupancyPct: Math.min(100, Math.round((initWaiting / cap) * 100)),
      lastBoarding: 16,
      lastAlighting: 12,
      totalBoardedToday: 680,
      totalAlightedToday: 610,
      activeDwell: null
    };

    this.stationMap[newId] = newStation;

    const activeCorridorKey = this.erkiletConfig.scenario === "scenario_b" ? "ERK_CORRIDOR_B" : "ERK_CORRIDOR_A";
    const corridor = this.corridorCurves[activeCorridorKey];
    let bestIndex = 1;
    let minDetour = Infinity;

    for (let i = 0; i < corridor.length - 1; i++) {
      const baseSeg = this.distanceKm(corridor[i].lat, corridor[i].lon, corridor[i + 1].lat, corridor[i + 1].lon);
      const detour = (
        this.distanceKm(corridor[i].lat, corridor[i].lon, parsedLat, parsedLon) +
        this.distanceKm(parsedLat, parsedLon, corridor[i + 1].lat, corridor[i + 1].lon)
      ) - baseSeg;
      if (detour < minDetour) {
        minDetour = detour;
        bestIndex = i + 1;
      }
    }

    corridor.splice(bestIndex, 0, {
      id: newId,
      name: newStation.name,
      lat: parsedLat,
      lon: parsedLon,
      isStop: true,
      isCustom: true,
      surface: newStation.surface
    });
    this.erkiletConfig.customStations.push(newStation);

    this.precomputeRoutePaths();
    this.updateErkiletConfig({});
    this.notifyTopologyListeners(newStation);
    return newStation;
  }

  /**
   * Mevcut Bir Durağın İsim, Koordinat ve Yolcu Yoğunluğu Parametrelerini Reaktif Güncelleme
   */
  updateErkiletStation(stnId, { name, lat, lon, hourlyDemandBase, occupancyPct, isTunnel }) {
    const stn = this.stationMap[stnId];
    if (!stn) return null;

    if (name !== undefined && name.trim()) stn.name = name.trim();
    if (lat !== undefined && !isNaN(parseFloat(lat))) stn.lat = parseFloat(lat);
    if (lon !== undefined && !isNaN(parseFloat(lon))) stn.lon = parseFloat(lon);
    if (hourlyDemandBase !== undefined && !isNaN(parseInt(hourlyDemandBase))) {
      stn.hourlyDemandBase = Math.max(50, parseInt(hourlyDemandBase));
    }
    if (occupancyPct !== undefined && !isNaN(parseFloat(occupancyPct))) {
      const clampedPct = Math.min(100, Math.max(0, parseFloat(occupancyPct)));
      stn.occupancyPct = clampedPct;
      stn.waitingPax = Math.round((clampedPct / 100) * (stn.platformCapacity || 350));
    }
    if (isTunnel !== undefined) {
      stn.is_tunnel = !!isTunnel;
      stn.surface = isTunnel ? "tunnel" : "surface";
    }

    // Koridor dizisindeki karşılığını da güncelle
    ["ERK_CORRIDOR_A", "ERK_CORRIDOR_B"].forEach(k => {
      const list = this.corridorCurves[k] || [];
      list.forEach(node => {
        if (node.id === stnId) {
          node.name = stn.name;
          node.lat = stn.lat;
          node.lon = stn.lon;
          node.surface = stn.surface;
        }
      });
    });

    this.precomputeRoutePaths();
    this.notifyTopologyListeners(stn);
    this.notifyListeners();
    return stn;
  }

  /**
   * Erkilet Hattından Durak Çıkarma (Silme) ve Rotayı Anında Yeniden Hesaplama
   */
  removeErkiletStation(stnId) {
    const activeCorridorKey = this.erkiletConfig.scenario === "scenario_b" ? "ERK_CORRIDOR_B" : "ERK_CORRIDOR_A";
    const corridor = this.corridorCurves[activeCorridorKey];
    const stopCount = corridor.filter(n => n.isStop).length;
    if (stopCount <= 2) return false; // En az başlangıç ve bitiş durağı kalmalı

    const idx = corridor.findIndex(n => n.id === stnId);
    if (idx !== -1) {
      corridor.splice(idx, 1);
    }

    this.erkiletConfig.customStations = this.erkiletConfig.customStations.filter(s => s.id !== stnId);
    if (stnId.startsWith("ERK_")) {
      delete this.stationMap[stnId];
    }

    this.precomputeRoutePaths();
    this.updateErkiletConfig({});
    this.notifyTopologyListeners();
    this.notifyListeners();
    return true;
  }

  distanceKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  calculateBearing(from, to) {
    const y = Math.sin((to.lon - from.lon) * Math.PI / 180) * Math.cos(to.lat * Math.PI / 180);
    const x = Math.cos(from.lat * Math.PI / 180) * Math.sin(to.lat * Math.PI / 180) -
              Math.sin(from.lat * Math.PI / 180) * Math.cos(to.lat * Math.PI / 180) * Math.cos((to.lon - from.lon) * Math.PI / 180);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  }

  step(dtSec) {
    if (this.timeScale === 0) return;

    const effectiveDt = dtSec * this.timeScale;
    this.simTimeSeconds = (this.simTimeSeconds + effectiveDt) % 86400;

    const timeDemandMultiplier = this.getHourlyDemandMultiplier();

    this.updateStationQueues(effectiveDt, timeDemandMultiplier);
    this.checkIncidents(effectiveDt);

    this.activeTrains.forEach(train => {
      this.updateTrain(train, effectiveDt, timeDemandMultiplier);
    });

    this.notifyListeners();
  }

  updateStationQueues(dtSec, demandMultiplier) {
    Object.values(this.stationMap).forEach(stn => {
      const arrivalRatePerSec = (stn.hourlyDemandBase / 3600) * demandMultiplier;
      stn.waitingPax = Math.min(stn.platformCapacity, stn.waitingPax + arrivalRatePerSec * dtSec);
      stn.occupancyPct = Math.min(100, Math.round((stn.waitingPax / Math.max(1, stn.platformCapacity)) * 100));

      if (stn.activeDwell) {
        stn.activeDwell.progressSec += dtSec;
        if (stn.activeDwell.progressSec >= stn.activeDwell.durationSec) {
          stn.activeDwell = null;
        }
      }
    });
  }

  updateTrain(train, dtSec, demandFactor) {
    let activeSpeedLimit = train.nominalSpeedKmh;
    let isTrainBlocked = false;
    let dwellPenaltySec = 0;

    this.activeIncidents.forEach(inc => {
      const dist = this.distanceKm(train.lat, train.lon, inc.lat, inc.lon);
      if (dist <= inc.affected_radius_km) {
        if (inc.impact_type === "STATION_CLOSURE" || inc.line_impact === "Hat kapatma") {
          isTrainBlocked = true;
        } else if (inc.impact_type === "SINGLE_TRACK") {
          activeSpeedLimit = Math.min(activeSpeedLimit, inc.speed_limit_kmh || 15);
        } else if (inc.impact_type === "SPEED_RESTRICTION") {
          activeSpeedLimit = Math.min(activeSpeedLimit, inc.speed_limit_kmh || 20);
        } else if (inc.impact_type === "VEHICLE_TOWING") {
          activeSpeedLimit = Math.min(activeSpeedLimit, 12);
          dwellPenaltySec = 25;
        }
      }
    });

    if (isTrainBlocked) {
      train.status = "BLOCKED";
      train.currentSpeedKmh = Math.max(0, train.currentSpeedKmh - 25 * dtSec);
      train.powerKw = 18;
      return;
    } else if (train.status === "BLOCKED") {
      train.status = "RUNNING";
    }

    let pathNodes;
    if (train.isErkilet) {
      const activeCorridorKey = this.erkiletConfig.scenario === "scenario_b" ? "ERK_CORRIDOR_B" : "ERK_CORRIDOR_A";
      const base = this.corridorCurves[activeCorridorKey];
      pathNodes = train.routeKey === "T5_OUT" ? base : [...base].reverse();
    } else if (train.isCustomLine) {
      const cLine = this.customLines.find(l => l.code === train.customLineCode);
      if (!cLine) return;
      pathNodes = train.routeKey === cLine.routeKeyOut ? cLine.nodes : [...cLine.nodes].reverse();
    } else {
      pathNodes = this.data.routes[train.routeKey].stops.map(id => this.stationMap[id]);
    }

    if (!pathNodes || pathNodes.length < 2) return;
    const arcSegments = this.routeSegmentArcMap[train.routeKey] || [];

    if (train.status === "DWELLING") {
      train.dwellTimerSec -= dtSec;
      train.currentSpeedKmh = 0;
      train.powerKw = 32;

      if (train.dwellTimerSec <= 0) {
        train.status = "RUNNING";
        train.currentStopIndex++;
        if (train.currentStopIndex >= pathNodes.length - 1) {
          train.currentStopIndex = 0;
        }
        train.segmentProgress = 0;
      }
      return;
    }

    const p1 = pathNodes[train.currentStopIndex];
    const p2 = pathNodes[train.currentStopIndex + 1];

    if (!p1 || !p2) {
      train.currentStopIndex = 0;
      train.segmentProgress = 0;
      return;
    }

    const currentArcSeg = arcSegments[train.currentStopIndex];
    const segDistKm = currentArcSeg
      ? currentArcSeg.totalKm
      : Math.max(0.02, this.distanceKm(p1.lat, p1.lon, p2.lat, p2.lon));

    const targetSpeed = Math.min(train.nominalSpeedKmh, activeSpeedLimit);
    train.currentSpeedKmh = targetSpeed;
    train.powerKw = Math.round(175 + Math.random() * 40);

    const distTraveledKm = (targetSpeed / 3600) * dtSec;
    train.segmentProgress += (distTraveledKm / segDistKm);

    if (train.segmentProgress >= 1.0) {
      train.segmentProgress = 1.0;

      const isStopNode = p2.isStop !== false;
      const targetStation = isStopNode ? (this.stationMap[p2.id] || null) : null;

      if (targetStation) {
        train.status = "DWELLING";

        const isHub = targetStation.type === "central_hub" || targetStation.type === "transfer" || targetStation.is_hub;
        const alightingRatio = isHub ? 0.34 : 0.17;
        const alightingPax = Math.min(train.passengers, Math.max(1, Math.round(train.passengers * alightingRatio + Math.random() * 7)));

        const availableCap = Math.max(0, train.capacity - (train.passengers - alightingPax));
        const boardingPax = Math.min(Math.max(1, Math.floor(targetStation.waitingPax * 0.65)), availableCap);

        train.passengers = Math.max(0, train.passengers - alightingPax + boardingPax);
        targetStation.waitingPax = Math.max(6, targetStation.waitingPax - boardingPax);
        targetStation.occupancyPct = Math.min(100, Math.round((targetStation.waitingPax / Math.max(1, targetStation.platformCapacity)) * 100));

        targetStation.lastBoarding = boardingPax;
        targetStation.lastAlighting = alightingPax;
        targetStation.totalBoardedToday = (targetStation.totalBoardedToday || 0) + boardingPax;
        targetStation.totalAlightedToday = (targetStation.totalAlightedToday || 0) + alightingPax;

        train.lastBoarded = boardingPax;
        train.lastAlighted = alightingPax;

        const computedDwell = Math.round(14 + (boardingPax * 0.32 + alightingPax * 0.22) + dwellPenaltySec);
        train.dwellTimerSec = Math.max(15, computedDwell);

        targetStation.activeDwell = {
          trainId: train.id,
          lineCode: train.lineCode,
          boarding: boardingPax,
          alighting: alightingPax,
          progressSec: 0,
          durationSec: train.dwellTimerSec
        };

        train.loadFactor = Math.min(100, Math.round((train.passengers / train.capacity) * 100));
      } else {
        train.currentStopIndex++;
        if (train.currentStopIndex >= pathNodes.length - 1) {
          train.currentStopIndex = 0;
        }
        train.segmentProgress = 0;
      }
    }

    if (currentArcSeg) {
      const sampled = this.sampleArcSegment(currentArcSeg, train.segmentProgress);
      train.lat = sampled.lat;
      train.lon = sampled.lon;
      train.bearing = sampled.bearing;
    } else {
      train.lat = p1.lat + (p2.lat - p1.lat) * train.segmentProgress;
      train.lon = p1.lon + (p2.lon - p1.lon) * train.segmentProgress;
      train.bearing = this.calculateBearing(p1, p2);
    }

    const isUnderground = (p1.surface === "tunnel" || p2.surface === "tunnel" || p1.is_tunnel || p2.is_tunnel);
    train.altitude = isUnderground ? -18 : 0;
    train.isTunnel = isUnderground;

    train.fromStationName = p1.name || "Önceki Düğüm";
    train.nextStationName = p2.name || "Sonraki İstasyon";
    const remKm = Math.max(0, (1 - train.segmentProgress) * segDistKm);
    train.etaSeconds = Math.round((remKm / Math.max(targetSpeed, 1)) * 3600) + Math.round(train.dwellTimerSec);
  }

  checkIncidents(dtSec) {
    this.activeIncidents.forEach(inc => {
      inc.elapsedSec += dtSec;
      inc.remainingDurationSec = Math.max(0, inc.totalDurationSec - inc.elapsedSec);

      const dispatchSec = Math.max(60, inc.logistics.dispatch_time_min * 60);
      const triageSec = dispatchSec + 180;
      const repairSec = Math.max(triageSec + 60, inc.totalDurationSec - 120);

      if (inc.elapsedSec < dispatchSec) {
        inc.phase = "DISPATCHING";
        inc.phaseTitle = inc.dispatch_team_required
          ? "🚨 Saha Müdahale Ekibi İntikal Halinde"
          : "🔍 Vatman / Yerel Teknisyen Müdahalesi Başladı";
        const dispatchRatio = Math.min(1, inc.elapsedSec / dispatchSec);
        inc.phaseProgressPct = Math.round(dispatchRatio * 100);
        inc.crewLat = inc.depotLat + (inc.lat - inc.depotLat) * dispatchRatio;
        inc.crewLon = inc.depotLon + (inc.lon - inc.depotLon) * dispatchRatio;
      } else if (inc.elapsedSec < triageSec) {
        inc.phase = "ON_SITE_TRIAGE";
        inc.phaseTitle = `🛡️ Emniyet Protokolü: ${inc.safety_protocol}`;
        inc.phaseProgressPct = Math.round(((inc.elapsedSec - dispatchSec) / 180) * 100);
        inc.crewLat = inc.lat;
        inc.crewLon = inc.lon;
      } else if (inc.elapsedSec < repairSec) {
        inc.phase = "REPAIRING";
        inc.phaseTitle = "🔧 Teknik Onarım, İzolasyon ve Parça Değişimi";
        inc.phaseProgressPct = Math.round(((inc.elapsedSec - triageSec) / (repairSec - triageSec)) * 100);
        inc.crewLat = inc.lat;
        inc.crewLon = inc.lon;
      } else {
        inc.phase = "TESTING";
        inc.phaseTitle = "⚡ Sinyal/Enerji Testi ve Hattın Normal İşletmeye Açılması";
        inc.phaseProgressPct = Math.round(((inc.elapsedSec - repairSec) / 120) * 100);
        inc.crewLat = inc.lat;
        inc.crewLon = inc.lon;
      }
    });

    const resolved = this.activeIncidents.filter(inc => inc.remainingDurationSec <= 0);
    if (resolved.length > 0) {
      this.activeIncidents = this.activeIncidents.filter(inc => inc.remainingDurationSec > 0);
      this.activeTrains.forEach(t => {
        if (t.status === "BLOCKED") t.status = "RUNNING";
      });
    }
  }

  triggerIncident(catalogId, targetStationId) {
    const incTemplate = this.data.incident_catalog.find(i => i.failure_id === catalogId || i.id === catalogId) || this.data.incident_catalog[0];
    const stn = this.stationMap[targetStationId] || this.stationMap["STN_19"];

    let depot = this.depotLocations["OCC_CENTER"];
    if (incTemplate.category === "Elektrifikasyon") depot = this.depotLocations["OSB_DEPOT"];
    else if (incTemplate.category === "Altyapı") depot = this.depotLocations["TUNA_DEPOT"];
    else if (incTemplate.category === "Araç") depot = this.depotLocations["ILDEM_DEPOT"];

    const mttrMin = incTemplate.MTTR_minutes || incTemplate.typical_mttr_min || 30;
    const mtbfHours = incTemplate.MTBF_hours || incTemplate.mtbf_hours || 1000;

    const incident = {
      instanceId: `INC-${Date.now().toString().slice(-4)}`,
      failure_id: incTemplate.failure_id || incTemplate.id,
      id: incTemplate.failure_id || incTemplate.id,
      name: incTemplate.name,
      category: incTemplate.category,
      description: incTemplate.description || incTemplate.impact_description,
      severity_level: incTemplate.severity_level || incTemplate.severity,
      severity: incTemplate.severity_level || incTemplate.severity,
      MTBF_hours: mtbfHours,
      mtbf_hours: mtbfHours,
      MTTR_minutes: mttrMin,
      typical_mttr_min: mttrMin,
      affected_system: incTemplate.affected_system || (incTemplate.affected_systems || []).join(", "),
      safety_protocol: incTemplate.safety_protocol || "Standart EN 50126 Emniyet Protokolü",
      dispatch_team_required: incTemplate.dispatch_team_required !== false,
      line_impact: incTemplate.line_impact || incTemplate.impact_title,
      impact_type: incTemplate.impact_type,
      impact_title: incTemplate.line_impact || incTemplate.impact_title,
      speed_limit_kmh: incTemplate.speed_limit_kmh,
      affected_radius_km: incTemplate.affected_radius_km || 0.7,
      affected_systems: incTemplate.affected_systems || [],
      stationId: stn.id,
      stationName: stn.name,
      lat: stn.lat,
      lon: stn.lon,
      depotLat: depot.lat,
      depotLon: depot.lon,
      crewLat: depot.lat,
      crewLon: depot.lon,
      totalDurationSec: mttrMin * 60,
      elapsedSec: 0,
      remainingDurationSec: mttrMin * 60,
      impact: incTemplate.description || incTemplate.impact_description,
      logistics: incTemplate.logistics,
      phase: "DISPATCHING",
      phaseTitle: "🚨 Saha Müdahale Ekibi İntikal Halinde",
      phaseProgressPct: 0
    };

    this.activeIncidents.push(incident);
    this.notifyListeners();
    return incident;
  }

  clearAllIncidents() {
    this.activeIncidents = [];
    this.activeTrains.forEach(t => {
      if (t.status === "BLOCKED") t.status = "RUNNING";
    });
    this.notifyListeners();
  }

  updateErkiletConfig(newConfig) {
    Object.assign(this.erkiletConfig, newConfig);
    this.precomputeRoutePaths();
    this.activeTrains = this.activeTrains.filter(t => !t.isErkilet);
    if (this.erkiletConfig.active) {
      this.spawnErkiletTrains();
    }
    this.notifyTopologyListeners();
    this.notifyListeners();
  }

  getSystemMetrics() {
    const totalPax = this.activeTrains.reduce((acc, t) => acc + (t.passengers || 0), 0);
    const avgLoadFactor = this.activeTrains.length > 0
      ? Math.round(this.activeTrains.reduce((acc, t) => acc + (t.loadFactor || 0), 0) / this.activeTrains.length)
      : 0;
    const totalPowerMw = (this.activeTrains.reduce((acc, t) => acc + (t.powerKw || 0), 0) / 1000).toFixed(2);
    const blockedTrains = this.activeTrains.filter(t => t.status === "BLOCKED").length;
    const dwellingTrains = this.activeTrains.filter(t => t.status === "DWELLING").length;
    const totalPlatformQueue = Object.values(this.stationMap).reduce((acc, s) => acc + (Math.round(s.waitingPax) || 0), 0);
    const dayProfile = this.getActiveDayProfile();

    return {
      simTimeFormatted: this.formatTime(this.simTimeSeconds),
      dayTypeLabel: dayProfile.label,
      demandMultiplier: this.getHourlyDemandMultiplier().toFixed(2),
      totalTrains: this.activeTrains.length,
      blockedTrainsCount: blockedTrains,
      dwellingTrainsCount: dwellingTrains,
      totalCurrentPassengers: totalPax,
      avgLoadFactorPct: avgLoadFactor,
      totalPowerMw: totalPowerMw,
      totalPlatformQueue: totalPlatformQueue,
      activeIncidentsCount: this.activeIncidents.length,
      catenaryHealthPct: this.activeIncidents.length > 0 ? 82.5 : 99.8
    };
  }

  formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }

  onUpdate(callback) {
    this.listeners.push(callback);
  }

  onTopologyChange(callback) {
    this.topologyListeners.push(callback);
  }

  notifyListeners() {
    this.listeners.forEach(cb => cb(this));
  }

  notifyTopologyListeners(newStn = null) {
    this.topologyListeners.forEach(cb => cb(this, newStn));
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = TramDigitalTwinEngine;
}
