/**
 * Kayseri Tramvay Dijital İkiz — Canlı 2D OpenStreetMap (Leaflet.js) Görselleştirme Motoru
 * - Gerçek OpenStreetMap, CartoDB Dark/Voyager ve Google Hybrid Uydu Katmanları
 * - Kuş Uçuşu ("İp Gibi") Görünümü Kaldıran Kavisli Çift Katmanlı Demiryolu Polyline Geometrisi
 * - Kelimeleri Kesmeyen Dinamik Genişlikli İstasyon Etiketleri + Canlı Peron Kuyruk/Doluluk Göstergeleri
 * - Peronlarda Canlı İniş/Biniş Yüzen Animasyon Balonları (+Biniş / -İniş)
 * - RAMS Arıza Etki Çemberi ve Depodan Olay Yerine İntikal Eden Canlı Müdahale Ekibi Aracı (🔧)
 */

class KayseriOSMMapView {
  constructor(containerId, engine, onSelectEntity) {
    this.containerId = containerId;
    this.container = document.getElementById(containerId);
    this.engine = engine;
    this.onSelectEntity = onSelectEntity;

    this.map = null;
    this.trackLayerGroup = null;
    this.stationLayerGroup = null;
    this.trainLayerGroup = null;
    this.incidentLayerGroup = null;

    this.trainMarkers = new Map();
    this.stationMarkers = new Map();
    this.stationLabelMarkers = new Map();
    this.dwellPopupMarkers = new Map();
    this.incidentLayers = new Map();

    this.trackedTrainId = null;
    this.addStationClickMode = false;
    this.lastLabelUpdateSec = 0;

    if (typeof L !== "undefined" && this.container) {
      this.initMap();
      this.buildCurvedTracks();
      this.buildStations();
      this.updateTrains();

      // Topoloji değiştiğinde (yeni durak eklendiğinde veya T5 senaryosu değiştiğinde) rayları ve durakları yenile
      this.engine.onTopologyChange(() => {
        this.rebuildTopology();
      });
    }
  }

  initMap() {
    // Cumhuriyet Meydanı merkezli OpenStreetMap başlatma
    this.map = L.map(this.containerId, {
      center: [38.7265, 35.4873],
      zoom: 13,
      zoomControl: false,
      preferCanvas: true
    });

    // Sağ üstte zoom kontrolü
    L.control.zoom({ position: "bottomright" }).addTo(this.map);

    // 1. OpenStreetMap Standart Katmanı (Varsayılan Aktif Katman)
    const osmStandard = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> katkıda bulunanlar'
    });

    // 2. OpenStreetMap HOT (İnsani/Ulaşım Odaklı Net Cadde Katmanı)
    const osmHot = L.tileLayer("https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors, Tiles style by Humanitarian OSM Team'
    });

    // 3. CartoDB Voyager (Renkli Kentsel Ulaşım Haritası)
    const cartoVoyager = L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap &copy; CARTO'
    });

    // 4. CartoDB Dark Matter (Koyu Siber Dijital İkiz Haritası)
    const cartoDark = L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap &copy; CARTO'
    });

    // 5. Google Hybrid Uydu + Cadde Katmanı
    const googleHybrid = L.tileLayer("https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}", {
      maxZoom: 20,
      attribution: "&copy; Google Maps Hybrid"
    });

    // Varsayılan olarak OpenStreetMap Standart katmanını ekle
    osmStandard.addTo(this.map);

    this.trackLayerGroup = L.layerGroup().addTo(this.map);
    this.stationLayerGroup = L.layerGroup().addTo(this.map);
    this.incidentLayerGroup = L.layerGroup().addTo(this.map);
    this.trainLayerGroup = L.layerGroup().addTo(this.map);

    const baseMaps = {
      "🗺️ OpenStreetMap (Standart)": osmStandard,
      "🚋 OpenStreetMap (Ulaşım / HOT)": osmHot,
      "🌆 CartoDB Voyager (Şehir Şeması)": cartoVoyager,
      "🌙 CartoDB Dark (Gece Modu)": cartoDark,
      "🛰️ Uydu + Sokak (Hybrid)": googleHybrid
    };

    const overlayMaps = {
      "🛤️ Kavisli Ray Hatları (T1-T5)": this.trackLayerGroup,
      "🏛️ İstasyonlar & Peron Kuyrukları": this.stationLayerGroup,
      "🚋 Canlı Tramvay Filosu": this.trainLayerGroup,
      "🚨 Arıza & Bakım Lojistiği": this.incidentLayerGroup
    };

    L.control.layers(baseMaps, overlayMaps, { position: "topright", collapsed: true }).addTo(this.map);

    // Harita üzerinden tıklayarak T5'e yeni istasyon ekleme desteği
    this.map.on("click", (e) => {
      if (this.addStationClickMode) {
        const { lat, lng } = e.latlng;
        const stnName = prompt(
          `OpenStreetMap üzerinde seçilen noktaya (${lat.toFixed(5)}, ${lng.toFixed(5)}) eklenecek yeni T5 istasyonunun adını giriniz:`,
          "Erkilet Bulvarı Yeni İstasyon"
        );
        this.setAddStationClickMode(false);
        if (stnName && stnName.trim()) {
          const newStn = this.engine.addCustomStationToErkilet(stnName.trim(), lat, lng, false);
          if (window.twinUI) {
            window.twinUI.updateErkiletCalculations();
            window.twinUI.showEntityDetails("station", newStn);
          }
        }
      }
    });
  }

  setAddStationClickMode(enabled) {
    this.addStationClickMode = enabled;
    if (this.container) {
      this.container.style.cursor = enabled ? "crosshair" : "";
    }
  }

  rebuildTopology() {
    if (!this.map) return;
    this.trackLayerGroup.clearLayers();
    this.stationLayerGroup.clearLayers();
    this.stationMarkers.clear();
    this.stationLabelMarkers.clear();
    this.dwellPopupMarkers.clear();

    this.buildCurvedTracks();
    this.buildStations();
  }

  /**
   * Kavisli (Catmull-Rom Spline + Cadde Kurpları) Ray Güzergâhlarını Çizer.
   * Düz "ip gibi" çizgiler yerine çift katmanlı (travers gövdesi + parlak ray) kavisli poligon kullanır.
   */
  buildCurvedTracks() {
    if (!this.trackLayerGroup) return;

    const lineStyles = [
      { code: "T1", routeKey: "T1_DEP", color: "#FF3366", casing: "#500724", weight: 5, name: "T1 Organize Sanayi ↔ İldem 5" },
      { code: "T2", routeKey: "T2_DEP", color: "#00E676", casing: "#064E3B", weight: 5, name: "T2 Cumhuriyet Meydanı ↔ Talas Cemil Baba" },
      { code: "T3", routeKey: "T3_DEP", color: "#00E5FF", casing: "#083344", weight: 4.5, name: "T3 Kumsmall AVM ↔ İldem 5" },
      { code: "T4", routeKey: "T4_ARR", color: "#E040FB", casing: "#4A044E", weight: 4.5, name: "T4 Cumhuriyet Meydanı ↔ Anayurt" }
    ];

    lineStyles.forEach(ls => {
      const densePoints = this.engine.routePolylineMap[ls.routeKey] || [];
      if (densePoints.length < 2) return;

      const latlngs = densePoints.map(p => [p.lat, p.lon]);

      // 1. Alt Demiryolu Travers Yatağı (Koyu Çerçeve)
      L.polyline(latlngs, {
        color: ls.casing,
        weight: ls.weight + 4,
        opacity: 0.75,
        lineCap: "round",
        lineJoin: "round"
      }).addTo(this.trackLayerGroup);

      // 2. Üst Parlak Ray Hattı
      const mainLine = L.polyline(latlngs, {
        color: ls.color,
        weight: ls.weight,
        opacity: 0.95,
        lineCap: "round",
        lineJoin: "round"
      }).addTo(this.trackLayerGroup);

      mainLine.bindTooltip(`<b>${ls.name}</b><br>Gerçek Cadde/Ray Kurp Geometrisi`, { sticky: true });
    });

    // T5 Erkilet Hattı (Hemzemin + 4 km Yeraltı Tünel Kesimi Ayrı Gösterimli)
    const t5Dense = this.engine.routePolylineMap["T5_OUT"] || [];
    if (t5Dense.length >= 2) {
      for (let i = 0; i < t5Dense.length - 1; i++) {
        const p1 = t5Dense[i];
        const p2 = t5Dense[i + 1];
        const isTunnel = (p1.surface === "tunnel" && p2.surface === "tunnel");
        const segLatLngs = [[p1.lat, p1.lon], [p2.lat, p2.lon]];

        if (isTunnel) {
          L.polyline(segLatLngs, {
            color: "#0c4a6e",
            weight: 9,
            opacity: 0.65
          }).addTo(this.trackLayerGroup);

          L.polyline(segLatLngs, {
            color: "#00E5FF",
            weight: 5,
            opacity: 0.95,
            dashArray: "8, 8"
          }).bindTooltip("<b>T5 Erkilet Yer Altı Tünel Kesimi (-18m)</b>", { sticky: true }).addTo(this.trackLayerGroup);
        } else {
          L.polyline(segLatLngs, {
            color: "#422006",
            weight: 9,
            opacity: 0.75
          }).addTo(this.trackLayerGroup);

          L.polyline(segLatLngs, {
            color: "#FFD600",
            weight: 5,
            opacity: 0.95
          }).bindTooltip("<b>T5 Erkilet Hemzemin Ray Hattı</b>", { sticky: true }).addTo(this.trackLayerGroup);
        }
      }
    }
  }

  /**
   * İstasyonları, Kesilmeyen Dinamik İsim Etiketlerini ve Canlı Peron Doluluk/Kuyruk Barlarını Çizer
   */
  buildStations() {
    if (!this.stationLayerGroup) return;

    const allStations = Object.values(this.engine.stationMap);
    allStations.forEach(stn => {
      if (stn.is_passenger_station === false) return;

      // Aktif olmayan T5 senaryosunun duraklarını filtrele
      const activeScenarioPrefix = this.engine.erkiletConfig.scenario === "scenario_b" ? "ERK_B_" : "ERK_A_";
      const inactiveScenarioPrefix = this.engine.erkiletConfig.scenario === "scenario_b" ? "ERK_A_" : "ERK_B_";
      if (stn.id.startsWith(inactiveScenarioPrefix)) return;

      const isHub = stn.is_hub || stn.type === "central_hub" || stn.type === "transfer";
      const isCustom = !!stn.isCustom;
      const isT5 = stn.id.startsWith("ERK_");

      const fillColor = isCustom
        ? "#F59E0B"
        : isT5
        ? (stn.is_tunnel ? "#00E5FF" : "#FFD600")
        : isHub
        ? "#F59E0B"
        : "#38BDF8";

      const circle = L.circleMarker([stn.lat, stn.lon], {
        radius: isCustom ? 9 : isHub ? 8 : 5.5,
        color: "#0f172a",
        weight: 2,
        fillColor: fillColor,
        fillOpacity: 0.95
      }).addTo(this.stationLayerGroup);

      circle.on("click", () => {
        if (this.onSelectEntity) this.onSelectEntity("station", stn);
      });

      this.stationMarkers.set(stn.id, circle);

      // Kalıcı, Kelimeleri Kesmeyen İstasyon Etiketi + Canlı Peron Kuyruk/Doluluk Göstergesi
      const labelIcon = L.divIcon({
        className: "osm-station-label-wrapper",
        html: this.renderStationBadgeHTML(stn),
        iconSize: null
      });

      const labelMarker = L.marker([stn.lat, stn.lon], {
        icon: labelIcon,
        interactive: true
      }).addTo(this.stationLayerGroup);

      labelMarker.on("click", () => {
        if (this.onSelectEntity) this.onSelectEntity("station", stn);
      });

      this.stationLabelMarkers.set(stn.id, labelMarker);
    });
  }

  renderStationBadgeHTML(stn) {
    const queue = Math.round(stn.waitingPax || 0);
    const cap = stn.platformCapacity || 300;
    const pct = Math.min(100, Math.round((queue / cap) * 100));
    const barColor = pct > 75 ? "#ef4444" : pct > 40 ? "#f59e0b" : "#10b981";
    const isHub = stn.is_hub || stn.type === "central_hub" || stn.type === "transfer";
    const isCustom = !!stn.isCustom;

    // Kuyruk yoğunluğunu temsil eden mini yolcu noktaları (1-5 adet)
    const dotCount = Math.max(1, Math.min(5, Math.ceil(pct / 20)));
    const dotsHtml = Array.from({ length: dotCount })
      .map(() => `<span class="pax-queue-dot" style="background:${barColor};"></span>`)
      .join("");

    const dwellHtml = stn.activeDwell
      ? `<div class="osm-dwell-pill">🚋 +${stn.activeDwell.boarding} Biniş | -${stn.activeDwell.alighting} İniş</div>`
      : "";

    return `
      <div class="osm-station-badge ${isHub ? 'hub-badge' : ''} ${isCustom ? 'custom-badge' : ''}">
        ${dwellHtml}
        <div class="osm-stn-title">${isCustom ? '⭐ ' : ''}${stn.name}</div>
        <div class="osm-stn-pax-row">
          <span class="pax-dots">${dotsHtml}</span>
          <span class="pax-count">${queue} yolcu</span>
          <span class="pax-delta">(+${stn.lastBoarding || 0}/-${stn.lastAlighting || 0})</span>
        </div>
        <div class="osm-stn-mini-bar">
          <div class="osm-stn-mini-fill" style="width:${pct}%; background:${barColor};"></div>
        </div>
      </div>
    `;
  }

  update() {
    if (!this.map) return;
    this.updateTrains();
    this.updateStationVisuals();
    this.updateIncidents();
  }

  updateTrains() {
    if (!this.trainLayerGroup) return;

    const activeIds = new Set();
    this.engine.activeTrains.forEach(train => {
      activeIds.add(train.id);
      let marker = this.trainMarkers.get(train.id);

      const isBlocked = train.status === "BLOCKED";
      const isDwelling = train.status === "DWELLING";
      const bg = isBlocked ? "#EF4444" : train.color;
      const borderCol = isDwelling ? "#FFD600" : "#FFFFFF";

      const iconHtml = `
        <div class="osm-train-marker ${isBlocked ? 'train-blocked' : ''} ${isDwelling ? 'train-dwelling' : ''}">
          <div class="osm-train-arrow" style="background:${bg}; border-color:${borderCol}; transform: rotate(${Math.round(train.bearing)}deg);">
            ▲
          </div>
          <div class="osm-train-tag" style="border-color:${bg};">
            <span>${train.id}</span>
            <span class="osm-train-load">%${train.loadFactor}</span>
          </div>
        </div>
      `;

      const icon = L.divIcon({
        className: "osm-train-icon-container",
        html: iconHtml,
        iconSize: [64, 36],
        iconAnchor: [32, 18]
      });

      if (!marker) {
        marker = L.marker([train.lat, train.lon], {
          icon: icon,
          zIndexOffset: 1000
        }).addTo(this.trainLayerGroup);

        marker.on("click", () => {
          this.trackedTrainId = train.id;
          if (this.onSelectEntity) this.onSelectEntity("train", train);
        });

        this.trainMarkers.set(train.id, marker);
      } else {
        marker.setLatLng([train.lat, train.lon]);
        marker.setIcon(icon);
      }
    });

    // Silinen trenleri temizle
    for (const [id, marker] of this.trainMarkers.entries()) {
      if (!activeIds.has(id)) {
        this.trainLayerGroup.removeLayer(marker);
        this.trainMarkers.delete(id);
      }
    }

    if (this.trackedTrainId) {
      const tr = this.engine.activeTrains.find(t => t.id === this.trackedTrainId);
      if (tr) {
        this.map.panTo([tr.lat, tr.lon], { animate: true, duration: 0.25 });
      }
    }
  }

  updateStationVisuals() {
    const now = performance.now();
    // Performans için istasyon rozetlerini saniyede ~3 kez güncelle
    if (now - this.lastLabelUpdateSec < 320) return;
    this.lastLabelUpdateSec = now;

    for (const [stnId, labelMarker] of this.stationLabelMarkers.entries()) {
      const stn = this.engine.stationMap[stnId];
      if (!stn) continue;
      const newIcon = L.divIcon({
        className: "osm-station-label-wrapper",
        html: this.renderStationBadgeHTML(stn),
        iconSize: null
      });
      labelMarker.setIcon(newIcon);
    }
  }

  updateIncidents() {
    if (!this.incidentLayerGroup) return;
    this.incidentLayerGroup.clearLayers();

    this.engine.activeIncidents.forEach(inc => {
      // 1. Etkilenen Bölge Yarıçapı
      L.circle([inc.lat, inc.lon], {
        radius: (inc.affected_radius_km || 0.6) * 1000,
        color: "#EF4444",
        weight: 2,
        fillColor: "#EF4444",
        fillOpacity: 0.22,
        dashArray: "6, 6"
      }).bindTooltip(`🚨 <b>${inc.name}</b><br>${inc.impact_title}<br>Aşama: ${inc.phaseTitle}`).addTo(this.incidentLayerGroup);

      // 2. Arıza Merkez Noktası İkonu
      const incIcon = L.divIcon({
        className: "osm-incident-icon",
        html: `<div class="incident-pulse-badge">⚠️ ${inc.name.split("&")[0].trim()}</div>`,
        iconSize: null
      });
      L.marker([inc.lat, inc.lon], { icon: incIcon, zIndexOffset: 2000 }).addTo(this.incidentLayerGroup);

      // 3. Bakım Üssünden Olay Yerine İntikal Eden Müdahale Ekibi Lojistik Hattı ve Aracı
      if (inc.crewLat && inc.crewLon) {
        L.polyline([[inc.depotLat, inc.depotLon], [inc.lat, inc.lon]], {
          color: "#F59E0B",
          weight: 3,
          dashArray: "5, 7",
          opacity: 0.85
        }).addTo(this.incidentLayerGroup);

        const crewIcon = L.divIcon({
          className: "osm-crew-icon",
          html: `<div class="crew-vehicle-badge">🔧 ${inc.logistics.vehicle.split(" ")[0]} (${inc.phase === 'DISPATCHING' ? 'İntikalde %' + inc.phaseProgressPct : 'Sahada'})</div>`,
          iconSize: null
        });
        L.marker([inc.crewLat, inc.crewLon], { icon: crewIcon, zIndexOffset: 2100 }).addTo(this.incidentLayerGroup);
      }
    });
  }

  focusOnGeo(lat, lon, zoom = 15) {
    this.trackedTrainId = null;
    if (this.map) {
      this.map.flyTo([lat, lon], zoom, { duration: 0.8 });
    }
  }

  setCameraPreset(preset) {
    this.trackedTrainId = null;
    if (!this.map) return;
    switch (preset) {
      case "all":
        this.map.flyTo([38.735, 35.487], 12, { duration: 0.8 });
        break;
      case "meydan":
        this.map.flyTo([38.72189, 35.48732], 15, { duration: 0.8 });
        break;
      case "erkilet":
        this.map.flyTo([38.778, 35.475], 13, { duration: 0.8 });
        break;
      case "talas":
        this.map.flyTo([38.704, 35.534], 14, { duration: 0.8 });
        break;
      case "kumsmall":
        this.map.flyTo([38.772, 35.420], 14, { duration: 0.8 });
        break;
    }
  }

  invalidateSize() {
    if (this.map) {
      setTimeout(() => this.map.invalidateSize(), 100);
    }
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = KayseriOSMMapView;
}
