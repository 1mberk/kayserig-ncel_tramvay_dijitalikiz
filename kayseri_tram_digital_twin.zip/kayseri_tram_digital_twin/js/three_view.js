/**
 * Kayseri Tramvay Dijital İkiz — SL-Train Video Tarzı 3D Koridor & İstasyon Peron İkizi (V4)
 * - Mapbox Dark v11 (Kullanıcı API Anahtarı Entegreli) + CartoDB Dark/Voyager Otomatik Fallback
 * - SL-Train Video Mimarisi: Koyu Vektör Koridor Haritası, Parlak Ray Hatları, Beyaz Halka İstasyon Düğümleri,
 *   Renkli Hat Rozetli Koyu Etiketler ve 3B Ada Peron + Üst Geçit + Canlı Yolcu Yoğunluk Noktaları (<0.2 Mavi, <0.5 Sarı, <1.0 Turuncu, >1.0 Kırmızı)
 */

class Kayseri3DView {
  constructor(containerId, engine, onSelectEntity) {
    this.container = document.getElementById(containerId);
    this.engine = engine;
    this.onSelectEntity = onSelectEntity;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();

    // 3D Obje Grupları (Dinamik Rebuild İçin)
    this.groundTileGroup = new THREE.Group();
    this.trackGroup = new THREE.Group();
    this.stationGroup = new THREE.Group();

    this.trainMeshes = new Map();
    this.stationMeshes = new Map();
    this.stationRings = new Map();
    this.stationHeatDiscs = new Map();
    this.stationLabels = new Map();
    this.stationPlatforms = new Map();
    this.stationPaxDots = new Map();
    this.lineCurves = new Map();
    this.incidentMarkers = new Map();
    this.crewMarkers = new Map();
    this.dwellFeedbackSprites = new Map();

    // Kamera Takip ve Haritadan Durak Seçim Modu
    this.trackedTrainId = null;
    this.focusedStationId = "STN_19";
    this.pickCoordinateCallback = null;

    // Coğrafi Koordinat Dönüşüm Katsayıları (Cumhuriyet Meydanı Merkezli)
    this.originLat = 38.7218925;
    this.originLon = 35.4873228;
    this.worldScale = 0.08;

    // Kullanıcının Mapbox API Anahtarı ve Harita Altlık Kaynakları
    this.mapboxToken = "pk.eyJ1IjoibWV0aW5iZXJrYWt5b2wiLCJhIjoiY213YXg4eGdwMDgwczJ4c2h0aTZxNmJudiJ9.zr2V41O_aFnj_tdV1aLLBA";
    this.activeBaseStyle = "mapbox_dark";
    this.tileProviders = {
      mapbox_dark: {
        name: "Mapbox Dark v11 (SL-Train Video Stili)",
        urls: [
          `https://api.mapbox.com/styles/v1/mapbox/dark-v11/tiles/512/{z}/{x}/{y}@2x?access_token=${this.mapboxToken}`,
          "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
          "https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png"
        ]
      },
      mapbox_streets: {
        name: "Mapbox Navigation Night",
        urls: [
          `https://api.mapbox.com/styles/v1/mapbox/navigation-night-v1/tiles/512/{z}/{x}/{y}@2x?access_token=${this.mapboxToken}`,
          "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png"
        ]
      },
      carto_dark: {
        name: "CartoDB Dark Matter (Siber Gece)",
        urls: [
          "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
          "https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png"
        ]
      },
      carto_voyager: {
        name: "CartoDB Voyager (Renkli Şehir)",
        urls: [
          "https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
          "https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
          "https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png"
        ]
      },
      carto_positron: {
        name: "CartoDB Positron (Aydınlık Şema)",
        urls: [
          "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
          "https://b.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png"
        ]
      },
      esri_satellite: {
        name: "Esri World Imagery (Uydu)",
        urls: [
          "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
        ]
      },
      osm_fallback: {
        name: "OpenStreetMap (User-Agent + Carto Fallback)",
        urls: [
          "https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
          "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        ]
      }
    };

    this.tooltipEl = document.getElementById("three-tooltip");

    this.initScene();
    this.buildGroundAndEnvironment();
    this.load3DBaseMapTiles(this.activeBaseStyle);
    this.buildTracksAndTunnels();
    this.buildStations();
    this.animate();

    // Topoloji veya İstasyon Yoğunluğu Değiştiğinde Anında Reaktif Güncelle
    this.engine.onTopologyChange(() => {
      this.rebuildAllTopology();
    });

    window.addEventListener("resize", () => this.onWindowResize());
    if (this.container) {
      this.container.addEventListener("pointerdown", (e) => this.onPointerDown(e));
      this.container.addEventListener("pointermove", (e) => this.onPointerMove(e));
    }
  }

  geoToWorld(lat, lon, altitude = 0) {
    const x = (lon - this.originLon) * (Math.PI / 180) * 6378137 * Math.cos(this.originLat * Math.PI / 180) * this.worldScale;
    const z = -(lat - this.originLat) * (Math.PI / 180) * 6378137 * this.worldScale;
    const y = altitude * this.worldScale;
    return new THREE.Vector3(x, y, z);
  }

  worldToGeo(x, z) {
    const lon = this.originLon + (x / (this.worldScale * 6378137 * Math.cos(this.originLat * Math.PI / 180))) * (180 / Math.PI);
    const lat = this.originLat - (z / (this.worldScale * 6378137)) * (180 / Math.PI);
    return { lat, lon };
  }

  initScene() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0b0f17);
    this.scene.fog = new THREE.FogExp2(0x0b0f17, 0.00014);

    const w = (this.container && this.container.clientWidth) ? this.container.clientWidth : window.innerWidth;
    const h = (this.container && this.container.clientHeight) ? this.container.clientHeight : window.innerHeight;

    this.camera = new THREE.PerspectiveCamera(45, w / h, 1, 60000);
    this.camera.position.set(0, 1650, 1950);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    this.renderer.setSize(w, h);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.shadowMap.enabled = true;
    if (this.container) {
      this.container.appendChild(this.renderer.domElement);
    }

    this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.03;
    this.controls.minDistance = 25;
    this.controls.maxDistance = 16000;
    this.controls.target.set(0, 0, 0);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.90);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.05);
    dirLight.position.set(1500, 3200, 1500);
    this.scene.add(dirLight);

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0b0f17, 0.5);
    this.scene.add(hemiLight);

    this.scene.add(this.groundTileGroup);
    this.scene.add(this.trackGroup);
    this.scene.add(this.stationGroup);
  }

  buildGroundAndEnvironment() {
    const groundGeo = new THREE.PlaneGeometry(18000, 18000);
    const groundMat = new THREE.MeshBasicMaterial({
      color: 0x0b0f17,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.65
    });
    this.groundPlaneMesh = new THREE.Mesh(groundGeo, groundMat);
    this.groundPlaneMesh.rotation.x = -Math.PI / 2;
    this.groundPlaneMesh.position.y = -1.2;
    this.groundPlaneMesh.userData = { type: "ground_plane" };
    this.scene.add(this.groundPlaneMesh);

    const gridHelper = new THREE.GridHelper(16000, 140, 0x1e293b, 0x111827);
    gridHelper.position.y = -0.9;
    this.scene.add(gridHelper);

    // Erciyes Dağı 3D Silueti (Güney Ufku)
    const erciyesGeo = new THREE.ConeGeometry(1300, 1150, 32);
    const erciyesMat = new THREE.MeshStandardMaterial({ color: 0x161f30, roughness: 0.9 });
    const erciyesMesh = new THREE.Mesh(erciyesGeo, erciyesMat);
    erciyesMesh.position.set(900, 380, 4400);
    this.scene.add(erciyesMesh);

    const snowGeo = new THREE.ConeGeometry(420, 360, 32);
    const snowMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, wireframe: true, transparent: true, opacity: 0.35 });
    const snowMesh = new THREE.Mesh(snowGeo, snowMat);
    snowMesh.position.set(900, 830, 4400);
    this.scene.add(snowMesh);
  }

  lon2tile(lon, zoom) {
    return Math.floor(((lon + 180) / 360) * Math.pow(2, zoom));
  }

  lat2tile(lat, zoom) {
    return Math.floor(
      ((1 - Math.log(Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)) / Math.PI) / 2) *
      Math.pow(2, zoom)
    );
  }

  tile2lon(x, zoom) {
    return (x / Math.pow(2, zoom)) * 360 - 180;
  }

  tile2lat(y, zoom) {
    const n = Math.PI - (2 * Math.PI * y) / Math.pow(2, zoom);
    return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
  }

  setBaseMapStyle(styleKey) {
    if (!this.tileProviders[styleKey]) return;
    this.activeBaseStyle = styleKey;
    this.load3DBaseMapTiles(styleKey);
  }

  load3DBaseMapTiles(styleKey = "mapbox_dark") {
    while (this.groundTileGroup.children.length > 0) {
      this.groundTileGroup.remove(this.groundTileGroup.children[0]);
    }

    const provider = this.tileProviders[styleKey] || this.tileProviders.mapbox_dark;
    const zoom = 13;
    const centerTileX = this.lon2tile(this.originLon, zoom);
    const centerTileY = this.lat2tile(this.originLat, zoom);

    for (let dx = -3; dx <= 3; dx++) {
      for (let dy = -2; dy <= 2; dy++) {
        const tx = centerTileX + dx;
        const ty = centerTileY + dy;

        const northLat = this.tile2lat(ty, zoom);
        const southLat = this.tile2lat(ty + 1, zoom);
        const westLon = this.tile2lon(tx, zoom);
        const eastLon = this.tile2lon(tx + 1, zoom);

        const nw = this.geoToWorld(northLat, westLon, 0);
        const se = this.geoToWorld(southLat, eastLon, 0);

        const tileWidth = Math.abs(se.x - nw.x);
        const tileDepth = Math.abs(se.z - nw.z);
        const centerX = (nw.x + se.x) / 2;
        const centerZ = (nw.z + se.z) / 2;

        const tileGeo = new THREE.PlaneGeometry(tileWidth, tileDepth);
        const fallbackTex = this.createProceduralTileTexture(tx, ty, styleKey);
        const tileMat = new THREE.MeshBasicMaterial({
          map: fallbackTex,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.95
        });

        const tileMesh = new THREE.Mesh(tileGeo, tileMat);
        tileMesh.rotation.x = -Math.PI / 2;
        tileMesh.position.set(centerX, -0.45, centerZ);
        tileMesh.userData = { type: "ground_plane" };
        this.groundTileGroup.add(tileMesh);

        this.fetchTileTextureWithFallback(provider.urls, zoom, tx, ty, (loadedTex) => {
          if (loadedTex && tileMesh.material) {
            tileMesh.material.map = loadedTex;
            tileMesh.material.needsUpdate = true;
          }
        });
      }
    }
  }

  createProceduralTileTexture(tx, ty, styleKey) {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext("2d");

    const isLight = styleKey === "carto_positron";
    ctx.fillStyle = isLight ? "#1e293b" : "#0d121d";
    ctx.fillRect(0, 0, 256, 256);

    // SL-Train Koyu Şehir Blokları Dokusu
    ctx.fillStyle = isLight ? "rgba(255,255,255,0.04)" : "rgba(30, 41, 59, 0.45)";
    for (let bx = 8; bx < 248; bx += 48) {
      for (let by = 8; by < 248; by += 48) {
        ctx.fillRect(bx, by, 36, 34);
      }
    }

    ctx.strokeStyle = isLight ? "rgba(56, 189, 248, 0.16)" : "rgba(51, 65, 85, 0.38)";
    ctx.lineWidth = 1.5;
    for (let i = 0; i <= 256; i += 48) {
      ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, 256); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(256, i); ctx.stroke();
    }
    return new THREE.CanvasTexture(canvas);
  }

  fetchTileTextureWithFallback(urlTemplates, z, x, y, onSuccess, attemptIndex = 0) {
    if (typeof fetch === "undefined" || typeof createImageBitmap === "undefined") return;
    if (attemptIndex >= urlTemplates.length) return;

    const rawUrl = urlTemplates[attemptIndex]
      .replace("{z}", z)
      .replace("{x}", x)
      .replace("{y}", y);

    fetch(rawUrl, {
      method: "GET",
      mode: "cors",
      referrerPolicy: "origin",
      headers: {
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8"
      }
    })
      .then(res => {
        if (!res.ok) throw new Error(`Tile HTTP ${res.status}`);
        return res.blob();
      })
      .then(blob => createImageBitmap(blob))
      .then(bitmap => {
        const canvas = document.createElement("canvas");
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(bitmap, 0, 0, 256, 256);
        const tex = new THREE.CanvasTexture(canvas);
        tex.minFilter = THREE.LinearFilter;
        onSuccess(tex);
      })
      .catch(() => {
        if (attemptIndex + 1 < urlTemplates.length) {
          this.fetchTileTextureWithFallback(urlTemplates, z, x, y, onSuccess, attemptIndex + 1);
        }
      });
  }

  rebuildAllTopology() {
    while (this.trackGroup.children.length > 0) {
      this.trackGroup.remove(this.trackGroup.children[0]);
    }
    while (this.stationGroup.children.length > 0) {
      this.stationGroup.remove(this.stationGroup.children[0]);
    }

    this.stationMeshes.clear();
    this.stationRings.clear();
    this.stationHeatDiscs.clear();
    this.stationLabels.clear();
    this.stationPlatforms.clear();
    this.stationPaxDots.clear();
    this.lineCurves.clear();

    this.buildTracksAndTunnels();
    this.buildStations();
  }

  /**
   * SL-Train Video Tarzı Parlak Ray Koridorları + Çift Hat Metalik Raylar
   */
  buildTracksAndTunnels() {
    const lineDefinitions = [
      { code: "T1", route: "T1_DEP", color: 0xff3355, radius: 2.3 },
      { code: "T2", route: "T2_DEP", color: 0x00e676, radius: 2.2 },
      { code: "T3", route: "T3_DEP", color: 0x00e5ff, radius: 2.1 },
      { code: "T4", route: "T4_ARR", color: 0xe040fb, radius: 2.1 }
    ];

    lineDefinitions.forEach(lineDef => {
      const densePoints = this.engine.routePolylineMap[lineDef.route] || [];
      if (densePoints.length < 2) return;

      const points = densePoints.map(pt => this.geoToWorld(pt.lat, pt.lon, 0.55));
      if (points.length >= 2) {
        const curve = new THREE.CatmullRomCurve3(points);
        curve.curveType = "centripetal";
        this.lineCurves.set(lineDef.route, curve);

        // SL-Train Koyu Travers Yatağı (Ballast Bed)
        const bedGeo = new THREE.TubeGeometry(curve, Math.min(400, points.length * 2), lineDef.radius * 1.9, 6, false);
        const bedMat = new THREE.MeshBasicMaterial({
          color: 0x111827,
          transparent: true,
          opacity: 0.78
        });
        this.trackGroup.add(new THREE.Mesh(bedGeo, bedMat));

        // Ana Neon Koridor Hattı
        const tubeGeo = new THREE.TubeGeometry(curve, Math.min(420, points.length * 2), lineDef.radius, 10, false);
        const tubeMat = new THREE.MeshStandardMaterial({
          color: lineDef.color,
          emissive: lineDef.color,
          emissiveIntensity: 0.72,
          roughness: 0.2,
          metalness: 0.8
        });
        const tubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
        tubeMesh.userData = { type: "line_track", lineCode: lineDef.code };
        this.trackGroup.add(tubeMesh);
      }
    });

    // T5 Erkilet Hattı
    this.buildErkiletCorridor3D();

    // Kullanıcının Dinamik Eklediği Yeni Hatlar
    if (this.engine.customLines && this.engine.customLines.length > 0) {
      this.engine.customLines.forEach(cLine => {
        if (cLine.visible === false) return;
        const cDense = this.engine.routePolylineMap[cLine.routeKeyOut] || this.engine.routePolylineMap[cLine.code] || [];
        if (cDense.length < 2) return;

        const cPoints = cDense.map(pt => this.geoToWorld(pt.lat, pt.lon, 0.8));
        const cCurve = new THREE.CatmullRomCurve3(cPoints);
        cCurve.curveType = "centripetal";
        this.lineCurves.set(cLine.code, cCurve);

        const colObj = new THREE.Color(cLine.color || "#F97316");
        const cTubeGeo = new THREE.TubeGeometry(cCurve, Math.min(350, cPoints.length * 3), 2.5, 10, false);
        const cTubeMat = new THREE.MeshStandardMaterial({
          color: colObj,
          emissive: colObj,
          emissiveIntensity: 0.75,
          metalness: 0.8,
          roughness: 0.2
        });
        const cMesh = new THREE.Mesh(cTubeGeo, cTubeMat);
        cMesh.userData = { type: "line_track", lineCode: cLine.code };
        this.trackGroup.add(cMesh);
      });
    }
  }

  buildErkiletCorridor3D() {
    if (!this.engine.erkiletConfig.active || this.engine.erkiletConfig.visible === false) return;

    const denseErk = this.engine.routePolylineMap["T5_OUT"] || [];
    if (!denseErk || denseErk.length < 2) return;

    const surfacePoints = denseErk.map(n => this.geoToWorld(n.lat, n.lon, n.surface === "tunnel" ? -14 : 1.0));
    const erkiletCurve = new THREE.CatmullRomCurve3(surfacePoints);
    erkiletCurve.curveType = "centripetal";
    this.lineCurves.set("T5_TRACK", erkiletCurve);

    const tubeGeo = new THREE.TubeGeometry(erkiletCurve, Math.min(450, surfacePoints.length * 2), 2.6, 10, false);
    const tubeMat = new THREE.MeshStandardMaterial({
      color: 0xffd600,
      emissive: 0xffd600,
      emissiveIntensity: 0.80,
      metalness: 0.85,
      roughness: 0.2
    });
    this.erkiletTubeMesh = new THREE.Mesh(tubeGeo, tubeMat);
    this.erkiletTubeMesh.userData = { type: "line_track", lineCode: "T5" };
    this.trackGroup.add(this.erkiletTubeMesh);

    const tunnelPoints = denseErk.filter(n => n.surface === "tunnel").map(n => this.geoToWorld(n.lat, n.lon, -14));
    if (tunnelPoints.length >= 2) {
      const tCurve = new THREE.CatmullRomCurve3(tunnelPoints);
      const tunnelCaseGeo = new THREE.TubeGeometry(tCurve, 60, 7.0, 12, false);
      const tunnelCaseMat = new THREE.MeshStandardMaterial({
        color: 0x00e5ff,
        emissive: 0x0284c7,
        emissiveIntensity: 0.5,
        transparent: true,
        opacity: 0.45,
        wireframe: true
      });
      const tunnelMesh = new THREE.Mesh(tunnelCaseGeo, tunnelCaseMat);
      this.trackGroup.add(tunnelMesh);
    }
  }

  /**
   * SL-Train Video Tarzı İstasyon Etiketi:
   * Koyu kapsül kutu + İstasyon İsmi + Renkli Hat Rozetleri ([T1][T2][T5])
   */
  createStationLabel(text, isHub = false, subText = "", lines = []) {
    const lineBadges = (lines && lines.length > 0) ? lines : ["T1"];
    const testCanvas = document.createElement("canvas");
    const testCtx = testCanvas.getContext("2d");
    testCtx.font = "bold 24px 'Segoe UI', Arial, sans-serif";
    const measuredMain = testCtx.measureText(text).width;
    const badgesWidth = lineBadges.length * 46;
    testCtx.font = "bold 17px 'Segoe UI', Arial, sans-serif";
    const measuredSub = subText ? testCtx.measureText(subText).width : 0;

    const padX = 28;
    const canvasWidth = Math.max(250, Math.ceil(Math.max(measuredMain + badgesWidth + 18, measuredSub) + padX * 2));
    const canvasHeight = subText ? 82 : 58;

    const canvas = document.createElement("canvas");
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext("2d");

    const cornerRadius = 12;
    ctx.fillStyle = "rgba(15, 23, 42, 0.94)";
    if (ctx.roundRect) {
      ctx.beginPath();
      ctx.roundRect(3, 3, canvasWidth - 6, canvasHeight - 6, cornerRadius);
      ctx.fill();
      ctx.strokeStyle = isHub ? "#ffd600" : "rgba(255, 255, 255, 0.65)";
      ctx.lineWidth = isHub ? 3.5 : 2.5;
      ctx.stroke();
    } else {
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
      ctx.strokeStyle = isHub ? "#ffd600" : "#ffffff";
      ctx.lineWidth = 3;
      ctx.strokeRect(2, 2, canvasWidth - 4, canvasHeight - 4);
    }

    // İstasyon Adı
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 23px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    const rowY = subText ? 26 : canvasHeight / 2;
    const startX = 20;
    ctx.fillText(text, startX, rowY);

    // SL-Train Tarzı Renkli Hat Rozetleri (T1, T2, T3, T4, T5)
    const lineColorMap = {
      "T1": "#ff3355",
      "T2": "#00e676",
      "T3": "#00e5ff",
      "T4": "#e040fb",
      "T5": "#ffd600",
      "T5-A": "#ffd600",
      "T5-B": "#ff9100"
    };
    let badgeX = startX + measuredMain + 12;
    lineBadges.forEach(lCode => {
      const bgCol = lineColorMap[lCode] || "#38bdf8";
      ctx.fillStyle = bgCol;
      if (ctx.roundRect) {
        ctx.beginPath();
        ctx.roundRect(badgeX, rowY - 13, 40, 26, 6);
        ctx.fill();
      } else {
        ctx.fillRect(badgeX, rowY - 13, 40, 26);
      }
      ctx.fillStyle = (lCode.startsWith("T5") || lCode === "T2" || lCode === "T3") ? "#0f172a" : "#ffffff";
      ctx.font = "bold 15px 'Segoe UI', Arial, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(lCode.replace("-A", "").replace("-B", ""), badgeX + 20, rowY);
      badgeX += 45;
    });

    if (subText) {
      ctx.fillStyle = "#38bdf8";
      ctx.font = "bold 17px 'Segoe UI', Arial, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(subText, canvasWidth / 2, 58);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
    const sprite = new THREE.Sprite(spriteMat);

    const worldWidth = canvasWidth * 0.155;
    const worldHeight = subText ? 13.5 : 9.8;
    sprite.scale.set(worldWidth, worldHeight, 1);
    return sprite;
  }

  /**
   * SL-Train Video Tarzı 3B Ada Peron, Beyaz Üst Geçit Köprüsü (Overpass Canopy), Merdivenler
   * ve Peron Üzerinde Canlı Yürüyen Yolcu Yoğunluk Noktaları (<0.2 Mavi, <0.5 Sarı, <1.0 Turuncu, >1.0 Kırmızı)
   */
  createSL3DStationPlatform(stn, pos, isTunnel) {
    const platGroup = new THREE.Group();
    platGroup.position.copy(pos);

    // 1. Uzun Ada Peronu (Island Platform Slab - #d8dee9)
    const platLen = 36;
    const platWidth = 7.4;
    const platHeight = 1.3;
    const slabGeo = new THREE.BoxGeometry(platLen, platHeight, platWidth);
    const slabMat = new THREE.MeshStandardMaterial({
      color: 0xd8dee9,
      roughness: 0.45,
      metalness: 0.2
    });
    const slabMesh = new THREE.Mesh(slabGeo, slabMat);
    slabMesh.position.y = platHeight / 2 + 0.1;
    slabMesh.userData = { type: "station", data: stn };
    platGroup.add(slabMesh);

    // 2. Sarı Emniyet Şeritleri (Tactile Safety Edges)
    const edgeGeo = new THREE.BoxGeometry(platLen, 0.15, 0.35);
    const edgeMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    const edgeNorth = new THREE.Mesh(edgeGeo, edgeMat);
    edgeNorth.position.set(0, platHeight + 0.12, -platWidth / 2 + 0.3);
    const edgeSouth = new THREE.Mesh(edgeGeo, edgeMat);
    edgeSouth.position.set(0, platHeight + 0.12, platWidth / 2 - 0.3);
    platGroup.add(edgeNorth);
    platGroup.add(edgeSouth);

    // 3. SL-Train Tarzı Beyaz Üst Geçit Köprüsü ve Kanopi (Overpass Canopy Bridge)
    const bridgeGeo = new THREE.BoxGeometry(9.5, 2.6, platWidth * 2.5);
    const bridgeMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.3,
      metalness: 0.35
    });
    const bridgeMesh = new THREE.Mesh(bridgeGeo, bridgeMat);
    bridgeMesh.position.set(-4, 6.2, 0);
    bridgeMesh.userData = { type: "station", data: stn };
    platGroup.add(bridgeMesh);

    // Köprü Taşıyıcı Sütunları ve Merdiven / Yürüyen Merdiven Rampası
    const pillarGeo = new THREE.CylinderGeometry(0.6, 0.6, 6.0, 12);
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.6 });
    const p1 = new THREE.Mesh(pillarGeo, pillarMat);
    p1.position.set(-4, 3.0, -platWidth * 1.1);
    const p2 = new THREE.Mesh(pillarGeo, pillarMat);
    p2.position.set(-4, 3.0, platWidth * 1.1);
    platGroup.add(p1);
    platGroup.add(p2);

    const stairGeo = new THREE.BoxGeometry(7.5, 0.7, 2.6);
    const stairMesh = new THREE.Mesh(stairGeo, bridgeMat);
    stairMesh.position.set(1.8, 3.6, 0);
    stairMesh.rotation.z = -0.46;
    platGroup.add(stairMesh);

    // 4. Peron Üzerinde Canlı Yolcu Yoğunluğu Noktaları (SL-Train Load Density Dots)
    const paxDots = [];
    const dotGeo = new THREE.SphereGeometry(0.48, 8, 8);
    const dotCount = 26;
    for (let i = 0; i < dotCount; i++) {
      const dotMat = new THREE.MeshBasicMaterial({ color: 0x3b82f6 });
      const dot = new THREE.Mesh(dotGeo, dotMat);
      const homeX = -platLen * 0.42 + (i / dotCount) * (platLen * 0.84) + (Math.random() - 0.5) * 1.5;
      const homeZ = (Math.random() - 0.5) * (platWidth - 1.8);
      dot.position.set(homeX, platHeight + 0.55, homeZ);
      dot.userData = {
        homeX,
        homeZ,
        phase: Math.random() * Math.PI * 2,
        speed: 0.8 + Math.random() * 1.2
      };
      platGroup.add(dot);
      paxDots.push(dot);
    }
    this.stationPaxDots.set(stn.id, paxDots);

    return { platGroup, clickableMesh: slabMesh };
  }

  /**
   * İstasyonları, SL-Train 3D Peronlarını, Beyaz Halka İşaretçilerini ve Etiketlerini Oluşturur
   */
  buildStations() {
    const inactivePrefix = this.engine.erkiletConfig.scenario === "scenario_b" ? "ERK_A_" : "ERK_B_";

    Object.values(this.engine.stationMap).forEach(stn => {
      if (stn.is_passenger_station === false) return;
      if (stn.id.startsWith(inactivePrefix)) return;

      const isTunnel = !!stn.is_tunnel || stn.surface === "tunnel";
      const pos = this.geoToWorld(stn.lat, stn.lon, isTunnel ? -14 : 0);
      const isHub = stn.is_hub || stn.type === "central_hub" || stn.type === "transfer";
      const isT5 = stn.id.startsWith("ERK_") || (stn.lines && stn.lines.includes("T5"));
      const isCustom = !!stn.isCustom;

      const hourlyDemand = stn.hourlyDemandBase || 900;

      // SL-Train 3D Ada Peron ve Üst Geçit Mimarisi
      const { platGroup, clickableMesh } = this.createSL3DStationPlatform(stn, pos, isTunnel);
      this.stationGroup.add(platGroup);
      this.stationPlatforms.set(stn.id, platGroup);
      this.stationMeshes.set(stn.id, clickableMesh);

      // SL-Train Koridor Haritası Beyaz Daire İstasyon Düğümü (White Ring Marker)
      const baseRadius = isCustom ? 7.5 : isHub ? 9.0 : isT5 ? 7.0 : 5.5;
      const ringGeo = new THREE.RingGeometry(baseRadius, baseRadius + 2.6, 28);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.95
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = -Math.PI / 2;
      ringMesh.position.copy(pos);
      ringMesh.position.y = isTunnel ? -13.4 : 0.65;
      this.stationGroup.add(ringMesh);
      this.stationRings.set(stn.id, ringMesh);

      // Yoğunluk Isı Haritası Halesi (Heat-Map Glow Disc)
      const heatRadius = Math.max(14, Math.min(48, (hourlyDemand / 85) + (stn.occupancyPct || 30) * 0.22));
      const heatGeo = new THREE.CircleGeometry(heatRadius, 24);
      const heatColor = hourlyDemand > 1800 ? 0xef4444 : hourlyDemand > 1000 ? 0xf59e0b : 0x3b82f6;
      const heatMat = new THREE.MeshBasicMaterial({
        color: heatColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.22
      });
      const heatMesh = new THREE.Mesh(heatGeo, heatMat);
      heatMesh.rotation.x = -Math.PI / 2;
      heatMesh.position.copy(pos);
      heatMesh.position.y = isTunnel ? -13.8 : 0.2;
      this.stationGroup.add(heatMesh);
      this.stationHeatDiscs.set(stn.id, heatMesh);

      // Dikey İnce Kılavuz Çizgi (Callout Stem Line) + SL-Train Kapsül İstasyon Etiketi
      const stemHeight = isHub || isT5 || isCustom ? 19 : 13;
      const stemGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(pos.x, pos.y + 2, pos.z),
        new THREE.Vector3(pos.x, pos.y + stemHeight, pos.z)
      ]);
      const stemMat = new THREE.LineBasicMaterial({ color: 0x94a3b8, transparent: true, opacity: 0.7 });
      this.stationGroup.add(new THREE.Line(stemGeo, stemMat));

      const prefix = isCustom ? "⭐ " : "";
      const subTxt = (isT5 || isHub || isCustom) ? `${hourlyDemand} yolcu/sa • %${stn.occupancyPct || 30}` : "";
      const labelSprite = this.createStationLabel(
        `${prefix}${stn.name}`,
        isHub || isT5 || isCustom,
        subTxt,
        stn.lines || (isT5 ? ["T5"] : ["T1"])
      );
      labelSprite.position.copy(pos);
      labelSprite.position.y += stemHeight + 4;
      this.stationGroup.add(labelSprite);
      this.stationLabels.set(stn.id, labelSprite);
    });
  }

  /**
   * SL-Train Video Tarzı 3 Vagonlu Mafsallı (Articulated) Beyaz/Gümüş 3D Tramvay Modeli
   */
  createTrainMesh(train) {
    const group = new THREE.Group();
    const carCount = 3;
    const carLen = 8.4;
    const gap = 0.8;
    const bodyWidth = 3.6;
    const bodyHeight = 4.0;

    const lineCol = new THREE.Color(train.color || "#38bdf8");
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      metalness: 0.45,
      roughness: 0.25,
      emissive: lineCol,
      emissiveIntensity: 0.22
    });
    const stripeMat = new THREE.MeshStandardMaterial({
      color: lineCol,
      emissive: lineCol,
      emissiveIntensity: 0.65
    });
    const glassMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });

    for (let c = 0; c < carCount; c++) {
      const zOffset = (c - 1) * (carLen + gap);

      const carGeo = new THREE.BoxGeometry(bodyWidth, bodyHeight, carLen);
      const carMesh = new THREE.Mesh(carGeo, c === 0 ? bodyMat : bodyMat.clone());
      carMesh.position.set(0, bodyHeight / 2 + 0.8, zOffset);
      group.add(carMesh);

      // Tavan Hat Rengi Şeridi (SL-Train Mavi/Kırmızı/Altın Tavan Şeridi)
      const roofGeo = new THREE.BoxGeometry(bodyWidth * 0.86, 0.45, carLen - 0.3);
      const roofMesh = new THREE.Mesh(roofGeo, stripeMat);
      roofMesh.position.set(0, bodyHeight + 0.85, zOffset);
      group.add(roofMesh);

      // Panoramik Yan Camlar
      const glassGeo = new THREE.BoxGeometry(bodyWidth + 0.12, 1.35, carLen - 1.0);
      const glassMesh = new THREE.Mesh(glassGeo, glassMat);
      glassMesh.position.set(0, bodyHeight * 0.66 + 0.4, zOffset);
      group.add(glassMesh);

      // Mafsal Körüğü (Bellows)
      if (c < carCount - 1) {
        const bellowGeo = new THREE.BoxGeometry(bodyWidth * 0.82, bodyHeight * 0.86, gap + 0.2);
        const bellowMat = new THREE.MeshBasicMaterial({ color: 0x334155 });
        const bellowMesh = new THREE.Mesh(bellowGeo, bellowMat);
        bellowMesh.position.set(0, bodyHeight / 2 + 0.7, zOffset + (carLen + gap) / 2);
        group.add(bellowMesh);
      }
    }

    // Pantoğraf
    const pantoGeo = new THREE.CylinderGeometry(0.25, 0.25, 2.2, 8);
    const pantoMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 });
    const pantoMesh = new THREE.Mesh(pantoGeo, pantoMat);
    pantoMesh.position.set(0, bodyHeight + 1.9, 0);
    group.add(pantoMesh);

    // Ön LED Farlar
    const frontZ = (carLen + gap) + carLen / 2 + 0.1;
    const headlightGeo = new THREE.SphereGeometry(0.5, 8, 8);
    const headlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const hlLeft = new THREE.Mesh(headlightGeo, headlightMat);
    hlLeft.position.set(-1.1, 1.8, frontZ);
    const hlRight = new THREE.Mesh(headlightGeo, headlightMat);
    hlRight.position.set(1.1, 1.8, frontZ);
    group.add(hlLeft);
    group.add(hlRight);

    group.userData = { type: "train", data: train };
    return group;
  }

  createDwellFeedbackSprite(boarding, alighting) {
    const canvas = document.createElement("canvas");
    canvas.width = 320;
    canvas.height = 70;
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "rgba(15, 23, 42, 0.95)";
    if (ctx.roundRect) {
      ctx.beginPath();
      ctx.roundRect(4, 4, 312, 62, 12);
      ctx.fill();
    } else {
      ctx.fillRect(4, 4, 312, 62);
    }
    ctx.strokeStyle = "#00e676";
    ctx.lineWidth = 3.5;
    ctx.stroke();

    ctx.font = "bold 24px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    ctx.fillStyle = "#00e676";
    ctx.fillText(`▲ +${boarding} Biniş`, 85, 35);

    ctx.fillStyle = "#ffffff";
    ctx.fillText("|", 160, 35);

    ctx.fillStyle = "#f87171";
    ctx.fillText(`▼ -${alighting} İniş`, 235, 35);

    const texture = new THREE.CanvasTexture(canvas);
    texture.minFilter = THREE.LinearFilter;
    const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(48, 10, 1);
    return sprite;
  }

  update() {
    const activeIds = new Set();
    const nowSec = performance.now() * 0.001;

    // 1. Trenleri Güncelle
    this.engine.activeTrains.forEach(train => {
      activeIds.add(train.id);
      let mesh = this.trainMeshes.get(train.id);
      if (!mesh) {
        mesh = this.createTrainMesh(train);
        this.scene.add(mesh);
        this.trainMeshes.set(train.id, mesh);
      }

      const targetPos = this.geoToWorld(train.lat, train.lon, train.isTunnel ? -14 : 0);
      mesh.position.copy(targetPos);
      mesh.rotation.y = -train.bearing * (Math.PI / 180) + Math.PI;
      mesh.userData.data = train;

      if (train.status === "BLOCKED") {
        mesh.children[0].material.emissive.setHex(0xef4444);
        mesh.children[0].material.emissiveIntensity = 0.85 + Math.sin(Date.now() * 0.01) * 0.45;
      } else if (train.status === "DWELLING") {
        mesh.children[0].material.emissive.setHex(0xf59e0b);
        mesh.children[0].material.emissiveIntensity = 0.55;
      } else {
        mesh.children[0].material.emissive.set(train.color);
        mesh.children[0].material.emissiveIntensity = 0.25;
      }
    });

    for (const [id, mesh] of this.trainMeshes.entries()) {
      if (!activeIds.has(id)) {
        this.scene.remove(mesh);
        this.trainMeshes.delete(id);
      }
    }

    // 2. İstasyon Peron Doluluk Halkaları, SL-Train Yolcu Yoğunluğu Noktaları ve Canlı İniş/Biniş Balonları
    Object.values(this.engine.stationMap).forEach(stn => {
      const ring = this.stationRings.get(stn.id);
      const loadRatio = Math.min(1.2, (stn.waitingPax || 0) / (stn.platformCapacity || 300));
      if (ring) {
        if (loadRatio > 0.75) {
          ring.material.color.setHex(0xef4444);
        } else if (loadRatio > 0.45) {
          ring.material.color.setHex(0xfacc15);
        } else {
          ring.material.color.setHex(0xffffff);
        }
        ring.scale.setScalar(1 + Math.min(0.45, loadRatio * 0.35));
      }

      // SL-Train Peron Üzerindeki Canlı Yolcu Noktaları (Load Density: <0.2 Mavi, <0.5 Sarı, <1.0 Turuncu, >1.0 Kırmızı)
      const paxDots = this.stationPaxDots.get(stn.id);
      if (paxDots) {
        const visibleCount = Math.max(4, Math.min(paxDots.length, Math.round(loadRatio * paxDots.length * 1.15)));
        const isDwelling = !!stn.activeDwell;

        paxDots.forEach((dot, idx) => {
          dot.visible = idx < visibleCount;
          if (!dot.visible) return;

          // Yoğunluğa göre renk (<0.2 Mavi, <0.5 Sarı, <1.0 Turuncu, >1.0 Kırmızı)
          if (loadRatio > 0.85 || idx > 20) {
            dot.material.color.setHex(0xef4444);
          } else if (loadRatio > 0.55 || idx > 14) {
            dot.material.color.setHex(0xf97316);
          } else if (loadRatio > 0.25 || idx > 7) {
            dot.material.color.setHex(0xfacc15);
          } else {
            dot.material.color.setHex(0x3b82f6);
          }

          // Peronda yürüme ve tramvay geldiğinde kapılara yönelme animasyonu
          const u = dot.userData;
          if (isDwelling) {
            dot.position.x = u.homeX + Math.sin(nowSec * 3.0 + u.phase) * 0.6;
            const targetEdgeZ = u.homeZ >= 0 ? 3.1 : -3.1;
            dot.position.z += (targetEdgeZ - dot.position.z) * 0.08;
          } else {
            dot.position.x = u.homeX + Math.sin(nowSec * u.speed + u.phase) * 1.1;
            dot.position.z = u.homeZ + Math.cos(nowSec * u.speed + u.phase) * 0.45;
          }
        });
      }

      const heatDisc = this.stationHeatDiscs.get(stn.id);
      if (heatDisc) {
        const demandRatio = Math.min(2.0, (stn.hourlyDemandBase || 800) / 1200);
        heatDisc.scale.setScalar(0.85 + loadRatio * 0.5 + demandRatio * 0.25);
        if (loadRatio > 0.7 || (stn.hourlyDemandBase || 0) > 1800) {
          heatDisc.material.color.setHex(0xef4444);
        } else if (loadRatio > 0.4 || (stn.hourlyDemandBase || 0) > 1000) {
          heatDisc.material.color.setHex(0xf59e0b);
        } else {
          heatDisc.material.color.setHex(0x3b82f6);
        }
      }

      if (stn.activeDwell) {
        let feedbackSprite = this.dwellFeedbackSprites.get(stn.id);
        if (!feedbackSprite) {
          feedbackSprite = this.createDwellFeedbackSprite(stn.activeDwell.boarding, stn.activeDwell.alighting);
          const stnMesh = this.stationMeshes.get(stn.id);
          if (stnMesh) {
            const worldPos = new THREE.Vector3();
            stnMesh.getWorldPosition(worldPos);
            feedbackSprite.position.copy(worldPos);
            feedbackSprite.position.y += 28;
          }
          this.scene.add(feedbackSprite);
          this.dwellFeedbackSprites.set(stn.id, feedbackSprite);
        }
        feedbackSprite.position.y += Math.sin(Date.now() * 0.005) * 0.04;
      } else {
        const feedbackSprite = this.dwellFeedbackSprites.get(stn.id);
        if (feedbackSprite) {
          this.scene.remove(feedbackSprite);
          this.dwellFeedbackSprites.delete(stn.id);
        }
      }
    });

    // 3. Kamera Araç Takip Modu
    if (this.trackedTrainId) {
      const trackedMesh = this.trainMeshes.get(this.trackedTrainId);
      if (trackedMesh) {
        this.controls.target.lerp(trackedMesh.position, 0.08);
      }
    }

    // 4. Arıza İşaretçileri ve Müdahale Ekibi Lojistik Aracı
    this.updateIncidentMarkers();
  }

  updateIncidentMarkers() {
    this.engine.activeIncidents.forEach(inc => {
      let marker = this.incidentMarkers.get(inc.instanceId);
      if (!marker) {
        const geo = new THREE.OctahedronGeometry(13, 0);
        const mat = new THREE.MeshBasicMaterial({ color: 0xef4444, wireframe: true });
        marker = new THREE.Mesh(geo, mat);
        const pos = this.geoToWorld(inc.lat, inc.lon, 18);
        marker.position.copy(pos);
        this.scene.add(marker);
        this.incidentMarkers.set(inc.instanceId, marker);
      }
      marker.rotation.y += 0.04;
      marker.rotation.x += 0.02;

      if (inc.dispatch_team_required && inc.crewLat && inc.crewLon) {
        let crewMesh = this.crewMarkers.get(inc.instanceId);
        if (!crewMesh) {
          const cGeo = new THREE.BoxGeometry(7, 5, 11);
          const cMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0xf59e0b, emissiveIntensity: 0.7 });
          crewMesh = new THREE.Mesh(cGeo, cMat);
          this.scene.add(crewMesh);
          this.crewMarkers.set(inc.instanceId, crewMesh);
        }
        const cPos = this.geoToWorld(inc.crewLat, inc.crewLon, 4);
        crewMesh.position.copy(cPos);
      }
    });

    for (const [id, marker] of this.incidentMarkers.entries()) {
      if (!this.engine.activeIncidents.some(i => i.instanceId === id)) {
        this.scene.remove(marker);
        this.incidentMarkers.delete(id);
      }
    }
    for (const [id, cMesh] of this.crewMarkers.entries()) {
      if (!this.engine.activeIncidents.some(i => i.instanceId === id)) {
        this.scene.remove(cMesh);
        this.crewMarkers.delete(id);
      }
    }
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.update();
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  onWindowResize() {
    if (!this.container) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  enableMapCoordinatePicker(callback) {
    this.pickCoordinateCallback = callback;
    if (this.container) {
      this.container.style.cursor = "crosshair";
    }
  }

  onPointerMove(event) {
    if (!this.tooltipEl) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    const interactiveObjects = [];
    this.trainMeshes.forEach(group => interactiveObjects.push(group.children[0]));
    this.stationMeshes.forEach(mesh => interactiveObjects.push(mesh));

    const intersects = this.raycaster.intersectObjects(interactiveObjects);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      const parentGroup = hit.parent;

      if (parentGroup && parentGroup.userData && parentGroup.userData.type === "train") {
        const train = parentGroup.userData.data;
        this.tooltipEl.style.display = "block";
        this.tooltipEl.style.left = `${event.clientX + 16}px`;
        this.tooltipEl.style.top = `${event.clientY - 12}px`;
        this.tooltipEl.innerHTML = `
          <div style="font-weight: 700; color: ${train.color}; font-size: 13px;">🚋 ${train.id} (${train.lineCode})</div>
          <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">${train.routeName}</div>
          <div style="margin-top: 6px; font-size: 11px;">
            Hız: <strong>${Math.round(train.currentSpeedKmh)} km/sa</strong> | Doluluk: <strong>%${train.loadFactor}</strong>
          </div>
          <div style="font-size: 10px; color: #38bdf8; margin-top: 2px;">Sonraki: ${train.nextStationName || 'Peron'}</div>
        `;
        return;
      } else if (hit.userData && hit.userData.type === "station") {
        const stn = hit.userData.data;
        const liveStn = this.engine.stationMap[stn.id] || stn;
        this.tooltipEl.style.display = "block";
        this.tooltipEl.style.left = `${event.clientX + 16}px`;
        this.tooltipEl.style.top = `${event.clientY - 12}px`;
        this.tooltipEl.innerHTML = `
          <div style="font-weight: 700; color: #38bdf8; font-size: 13px;">🏛️ ${liveStn.name}</div>
          <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">Hatlar: ${liveStn.lines ? liveStn.lines.join(", ") : "T1, T3"}</div>
          <div style="margin-top: 6px; font-size: 11px;">
            Peron Kuyruğu: <strong style="color:#f59e0b;">${Math.round(liveStn.waitingPax || 0)} yolcu</strong> (Yoğunluk: ${liveStn.hourlyDemandBase || 900}/sa)
          </div>
          <div style="font-size: 10px; color: #10b981; margin-top: 2px;">Son Biniş: +${liveStn.lastBoarding || 0} | İniş: -${liveStn.lastAlighting || 0} (3D Peron İkizi için tıklayın)</div>
        `;
        return;
      }
    }
    this.tooltipEl.style.display = "none";
  }

  onPointerDown(event) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    if (this.pickCoordinateCallback && this.groundPlaneMesh) {
      const groundHits = this.raycaster.intersectObject(this.groundPlaneMesh);
      if (groundHits.length > 0) {
        const pt = groundHits[0].point;
        const geo = this.worldToGeo(pt.x, pt.z);
        const cb = this.pickCoordinateCallback;
        this.pickCoordinateCallback = null;
        if (this.container) this.container.style.cursor = "";
        cb(geo.lat, geo.lon);
        return;
      }
    }

    const interactiveObjects = [];
    this.trainMeshes.forEach(group => interactiveObjects.push(group.children[0]));
    this.stationMeshes.forEach(mesh => interactiveObjects.push(mesh));

    const intersects = this.raycaster.intersectObjects(interactiveObjects);

    if (intersects.length > 0) {
      const hit = intersects[0].object;
      const parentGroup = hit.parent;

      if (parentGroup && parentGroup.userData && parentGroup.userData.type === "train") {
        const trainData = parentGroup.userData.data;
        this.trackedTrainId = trainData.id;
        if (this.onSelectEntity) this.onSelectEntity("train", trainData);
      } else if (hit.userData && hit.userData.type === "station") {
        const stnData = hit.userData.data;
        this.trackedTrainId = null;
        this.focusedStationId = stnData.id;
        const worldPos = this.geoToWorld(stnData.lat, stnData.lon, stnData.is_tunnel ? -14 : 0);
        this.focusOnStationPlatform(worldPos);
        if (this.onSelectEntity) this.onSelectEntity("station", stnData);
      }
    }
  }

  focusOnStationPlatform(worldPos) {
    const destCam = new THREE.Vector3(worldPos.x + 48, worldPos.y + 42, worldPos.z + 68);
    gsapCameraAndTarget(this.camera.position, destCam, this.controls.target, worldPos, 0.85);
  }

  focusOnPosition(worldPos, distance = 220) {
    const destCam = new THREE.Vector3(worldPos.x + distance * 0.35, Math.max(45, distance * 0.45), worldPos.z + distance * 0.65);
    gsapCameraAndTarget(this.camera.position, destCam, this.controls.target, worldPos, 0.8);
  }

  focusOnGeo(lat, lon) {
    const worldPos = this.geoToWorld(lat, lon, 0);
    this.focusOnStationPlatform(worldPos);
  }

  setCameraPreset(preset) {
    this.trackedTrainId = null;
    switch (preset) {
      case "all": {
        const destCam = new THREE.Vector3(0, 1750, 2100);
        const destTarget = new THREE.Vector3(0, 0, 0);
        gsapCameraAndTarget(this.camera.position, destCam, this.controls.target, destTarget, 0.9);
        break;
      }
      case "platform": {
        const stn = this.engine.stationMap[this.focusedStationId || "STN_19"] || this.engine.stationMap["STN_19"];
        const pPos = this.geoToWorld(stn.lat, stn.lon, stn.is_tunnel ? -14 : 0);
        this.focusOnStationPlatform(pPos);
        break;
      }
      case "meydan": {
        const mPos = this.geoToWorld(38.7218925, 35.4873228, 0);
        this.focusedStationId = "STN_19";
        this.focusOnStationPlatform(mPos);
        break;
      }
      case "erkilet": {
        const ePos = this.geoToWorld(38.77348, 35.49468, 0);
        const destCam = new THREE.Vector3(ePos.x + 180, 320, ePos.z + 340);
        gsapCameraAndTarget(this.camera.position, destCam, this.controls.target, ePos, 0.85);
        break;
      }
      case "talas": {
        const tPos = this.geoToWorld(38.70795, 35.53103, 0);
        const destCam = new THREE.Vector3(tPos.x + 140, 220, tPos.z + 260);
        gsapCameraAndTarget(this.camera.position, destCam, this.controls.target, tPos, 0.85);
        break;
      }
      case "kumsmall": {
        const kPos = this.geoToWorld(38.77767, 35.43233, 0);
        const destCam = new THREE.Vector3(kPos.x - 140, 220, kPos.z - 250);
        gsapCameraAndTarget(this.camera.position, destCam, this.controls.target, kPos, 0.85);
        break;
      }
    }
  }
}

function gsapCameraAndTarget(camVec, destCam, targetVec, destTarget, duration) {
  const sCamX = camVec.x, sCamY = camVec.y, sCamZ = camVec.z;
  const sTarX = targetVec.x, sTarY = targetVec.y, sTarZ = targetVec.z;
  const startTime = performance.now();

  function anim(now) {
    const elapsed = (now - startTime) / (duration * 1000);
    if (elapsed < 1.0) {
      const ease = 0.5 - Math.cos(elapsed * Math.PI) / 2;
      camVec.x = sCamX + (destCam.x - sCamX) * ease;
      camVec.y = sCamY + (destCam.y - sCamY) * ease;
      camVec.z = sCamZ + (destCam.z - sCamZ) * ease;
      targetVec.x = sTarX + (destTarget.x - sTarX) * ease;
      targetVec.y = sTarY + (destTarget.y - sTarY) * ease;
      targetVec.z = sTarZ + (destTarget.z - sTarZ) * ease;
      requestAnimationFrame(anim);
    } else {
      camVec.copy(destCam);
      targetVec.copy(destTarget);
    }
  }
  requestAnimationFrame(anim);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = Kayseri3DView;
}
