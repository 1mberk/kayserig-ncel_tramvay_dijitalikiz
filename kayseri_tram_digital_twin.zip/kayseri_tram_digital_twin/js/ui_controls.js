/**
 * Kayseri Tramvay Dijital İkiz — Kullanıcı Arayüzü & Reaktif Kontroller (V4)
 * - Konsolide 3D Harita Altlık Seçimi (Mapbox Dark v11 / CartoDB Voyager / Positron / Dark / Esri / OSM Fallback)
 * - T5 Erkilet Dinamik Durak Yönetimi (İsim, Koordinat, Saatlik Yolcu Yoğunluğu, Doluluk Oranı Ekleme/Düzenleme/Silme)
 * - Sayfa Yenilenmeden Reaktif Rota, Marker ve Yoğunluk Isı Haritası Güncellemesi
 * - Hafta İçi, Cumartesi ve Pazar Zaman Profilleri
 * - Zenginleştirilmiş RAMS Arıza & Bakım Backlogu Meta Veri Görüntüleyicisi
 */

class TramUIController {
  constructor(engine, threeView) {
    this.engine = engine;
    this.threeView = threeView;
    this.selectedEntity = null;

    this.bindDOM();
    this.bindEvents();
    this.renderInitialUI();

    this.engine.onUpdate(() => this.updateUI());
    this.engine.onTopologyChange(() => {
      this.populateErkiletStationEditor();
      this.renderLinesList();
      this.populateIncidentStations();
    });
  }

  bindDOM() {
    this.simClockEl = document.getElementById("sim-clock");
    this.speedButtons = document.querySelectorAll(".speed-btn");
    this.cameraButtons = document.querySelectorAll(".camera-btn");
    this.dayTypeSelect = document.getElementById("day-type-select");
    this.dayQuickButtons = document.querySelectorAll(".day-quick-btn");
    this.basemapStyleSelect = document.getElementById("basemap-style-select");
    this.dayProfileBadge = document.getElementById("day-profile-badge");
    this.dayProfileSummary = document.getElementById("day-profile-summary");
    this.flowDayLabel = document.getElementById("flow-day-label");

    // Sol Panel Metrikleri
    this.valTotalTrains = document.getElementById("val-total-trains");
    this.valCurrentPax = document.getElementById("val-current-pax");
    this.valLoadFactor = document.getElementById("val-load-factor");
    this.valPlatformQueue = document.getElementById("val-platform-queue");
    this.valPowerMw = document.getElementById("val-power-mw");
    this.linesContainer = document.getElementById("lines-container");

    // Sağ Panel (Inspector)
    this.inspectorContent = document.getElementById("inspector-content");

    // Alt Çekmece Sekmeleri
    this.tabButtons = document.querySelectorAll(".tab-btn");
    this.tabPanes = document.querySelectorAll(".tab-pane");

    // Arıza Yönetimi & RAMS Meta Veri Backlogu
    this.incidentSelect = document.getElementById("incident-type-select");
    this.stationSelect = document.getElementById("incident-station-select");
    this.btnTriggerIncident = document.getElementById("btn-trigger-incident");
    this.btnClearIncidents = document.getElementById("btn-clear-incidents");
    this.activeIncidentsBanner = document.getElementById("active-incidents-banner");
    this.incidentSpecDetails = document.getElementById("incident-spec-details");
    this.liveIncidentTracker = document.getElementById("live-incident-tracker");

    // Peron Akış Grid
    this.passengerFlowGrid = document.getElementById("passenger-flow-grid");

    // Erkilet Parametreleri ve Dinamik İstasyon Formları
    this.erkiletScenarioSelect = document.getElementById("erkilet-scenario-select");
    this.erkiletHeadwaySlider = document.getElementById("erkilet-headway-slider");
    this.erkiletHeadwayVal = document.getElementById("erkilet-headway-val");
    this.erkiletSpeedSlider = document.getElementById("erkilet-speed-slider");
    this.erkiletSpeedVal = document.getElementById("erkilet-speed-val");

    // Mevcut Durağı Düzenle / Çıkar
    this.editStationSelect = document.getElementById("erkilet-edit-station-select");
    this.editStnName = document.getElementById("edit-stn-name");
    this.editStnLat = document.getElementById("edit-stn-lat");
    this.editStnLon = document.getElementById("edit-stn-lon");
    this.editStnDemand = document.getElementById("edit-stn-demand");
    this.editStnOcc = document.getElementById("edit-stn-occ");
    this.btnSaveEditStation = document.getElementById("btn-save-edit-station");
    this.btnDeleteStation = document.getElementById("btn-delete-station");

    // Yeni Durak Ekle
    this.newStnName = document.getElementById("new-stn-name");
    this.newStnLat = document.getElementById("new-stn-lat");
    this.newStnLon = document.getElementById("new-stn-lon");
    this.newStnDemand = document.getElementById("new-stn-demand");
    this.newStnTunnel = document.getElementById("new-stn-tunnel");
    this.btnAddNewStation = document.getElementById("btn-add-new-station");
    this.btnPickStationOnMap = document.getElementById("btn-pick-station-map");

    // Erkilet Çıktı Metrikleri
    this.calcFleetSize = document.getElementById("calc-fleet-size");
    this.calcCycleTime = document.getElementById("calc-cycle-time");
    this.calcDailyCap = document.getElementById("calc-daily-cap");
    this.calcWaitTime = document.getElementById("calc-wait-time");
  }

  bindEvents() {
    // 3D Harita Zemin Altlığı Değiştirici
    if (this.basemapStyleSelect) {
      this.basemapStyleSelect.addEventListener("change", (e) => {
        if (this.threeView) {
          this.threeView.setBaseMapStyle(e.target.value);
        }
      });
    }

    // Zaman Hızı Butonları
    this.speedButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        this.speedButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        this.engine.timeScale = parseFloat(btn.dataset.speed);
      });
    });

    // Kamera Açı Butonları
    this.cameraButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        this.cameraButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const preset = btn.dataset.preset;
        if (this.threeView) this.threeView.setCameraPreset(preset);
      });
    });

    // Gün Tipi (Hafta İçi / Cumartesi / Pazar) Seçimi
    if (this.dayTypeSelect) {
      this.dayTypeSelect.addEventListener("change", (e) => {
        this.applyDayProfile(e.target.value);
      });
    }

    this.dayQuickButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        this.applyDayProfile(btn.dataset.day);
      });
    });

    // Alt Çekmece Sekme Geçişleri
    this.tabButtons.forEach(btn => {
      btn.addEventListener("click", () => {
        this.tabButtons.forEach(b => b.classList.remove("active"));
        this.tabPanes.forEach(p => p.classList.remove("active"));
        btn.classList.add("active");
        const targetPane = document.getElementById(btn.dataset.tab);
        if (targetPane) targetPane.classList.add("active");
      });
    });

    // Arıza Türü Seçildiğinde RAMS Meta Veri Özelliklerini Göster
    if (this.incidentSelect) {
      this.incidentSelect.addEventListener("change", () => {
        this.updateIncidentSpecCard();
      });
    }

    // Arıza Tetikleme
    if (this.btnTriggerIncident) {
      this.btnTriggerIncident.addEventListener("click", () => {
        const catId = this.incidentSelect.value;
        const stnId = this.stationSelect.value;
        this.engine.triggerIncident(catId, stnId);

        const stn = this.engine.stationMap[stnId];
        if (stn && this.threeView) {
          const worldPos = this.threeView.geoToWorld(stn.lat, stn.lon, 0);
          this.threeView.focusOnPosition(worldPos, 340);
        }
      });
    }

    if (this.btnClearIncidents) {
      this.btnClearIncidents.addEventListener("click", () => {
        this.engine.clearAllIncidents();
      });
    }

    // Erkilet Parametreleri
    if (this.erkiletScenarioSelect) {
      this.erkiletScenarioSelect.addEventListener("change", (e) => {
        this.engine.updateErkiletConfig({ scenario: e.target.value });
        this.populateErkiletStationEditor();
        this.updateErkiletCalculations();
      });
    }

    if (this.erkiletHeadwaySlider) {
      this.erkiletHeadwaySlider.addEventListener("input", (e) => {
        const val = parseInt(e.target.value);
        this.erkiletHeadwayVal.innerText = `${val} dk`;
        this.engine.updateErkiletConfig({ headwayMinutes: val });
        this.updateErkiletCalculations();
      });
    }

    if (this.erkiletSpeedSlider) {
      this.erkiletSpeedSlider.addEventListener("input", (e) => {
        const val = parseInt(e.target.value);
        this.erkiletSpeedVal.innerText = `${val} km/sa`;
        this.engine.updateErkiletConfig({ commercialSpeed: val });
        this.updateErkiletCalculations();
      });
    }

    // Mevcut T5 Durağı Seçildiğinde Inputları Doldur
    if (this.editStationSelect) {
      this.editStationSelect.addEventListener("change", () => {
        this.loadSelectedErkiletStationIntoForm();
      });
    }

    // Mevcut Durağı Reaktif Güncelleme Butonu (Sayfa Yenilenmeden!)
    if (this.btnSaveEditStation) {
      this.btnSaveEditStation.addEventListener("click", () => {
        if (!this.editStationSelect) return;
        const stnId = this.editStationSelect.value;
        const updated = this.engine.updateErkiletStation(stnId, {
          name: this.editStnName ? this.editStnName.value : undefined,
          lat: this.editStnLat ? parseFloat(this.editStnLat.value) : undefined,
          lon: this.editStnLon ? parseFloat(this.editStnLon.value) : undefined,
          hourlyDemandBase: this.editStnDemand ? parseInt(this.editStnDemand.value) : undefined,
          occupancyPct: this.editStnOcc ? parseFloat(this.editStnOcc.value) : undefined
        });

        if (updated) {
          this.showEntityDetails("station", updated);
          if (this.threeView) {
            this.threeView.focusOnGeo(updated.lat, updated.lon);
          }
          this.updateErkiletCalculations();
        }
      });
    }

    // Mevcut Durağı Çıkarma / Silme Butonu
    if (this.btnDeleteStation) {
      this.btnDeleteStation.addEventListener("click", () => {
        if (!this.editStationSelect) return;
        const stnId = this.editStationSelect.value;
        const ok = this.engine.removeErkiletStation(stnId);
        if (ok) {
          this.populateErkiletStationEditor();
          this.updateErkiletCalculations();
        }
      });
    }

    // Yeni T5 İstasyonu Ekleme Butonu
    if (this.btnAddNewStation) {
      this.btnAddNewStation.addEventListener("click", () => {
        const name = (this.newStnName && this.newStnName.value.trim()) ? this.newStnName.value.trim() : "Erkilet Yeni Durak";
        const lat = this.newStnLat ? parseFloat(this.newStnLat.value) : 38.7845;
        const lon = this.newStnLon ? parseFloat(this.newStnLon.value) : 35.4715;
        const demand = this.newStnDemand ? parseInt(this.newStnDemand.value) : 1450;
        const isTunnel = this.newStnTunnel ? !!this.newStnTunnel.checked : false;

        const newStn = this.engine.addCustomStationToErkilet(name, lat, lon, isTunnel, demand);
        this.populateErkiletStationEditor();
        if (this.editStationSelect) {
          this.editStationSelect.value = newStn.id;
          this.loadSelectedErkiletStationIntoForm();
        }
        this.showEntityDetails("station", newStn);
        if (this.threeView) {
          this.threeView.focusOnGeo(newStn.lat, newStn.lon);
        }
        this.updateErkiletCalculations();
      });
    }

    // 3D Harita Üzerinden Tıklayarak Koordinat Seçme
    if (this.btnPickStationOnMap) {
      this.btnPickStationOnMap.addEventListener("click", () => {
        if (!this.threeView) return;
        this.btnPickStationOnMap.innerText = "🎯 Haritaya Tıklayın...";
        this.threeView.enableMapCoordinatePicker((lat, lon) => {
          if (this.newStnLat) this.newStnLat.value = lat.toFixed(5);
          if (this.newStnLon) this.newStnLon.value = lon.toFixed(5);
          this.btnPickStationOnMap.innerText = "📍 3D Haritadan Seç";
        });
      });
    }
  }

  applyDayProfile(dayType) {
    this.engine.setDayType(dayType);
    if (this.dayTypeSelect) this.dayTypeSelect.value = dayType;
    this.dayQuickButtons.forEach(b => b.classList.toggle("active", b.dataset.day === dayType));

    const prof = this.engine.getActiveDayProfile();
    if (this.dayProfileBadge) this.dayProfileBadge.innerText = prof.label.split("(")[0].trim();
    if (this.flowDayLabel) this.flowDayLabel.innerText = prof.label;
    if (this.dayProfileSummary) {
      this.dayProfileSummary.innerHTML = `📅 <strong>${prof.label}:</strong> ${prof.description} (Sefer Çarpanı: <strong>${prof.headway_multiplier}x</strong>, Talep Ölçeği: <strong>%${Math.round(prof.demand_scale * 100)}</strong>)`;
    }
    this.updateErkiletCalculations();
    this.updateUI();
  }

  populateErkiletStationEditor() {
    if (!this.editStationSelect) return;
    const prevVal = this.editStationSelect.value;
    this.editStationSelect.innerHTML = "";

    const erkStations = this.engine.getErkiletStations();
    erkStations.forEach(stn => {
      const opt = document.createElement("option");
      opt.value = stn.id;
      opt.innerText = `${stn.isCustom ? "⭐ " : ""}${stn.name} (${stn.hourlyDemandBase || 1100} yolcu/sa)`;
      this.editStationSelect.appendChild(opt);
    });

    if (prevVal && erkStations.some(s => s.id === prevVal)) {
      this.editStationSelect.value = prevVal;
    }
    this.loadSelectedErkiletStationIntoForm();
  }

  loadSelectedErkiletStationIntoForm() {
    if (!this.editStationSelect) return;
    const stnId = this.editStationSelect.value;
    const stn = this.engine.stationMap[stnId];
    if (!stn) return;

    if (this.editStnName) this.editStnName.value = stn.name || "";
    if (this.editStnLat) this.editStnLat.value = Number(stn.lat).toFixed(5);
    if (this.editStnLon) this.editStnLon.value = Number(stn.lon).toFixed(5);
    if (this.editStnDemand) this.editStnDemand.value = stn.hourlyDemandBase || 1100;
    if (this.editStnOcc) this.editStnOcc.value = stn.occupancyPct || Math.round(((stn.waitingPax || 45) / (stn.platformCapacity || 350)) * 100);
  }

  renderLinesList() {
    if (!this.linesContainer) return;
    this.linesContainer.innerHTML = "";
    this.engine.data.lines.forEach(line => {
      const div = document.createElement("div");
      div.className = "line-item";
      div.style.cursor = "pointer";
      div.innerHTML = `
        <span class="line-pill" style="background-color: ${line.color}; color: ${line.color}"></span>
        <span class="line-name">${line.name}</span>
        <span class="line-badge">${line.length_km} km</span>
      `;
      div.addEventListener("click", () => {
        if (line.code.startsWith("T5") && this.threeView) {
          this.threeView.setCameraPreset("erkilet");
        } else if (line.code === "T2" && this.threeView) {
          this.threeView.setCameraPreset("talas");
        } else if (line.code === "T3" && this.threeView) {
          this.threeView.setCameraPreset("kumsmall");
        } else if (this.threeView) {
          this.threeView.setCameraPreset("all");
        }
      });
      this.linesContainer.appendChild(div);
    });
  }

  populateIncidentStations() {
    if (!this.stationSelect) return;
    const prev = this.stationSelect.value || "STN_19";
    this.stationSelect.innerHTML = "";
    Object.values(this.engine.stationMap).forEach(stn => {
      if (stn.is_passenger_station === false) return;
      const opt = document.createElement("option");
      opt.value = stn.id;
      opt.innerText = `${stn.code || 'ST'} - ${stn.name}`;
      if (stn.id === prev) opt.selected = true;
      this.stationSelect.appendChild(opt);
    });
  }

  renderInitialUI() {
    this.renderLinesList();
    this.populateIncidentStations();
    this.populateErkiletStationEditor();

    if (this.incidentSelect) {
      this.incidentSelect.innerHTML = "";
      this.engine.data.incident_catalog.forEach(inc => {
        const opt = document.createElement("option");
        opt.value = inc.failure_id || inc.id;
        opt.innerText = `[${inc.severity_level || inc.severity}] ${inc.name} (${inc.MTTR_minutes || inc.typical_mttr_min} dk)`;
        this.incidentSelect.appendChild(opt);
      });
      this.updateIncidentSpecCard();
    }

    this.updateErkiletCalculations();

    if (this.engine.activeTrains.length > 0) {
      this.showEntityDetails("train", this.engine.activeTrains[0]);
    }
  }

  updateIncidentSpecCard() {
    if (!this.incidentSelect || !this.incidentSpecDetails) return;
    const catId = this.incidentSelect.value;
    const inc = this.engine.data.incident_catalog.find(i => i.failure_id === catId || i.id === catId) || this.engine.data.incident_catalog[0];

    const sevColor = (inc.severity_level === "Kritik") ? "#ef4444" : (inc.severity_level === "Orta") ? "#f59e0b" : "#38bdf8";

    this.incidentSpecDetails.innerHTML = `
      <div style="display:flex; justify-content:space-between; margin-bottom:2px;">
        <span>Kod / Kategori:</span>
        <strong style="color:${sevColor};">${inc.failure_id} • ${inc.category} (${inc.severity_level})</strong>
      </div>
      <div style="display:flex; justify-content:space-between; margin-bottom:2px;">
        <span>MTBF / MTTR:</span>
        <strong>${(inc.MTBF_hours || inc.mtbf_hours).toLocaleString("tr-TR")} sa / <span style="color:#fbbf24;">${inc.MTTR_minutes || inc.typical_mttr_min} dk</span></strong>
      </div>
      <div style="display:flex; justify-content:space-between; margin-bottom:2px;">
        <span>Etkilenen Sistem:</span>
        <span style="color:#e2e8f0; text-align:right;">${inc.affected_system}</span>
      </div>
      <div style="display:flex; justify-content:space-between; margin-bottom:2px;">
        <span>Emniyet Protokolü:</span>
        <span style="color:#38bdf8; text-align:right;">${inc.safety_protocol}</span>
      </div>
      <div style="display:flex; justify-content:space-between;">
        <span>Hat Etkisi & Ekip Sevki:</span>
        <strong style="color:#00e676;">${inc.line_impact} (${inc.dispatch_team_required ? "Saha Ekibi Sevkli" : "Yerel Müdahale"})</strong>
      </div>
    `;
  }

  updateUI() {
    const metrics = this.engine.getSystemMetrics();

    if (this.simClockEl) {
      this.simClockEl.innerText = metrics.simTimeFormatted;
    }

    if (this.valTotalTrains) this.valTotalTrains.innerText = metrics.totalTrains;
    if (this.valCurrentPax) this.valCurrentPax.innerText = metrics.totalCurrentPassengers.toLocaleString("tr-TR");
    if (this.valLoadFactor) this.valLoadFactor.innerText = `%${metrics.avgLoadFactorPct}`;
    if (this.valPlatformQueue) this.valPlatformQueue.innerText = metrics.totalPlatformQueue.toLocaleString("tr-TR");
    if (this.valPowerMw) this.valPowerMw.innerText = `${metrics.totalPowerMw} MW`;

    if (this.activeIncidentsBanner) {
      if (metrics.activeIncidentsCount > 0) {
        const inc = this.engine.activeIncidents[0];
        const remMin = Math.ceil(inc.remainingDurationSec / 60);
        this.activeIncidentsBanner.style.display = "flex";
        this.activeIncidentsBanner.innerHTML = `
          <span>⚠️ <strong>[${inc.failure_id}] ${inc.name}</strong> (${inc.stationName}) — Hat Etkisi: <strong>${inc.line_impact}</strong> | ${inc.phaseTitle} (Kalan MTTR: <strong>${remMin} dk</strong>)</span>
          <button class="action-btn danger" onclick="window.twinUI.engine.clearAllIncidents()">Onarımı Tamamla & Hatları Aç</button>
        `;

        if (this.liveIncidentTracker) {
          this.liveIncidentTracker.style.display = "block";
          this.liveIncidentTracker.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
              <strong style="color:#f87171;">🚨 [${inc.failure_id}] ${inc.name} (${inc.category} - ${inc.severity_level})</strong>
              <span style="font-size:11px; color:#fbbf24;">Kalan MTTR: ${remMin} dk / ${inc.MTTR_minutes} dk | MTBF: ${inc.MTBF_hours} saat</span>
            </div>
            <div style="font-size:11px; margin-bottom:4px;">
              İstasyon: <strong>${inc.stationName}</strong> | Etkilenen Sistem: <strong>${inc.affected_system}</strong> | Hat Etkisi: <strong style="color:#fbbf24;">${inc.line_impact}</strong>
            </div>
            <div style="font-size:11px; color:#38bdf8; margin-bottom:6px;">
              Emniyet Protokolü: <strong>${inc.safety_protocol}</strong> | Ekip: <strong>${inc.logistics.crew_name}</strong> (${inc.dispatch_team_required ? "Saha Ekibi Sevk Edildi" : "Yerel Müdahale"})
            </div>
            <div class="load-bar">
              <div class="load-bar-fill" style="width: ${inc.phaseProgressPct}%; background-color: #ef4444;"></div>
            </div>
          `;
        }
      } else {
        this.activeIncidentsBanner.style.display = "none";
        if (this.liveIncidentTracker) this.liveIncidentTracker.style.display = "none";
      }
    }

    this.updatePassengerFlowCards();

    if (this.selectedEntity) {
      if (this.selectedEntity.type === "train") {
        const train = this.engine.activeTrains.find(t => t.id === this.selectedEntity.data.id);
        if (train) this.showEntityDetails("train", train, false);
      } else if (this.selectedEntity.type === "station") {
        const stn = this.engine.stationMap[this.selectedEntity.data.id];
        if (stn) this.showEntityDetails("station", stn, false);
      }
    }
  }

  updatePassengerFlowCards() {
    if (!this.passengerFlowGrid) return;

    const monitoredStations = [
      "STN_19", "STN_20", "STN_24", "STN_48", "STN_61", "ERK_A_04", "ERK_A_02", "STN_55"
    ];

    let html = "";
    monitoredStations.forEach(stnId => {
      const stn = this.engine.stationMap[stnId];
      if (!stn) return;

      const queue = Math.round(stn.waitingPax || 0);
      const cap = stn.platformCapacity || 300;
      const pct = Math.min(100, Math.round((queue / cap) * 100));
      const col = pct > 75 ? "#ef4444" : pct > 40 ? "#f59e0b" : "#10b981";
      const dwellBadge = stn.activeDwell
        ? `<span style="font-size:10px; background:rgba(16,185,129,0.2); color:#10b981; padding:1px 5px; border-radius:4px;">🚋 ${stn.activeDwell.trainId}</span>`
        : `<span style="font-size:10px; color:var(--text-muted);">${stn.hourlyDemandBase || 1000}/sa</span>`;

      html += `
        <div class="ctrl-card" style="cursor:pointer; padding:8px 10px;" onclick="window.twinUI.focusStationById('${stn.id}')">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:6px;">
            <span style="font-size:11px; font-weight:bold; color:${col};">${stn.name}</span>
            ${dwellBadge}
          </div>
          <div style="font-size:11px; display:flex; justify-content:space-between; margin-top:2px;">
            <span>Peron Kuyruğu: <strong>${queue} yolcu</strong></span>
            <span>Doluluk: <strong>%${pct}</strong></span>
          </div>
          <div class="load-bar" style="margin-top:3px;">
            <div class="load-bar-fill" style="width:${pct}%; background-color:${col};"></div>
          </div>
          <div style="font-size:10px; color:var(--text-muted); display:flex; justify-content:space-between; margin-top:3px;">
            <span>Biniş: <strong style="color:#00e676;">+${stn.lastBoarding || 0}</strong></span>
            <span>İniş: <strong style="color:#f87171;">-${stn.lastAlighting || 0}</strong></span>
          </div>
        </div>
      `;
    });
    this.passengerFlowGrid.innerHTML = html;
  }

  focusStationById(stnId) {
    const stn = this.engine.stationMap[stnId];
    if (!stn) return;
    this.showEntityDetails("station", stn);
    if (this.threeView) {
      this.threeView.focusedStationId = stnId;
      this.threeView.focusOnGeo(stn.lat, stn.lon);
    }
  }

  showEntityDetails(type, data, isNewSelection = true) {
    this.selectedEntity = { type, data };

    if (type === "train") {
      const loadColor = data.loadFactor > 85 ? "#ef4444" : data.loadFactor > 60 ? "#f59e0b" : "#00e676";
      const statusText = data.status === "BLOCKED"
        ? "🚨 ARIZA / BLOKE"
        : data.status === "DWELLING"
        ? `⏳ PERONDA (Biniş/İniş - ${Math.round(data.dwellTimerSec)}s)`
        : "🟢 SEYİR HALİNDE";

      this.inspectorContent.innerHTML = `
        <div class="inspector-title">
          <span class="inspector-badge" style="background-color: ${data.color}; color: #fff">${data.lineCode}</span>
          <span class="inspector-name">${data.id} (${data.model.split("(")[0].trim()})</span>
        </div>
        <div class="detail-row">
          <span>Güzergâh:</span>
          <span>${data.routeName}</span>
        </div>
        <div class="detail-row">
          <span>İşletme Durumu:</span>
          <span><strong>${statusText}</strong></span>
        </div>
        <div class="detail-row">
          <span>Anlık Seyir Hızı:</span>
          <span>${Math.round(data.currentSpeedKmh)} km/sa (Açı: ${Math.round(data.bearing)}°)</span>
        </div>
        <div class="detail-row">
          <span>Önceki / Sonraki İstasyon:</span>
          <span>${data.fromStationName || "Durak"} → <strong>${data.nextStationName || "İstasyon"}</strong></span>
        </div>
        <div class="detail-row">
          <span>Varışa Kalan Süre:</span>
          <span>${data.etaSeconds ? `${Math.round(data.etaSeconds)} sn` : "Peronda"}</span>
        </div>

        <div class="load-bar-wrap">
          <div style="display:flex; justify-content:space-between; font-size:11px;">
            <span>Araç İçi Yolcu: <strong>${data.passengers} / ${data.capacity}</strong></span>
            <span>Doluluk: <strong>%${data.loadFactor}</strong></span>
          </div>
          <div class="load-bar">
            <div class="load-bar-fill" style="width: ${data.loadFactor}%; background-color: ${loadColor};"></div>
          </div>
          <div style="display:flex; justify-content:space-between; font-size:10px; color:var(--text-muted); margin-top:2px;">
            <span>Son Durak Biniş: <strong style="color:#00e676;">+${data.lastBoarded || 12}</strong></span>
            <span>Son Durak İniş: <strong style="color:#f87171;">-${data.lastAlighted || 9}</strong></span>
          </div>
        </div>

        <div class="panel-header" style="margin-top: 10px;">ARAÇ SAĞLIK & TELEMETRİ</div>
        <div class="detail-row">
          <span>Katener Voltajı:</span>
          <span>${data.catenaryVoltage} V DC</span>
        </div>
        <div class="detail-row">
          <span>Anlık Çekiş Gücü:</span>
          <span>${data.powerKw} kW</span>
        </div>
        <div class="detail-row">
          <span>Tekerlek Aşınma Sağlığı:</span>
          <span>%${data.health.wheelWearPct} (İyi)</span>
        </div>
        <div class="detail-row">
          <span>Pantoğraf Durumu:</span>
          <span>${data.health.pantograph}</span>
        </div>
        <div class="detail-row">
          <span>Ağır Bakıma Kalan:</span>
          <span>${data.health.nextMaintenanceKm.toLocaleString("tr-TR")} km</span>
        </div>
      `;
    } else if (type === "station") {
      const liveStn = this.engine.stationMap[data.id] || data;
      const isHub = liveStn.is_hub || liveStn.type === "central_hub" || liveStn.type === "transfer";
      const queue = Math.round(liveStn.waitingPax || 0);
      const cap = liveStn.platformCapacity || 300;
      const crowdRatio = Math.min(100, Math.round((queue / cap) * 100));
      const crowdCol = crowdRatio > 75 ? "#ef4444" : crowdRatio > 40 ? "#f59e0b" : "#10b981";

      if (liveStn.id && liveStn.id.startsWith("ERK_") && this.editStationSelect) {
        this.editStationSelect.value = liveStn.id;
        this.loadSelectedErkiletStationIntoForm();
      }

      this.inspectorContent.innerHTML = `
        <div class="inspector-title">
          <span class="inspector-badge">${liveStn.code || "İST"}</span>
          <span class="inspector-name">${liveStn.name}</span>
        </div>
        <div class="detail-row">
          <span>Koordinat (WGS84):</span>
          <span>${Number(liveStn.lat).toFixed(5)}, ${Number(liveStn.lon).toFixed(5)}</span>
        </div>
        <div class="detail-row">
          <span>İstasyon Tipi:</span>
          <span>${liveStn.type === "terminal" ? "Terminal İstasyonu" : isHub ? "Ana Aktarma Hub" : "Hat İstasyonu"}</span>
        </div>
        <div class="detail-row">
          <span>Hizmet Veren Hatlar:</span>
          <span><strong>${liveStn.lines ? liveStn.lines.join(", ") : "T1, T3"}</strong></span>
        </div>
        <div class="detail-row">
          <span>Altyapı Kesiti:</span>
          <span>${liveStn.is_tunnel ? "Yer Altı Tünel İstasyonu (-18 m)" : "SL-Train 3B Ada Peron + Üst Geçit"}</span>
        </div>

        <div class="panel-header" style="margin-top: 10px;">CANLI PERON YOLCU & ISI HARİTASI</div>
        <div class="load-bar-wrap">
          <div style="display:flex; justify-content:space-between; font-size:11px;">
            <span>Peronda Bekleyen: <strong style="color:${crowdCol};">${queue} yolcu</strong></span>
            <span>Doluluk: <strong>%${crowdRatio}</strong> (Kap: ${cap})</span>
          </div>
          <div class="load-bar">
            <div class="load-bar-fill" style="width: ${crowdRatio}%; background-color: ${crowdCol};"></div>
          </div>
        </div>

        <div class="detail-row">
          <span>Son Sefer Biniş / İniş:</span>
          <span><strong style="color:#00e676;">+${liveStn.lastBoarding || 0} Biniş</strong> / <strong style="color:#f87171;">-${liveStn.lastAlighting || 0} İniş</strong></span>
        </div>
        <div class="detail-row">
          <span>Saatlik Baz Talep:</span>
          <span><strong>${liveStn.hourlyDemandBase || 1200} yolcu/saat</strong></span>
        </div>
        <div class="detail-row">
          <span>Anlık Peron Durumu:</span>
          <span>${liveStn.activeDwell ? `⏳ <strong>${liveStn.activeDwell.trainId}</strong> peronda (+${liveStn.activeDwell.boarding}/-${liveStn.activeDwell.alighting})` : "🟢 Peron açık"}</span>
        </div>
      `;
    }
  }

  updateErkiletCalculations() {
    const scenario = this.engine.erkiletConfig.scenario;
    const isA = (scenario === "scenario_a");
    const erkStations = this.engine.getErkiletStations();
    const stationCount = Math.max(2, erkStations.length);
    const routeLengthKm = (isA ? 17.8 : 14.7) + (this.engine.erkiletConfig.customStations.length * 0.4);
    const commercialSpeed = this.engine.erkiletConfig.commercialSpeed;
    const dayProfile = this.engine.getActiveDayProfile();
    const effectiveHeadway = Math.round(this.engine.erkiletConfig.headwayMinutes * (dayProfile.headway_multiplier || 1.0) * 10) / 10;

    const dwellMin = (stationCount * 25) / 60;
    const runTimeMin = Math.round((routeLengthKm / commercialSpeed) * 60 + dwellMin);
    const cycleTimeMin = Math.round(2 * runTimeMin + 12);
    const activeTrainsReq = Math.ceil(cycleTimeMin / Math.max(1, effectiveHeadway));
    const totalFleetReq = Math.ceil(activeTrainsReq * 1.15);
    const dailyTripsPerDir = Math.floor((18 * 60) / Math.max(1, effectiveHeadway));
    const totalDailyCap = dailyTripsPerDir * 2 * 296;
    const avgWaitMin = (effectiveHeadway / 2).toFixed(1);

    if (this.calcCycleTime) this.calcCycleTime.innerText = `${cycleTimeMin} dk (${runTimeMin} dk tek yön • ${stationCount} durak)`;
    if (this.calcFleetSize) this.calcFleetSize.innerText = `${totalFleetReq} Tren (${activeTrainsReq} aktif + ${totalFleetReq - activeTrainsReq} yedek)`;
    if (this.calcDailyCap) this.calcDailyCap.innerText = `${totalDailyCap.toLocaleString("tr-TR")} Yolcu/Gün`;
    if (this.calcWaitTime) this.calcWaitTime.innerText = `${avgWaitMin} dk (Efektif Headway: ${effectiveHeadway} dk)`;
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = TramUIController;
}
